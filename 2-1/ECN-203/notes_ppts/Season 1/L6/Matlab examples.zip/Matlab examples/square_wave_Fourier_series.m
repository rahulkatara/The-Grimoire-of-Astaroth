clc;
clear all;
close all;

syms t n

T=4; %Period

t1=-10:0.1:10;
t1(1)=[];
x=zeros(length(t1),1);
x(find(t1==-1*T/4):find(t1==T/4))=1;
x_one_period=x(find(t1==-1*T/2):find(t1==T/2));
x_one_period(1)=[];
x=repmat(x_one_period,length(t1)/length(x_one_period),1);


figure;
plot(t1,x,'r');
ylim([-0.1 1.1]);



w0=2*pi/T;

outputVideo = VideoWriter('square_wave_fourier_series_approximation','MPEG-4');
outputVideo.FrameRate = 10;
open(outputVideo);

E_N=zeros(1000,1);

for k=0:1000

    k
    
    n=-1*k:1:k;

    an=(1/T)*int(exp(-1*1i*n*w0*t),t,-T/4,T/4)

    x_N=zeros(length(t1),1);
    for j=1:length(n)
        for k1=1:length(t1)
            x_N(k1)=x_N(k1)+an(j)*exp(1i*n(j)*w0*t1(k1));
        end
    end
    
    e_N=x-x_N;
    
    
    E_N(k+1)=trapz(-1.9:0.1:2, abs(e_N(1:40)).^2);
    
    fig=figure;%('visible','off');
    title(['N=' num2str(k)])
    
    subplot(1,2,1);    
    plot(t1,x,'r');
    hold on;
    plot(t1,real(x_N),'b');
    ylim([-0.1 1.1]);
    title(['x/x_N' ' N=' num2str(k)])
    
    subplot(1,2,2);    
    plot(t1,real(e_N),'r');
    hold on;
    plot(t1,zeros(length(t1),1),'b');
    title(['e_N, E_N=' num2str(E_N(k+1))])
    
    F = getframe(fig);
    writeVideo(outputVideo,F);
    close(fig);
end
close(outputVideo);

figure;plot(E_N);
