clc;
clear all;
close all;

omega_0=pi/50;
t=0:0.1:100;

a_0=1;
a_1=1/4;
a_2=1/2;
a_3=1/3;
a_4=1/2;

figure;
x_1_t=zeros(length(t),1)+a_0;
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
for j=1:length(t)
    x_1_t(j)=x_1_t(j)+2*a_1*cos(2*pi*omega_0*t(j));
end
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
for j=1:length(t)
    x_1_t(j)=x_1_t(j)+2*a_2*cos(2*pi*2*omega_0*t(j));
end
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
for j=1:length(t)
    x_1_t(j)=x_1_t(j)+2*a_3*cos(2*pi*3*omega_0*t(j));
end
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
for j=1:length(t)
    x_1_t(j)=x_1_t(j)+2*a_4*cos(2*pi*4*omega_0*t(j));
end
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');