clc;
clear all;
close all;

omega_0=pi/50;
t=0:0.1:100;

no_of_complex_exponentials=20;
a_k=rand(no_of_complex_exponentials,1)


figure;
x_1_t=zeros(length(t),1)+a_k(1);
plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
for i=2:no_of_complex_exponentials
    for j=1:length(t)
        x_1_t(j)=x_1_t(j)+2*a_k(i)*cos(2*pi*(i-1)*omega_0*t(j));
    end
    plot(1:length(t),zeros(length(t),1),'r',1:length(t),x_1_t,'b');
end

