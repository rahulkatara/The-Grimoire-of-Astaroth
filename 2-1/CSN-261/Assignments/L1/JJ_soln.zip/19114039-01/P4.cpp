#include<iostream>
using namespace std;

// Function to get decimal value of the [k_th] bits pair from last for integer [x] 
int decimal(int x,int k){
	// Array to store binary representation for [x]
	int binary[8]={0}; 
	for (int i=7; x!=0;i--){
		binary[i]=x%2;
		x/=2;
	}
	
	return binary[8-2*k]*2+binary[9-2*k];
}

void CountSort(int *arr,int n,int k){

	/* [count] array stores the number of occurences of decimal representation of last [k_th] 
		pair of bits of the integers in array [arr] which can be: 0->00 ,1->01, 2->10, 3->11 */
	int count[4]={0};
	for(int i=0;i<n;i++){
		count[ decimal(arr[i],k) ]++;
	}

	// Change [count] to store the position of the element with corresponding decimal value in output array
	for(int i=1;i<4;i++){
		count[i]+=count[i-1];
	}

	// [sorted] -> output array
	int sorted[n];
	
	for(int i=n-1;i>=0;i--){
		sorted[count[decimal(arr[i],k)]-1]=arr[i];
		count[decimal(arr[i],k)]--;
	}

	//copy elements from [sorted] array to [arr]
	for(int i=0;i<n;i++){
		arr[i]=sorted[i];
	}
}

void RadixSort(int *arr,int n){
	for(int i=0;i<4;i++){
		//perform count sort on the array according to [i+1_th] last pair of two bits of the binary representation of a number
		CountSort(arr,n,i+1);
		
	}
}

int main(){
	int n;
	cout << "Enter the length of the array to be sorted: ";
	cin>>n;
	int arr[n];
	cout << "Enter the elements [b/w 0-255] of the array (in separate lines) and press enter: \n";
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	RadixSort(arr,n);
	cout << "Radix Sorted array: \n";
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout << "\n";
	return 0;
}