#include <iostream>
using namespace std;

// Function for swapping two integers
void swap(int &x,int &y){
	int a = x;
	x = y;
	y = a;
}

// Implementation of QuickSort using recursion to sort the array arr
void QuickSort(int *arr,int start,int end){
    
    if(start<end){
    	// First element is the pivot and p stores the index of the pivot element 
        int p=start;
		// Length of the array to be sorted
        int n=end-start+1;  
        for(int i=start+1;i<=end;i++){
        	if(arr[i]<arr[start]){
        		p++;
        		swap(arr[p],arr[i]);
        	}
        }
        swap(arr[start],arr[p]);

        /*After the swapping operations, array contains pivot element at index p and elements smaller than pivot 
		to the left and greater than or equal to to the right of the pivot*/
        QuickSort(arr,start,p-1);
        QuickSort(arr,p+1,end);
    }
    else{
        return;
    }
    
}

int main(){
	int n;
	cout << "Enter the length of the array to be sorted:";
	cin>>n;
	cout << "Enter the elements of the array (in separate lines) and press enter: \n";
	int arr[n];
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	
	QuickSort(arr,0,n-1);

	cout << "Sorted array: \n";
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout << "\n";
	return 0;
}