#include <iostream>
using namespace std;

/* Function to return the first occurence index for the [value] in a sorted array [arr]
with starting index for searching: [start] and ending index as [end]*/ 
int search(int *arr,int start,int end,int value){
	/* If value is not present in the array then return the 
	   index of element just smaller than value in the array*/
	if(start>end){
		return end;
	}
	
	int mid=(start+end)/2;
	
	if(arr[mid]==value){
		// If the value is present at the preceding index to mid again search between [start] and [mid-1]
		if(mid-1>=start && arr[mid-1]==value){
			return search(arr,start,mid-1,value);
		}
		else{
			return mid;
		}
	}
	else if(arr[mid]>value){
		return search(arr,start,mid-1,value);
	}
	else{
		return search(arr,mid+1,end,value);
	}
}

int main(){
	int n;
	cout << "Enter the length of the array to be sorted: ";
	cin>>n;
	int arr[n];
	cout << "Enter the elements of the array (in separate lines) and press enter: \n";
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	
	// Carry out Insertion sort
	for(int i=1;i<n;i++){
		// x is the index after which the arr[i] is to be inserted in the sorted array
		int x=search(arr,0,i-1,arr[i]);
		int y=arr[i];
		for(int j=i;j>x+1;j--){
			arr[j]=arr[j-1];
		}
		arr[x+1]=y;
	}
	cout << "Sorted array: \n";
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout << "\n";
	return 0;
}