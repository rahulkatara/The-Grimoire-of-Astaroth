#include <iostream>
using namespace std;

/* Function to return the first occurence index for the [value] in a sorted array [arr]
with starting index for searching: [start] and ending index as [end]*/ 
int search(int *arr,int start,int end,int value){

	// Return -1 if value is not found
	if(start>end){
		return -1;
	}
	
	int mid=(start+end)/2;
	
	if(arr[mid]==value){
		// If the value is present at the preceding index to mid again search between [start] and [mid-1]
		if(mid-1>=start && arr[mid-1]==value){
			return search(arr,start,mid-1,value);
		}
		else{
			return mid;
		}
	}
	else if(arr[mid]>value){
		return search(arr,start,mid-1,value);
	}
	else{
		return search(arr,mid+1,end,value);
	}
}

int main(){
	int n;
	cout << "Enter the length of the sorted array: ";
	cin>>n;
	int arr[n];
	cout << "Enter the elements of the sorted [ascending] array (in separate lines) in order and press enter: \n";
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	for(int i=0;i<n-1;i++){
		if(arr[i]>arr[i+1]){
			cout << "Looks like you didn't enter an ascending array! \n";
			return -1;
		}
	}
	int value;
	cout << "Enter the value for which the search is to be performed: ";
	cin>>value;
	int x=search(arr,0,n-1,value);
	if(x != -1){
		cout << "Search successful with index: ";
		cout<<x;
		} 
	else{
		cout << "Oops, program returned -1. Please check the inputs!";
		}
	cout << "\n";
	return 0;
}