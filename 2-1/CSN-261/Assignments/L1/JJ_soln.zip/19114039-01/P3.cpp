#include <iostream>
using namespace std;

int main(){
	int n;
	cout << "Enter the length of the array to be reversed: ";
	cin>>n;
	cout << "Enter the elements of the array (in separate lines) and press enter: \n";
	int arr[n];
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	for(int i=0;i<n/2;i++){
	    /* To ensure inplace operations we swap those elements
	       which belong to indexes [i] and [n-i-1] respectively. */
	    arr[i] = arr[i]-arr[n-1-i];
    	arr[n-1-i] = arr[i]+arr[n-1-i];
    	arr[i] = arr[n-1-i]-arr[i];

	}
	cout << "Reversed array: \n";
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout << "\n";
	return 0;
}