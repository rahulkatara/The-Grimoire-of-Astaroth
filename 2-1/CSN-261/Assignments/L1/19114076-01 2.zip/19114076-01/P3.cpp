// Problem 3

#include <bits/stdc++.h>
using namespace std;

int main(){

    int n;
    // Input: Array size (n)
    cin>>n;
    int a[n];
    // Input: The elements of the array
    for(int i=0; i<n; i++) cin>>a[i];

    for(int i=0; i<n/2; i++){
        a[i] = a[n-1-i]+a[i];
        a[n-1-i] = a[i] - a[n-1-i];
        a[i] = a[i] - a[n-1-i];
    }

    for(auto x:a) cout<<x<<" ";
    cout<<endl;

    return 0;
}