// Binary Insertion Sort - Problem 5

#include <bits/stdc++.h>
using namespace std;

int bin_search(int *a, int left_limit, int right_limit, int key){

    if(left_limit>=right_limit) return (key>a[left_limit]) ? (left_limit+1) : left_limit;

    int mp = (left_limit+right_limit)/2;
    if(a[mp]==key) return mp+1;

    if(key<a[mp]) return bin_search(a, left_limit, mp-1, key);
    else return bin_search(a, mp+1, right_limit, key);

}

void insertion_sort(int *a, int n){

    for(int i = 1; i < n; i++){
        int insertion_location = bin_search(a, 0, i-1, a[i]);

        int temp = a[i];

        for(int j = i; j > insertion_location; j--){
            a[j] = a[j-1];
        }

        a[insertion_location] = temp;
    }

}

int main(){

    int n;
    cin>>n;
    int a[n];
    for(int i = 0; i < n; i++) cin>>a[i];

    insertion_sort(a, n);

    for(auto x:a) cout<<x<<" ";
    cout<<endl;

    return 0;
}