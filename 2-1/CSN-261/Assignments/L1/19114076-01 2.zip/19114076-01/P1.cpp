// Quick Sort Algorithm - Problem 1

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

void swap(ll *a, ll *b){

    ll temp = *a;
    *a = *b;
    *b = temp;

}

ll partition(ll *a, ll left_limit, ll right_limit){
    
    ll pivot = a[right_limit];

    ll pi = left_limit-1; // Partitioning index

    for(ll i = left_limit; i<right_limit; i++){
        if(a[i]<pivot){
            pi++; // Make room for the new smaller element
            swap(&a[i], &a[pi]); // Swap the elements to fit the smaller element in the left set
        }
    }
    swap(&a[pi+1], &a[right_limit]); // Put the pivot in place

    return pi+1;

}

void quicksort(ll *a, ll left_limit, ll right_limit){

    if(left_limit < right_limit){

        ll part = partition(a, left_limit, right_limit);

        quicksort(a, left_limit, part-1);
        quicksort(a, part+1, right_limit);
    }


}

int main(){

    ll n;
    cin>>n; // Input: Number of elements in array
    ll a[n];
    // Input: The elements of the array
    for(ll i=0; i<n; i++) cin>>a[i];

    quicksort(a, 0, n-1);

    for(auto x:a) cout<<x<<" ";
    cout<<endl;

    return 0;
}