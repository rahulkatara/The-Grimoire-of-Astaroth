// Binary Search - Problem 2

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll custom_binary_search(ll a[], ll left, ll right, ll key){
    
    if(left>right) return -1;

    ll mp = (left + right) / 2;
    if(a[mp]==key) return mp;

    if(key<a[mp]) return custom_binary_search(a, left, mp-1, key);
    else return custom_binary_search(a, mp+1, right, key);
}

int main(){

    ll n, key;
    // Input: The values of Array Size (n) and key
    cin>>n>>key;
    ll a[n];
    // Input: The elements of the array
    for(ll i=0; i<n; i++) cin>>a[i];

    ll ans = custom_binary_search(a, 0, n-1, key);
    cout<<ans<<endl;

    return 0;
}