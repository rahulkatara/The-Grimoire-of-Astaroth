// Radix Sort - Problem 4

#include <bits/stdc++.h>
using namespace std;

void count_sort(int *a, int n, int exp){

    int count[4] = {0}; // Since we have 4 possibilities: 00 01 10 11
    for(int i = 0; i < n; i++){
        count[(a[i]/exp)&3]++;
    }

    // Find Cumulative Sum in order to find the respective positions of elements
    for(int i = 1; i < 4; i++){
        count[i]+=count[i-1];
    }

    int out[n];

    for(int i = n-1; i >= 0; i--){
        out[count[(a[i]/exp)&3]-1] = a[i];
        count[(a[i]/exp)&3]--;
    }

    for(int i = 0; i < n; i++){
        a[i]=out[i];
    }

}

void radix_sort(int *a, int n){

    for(int i=0; i<4; i++){
        count_sort(a, n, 1<<(i*2));
    }

}

int main(){

    // Given that the input is in the range [0, 255]
    int n;
    // Input: Size of the array (n)
    cin>>n;
    int a[n];
    // Input: The elements of the array
    for(int i=0; i<n; i++) cin>>a[i];

    radix_sort(a, n);

    for(auto x:a) cout<<x<<" ";
    cout<<endl;

    return 0;
}