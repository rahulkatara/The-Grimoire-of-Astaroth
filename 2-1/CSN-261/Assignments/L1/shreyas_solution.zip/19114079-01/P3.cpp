/**********************************
	
	CSN-291 Lab 1 Question 3 : Reverse Array
	q3.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

int main() 
{
	//cout<<"Enter number of integers in the array: "; 
	int n;
	cin>>n;
	
	//cout<<"\nEnter space separated integers in the array:\n";
	int a[n];
	for(int i=0; i<n; i++){
		cin>>a[i];
	}

	/**
	  Exchange integers in positions a[i] and a[n-1-i] in place

	  Iterating only up till n/2 because we only want to switch once.
	*/
	for(int i=0; i<n/2; i++){
		//In-Place swapping
		a[i] = a[i] + a[n-1-i];
		a[n-1-i] = a[i] - a[n-1-i];
		a[i] = a[i] - a[n-1-i];
	}

	cout<<"\nReversed array:\n";
	for(int i=0; i<n; i++){
		cout<<a[i]<<" ";
	}
        
	return 0;
}
