/**********************************
	
	CSN-261 Lab 1 Question 5 : Insertion Sort using Binary Search
	q5.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

//Initialize variables globally to avoid redundant passing of elements in functions
int n; // to store size of array
int a[1000001]; // a large enough array to pass test cases 


//Binary search to find location of element (documented in q2.cpp)
int binary_search(int key, int low, int high){
	
	if(high<=low) return ( (a[low] < key) ? low+1 : low );
	
	int mid = (low+high)/2;

	if(a[mid] == key) return mid+1;

	if(a[mid] < key){
		return binary_search(key, mid+1, high);
	} else {
		return binary_search(key, low, mid-1);
	}
}

/**
	Sorts array using insertion sort
	@param : NONE
	@return NULL
*/
void insertion_sort(){
	
	int pos; // To store the correct position of variable in array
	
	for(int i=1; i<n; i++){
		pos = binary_search(a[i], 0, i-1); // perform binary search on prefix array to find correct position
		int j=i;
		int key = a[i];
		
		// Insert current element into its correct location
		while(j>pos)		{
			a[j] = a[j-1];
			j--;
		}
		a[j] = key;
	}
}

int main() 
{
	//N DECLARED GLOBALLY
	//cout<<"Enter the number of elements in the array: ";
	cin>>n;

	//ARRAY DECLARED GLOBALLY
	//cout<<"Enter space separated integers of the array to be sorted:\n";
	for(int i=0; i<n; i++){
		cin>>a[i];
	}

	insertion_sort();
	
	//OUTPUT
	cout<<"Sorted array:\n";
	for(int i=0; i<n; i++){
		cout<<a[i]<<" ";
	}

	return 0;
}
