/**********************************
	
	CSN-261 Lab 1 Question 2: Binary Search 
	q2.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
	
/**
  Searches for the key in the array using binary search
  @param int nums[] -> array of integers
  @param int n      -> size of array
  @param int key    -> element that is being searched for
  @return index of element if found, else -1.
*/
int search(int nums[], int n, int key){
	
	int lower = 0;
	int upper = n-1;

	while(lower<=upper){
		int mid = lower + (upper-lower)/2;
		if(nums[mid] == key){
			return mid; //Element found
		} else if(nums[mid]>key){
			upper = mid-1; //Element does not exist in the upper half
		} else {
			lower = mid+1; //Element does not exist in the lower half
		}
	}
	return -1; //Element does not exist in the array
}

//Program starts here
int main() 
{
	//TAKE INPUT

	//cout << "Enter size of array: ";	
	int n; 
	cin >> n;
	
	//cout << "\nEnter space separated elements of array:\n";
	int nums[n];
	for(int i=0; i<n; i++){
		cin >> nums[i];
	}

	//cout << "\nEnter the value of they key you want to find: ";
	int key; 
	cin >> key;

	//Call binary search on the array
	int index = search(nums, n, key);

	//Display output
        if(index==-1){
		cout<<"The key "<<key<<" is not present in the array\n";
	} else {
		cout<<"The key "<<key<<" is present at index "<<index<<"\n";
	}
	return 0;
}
