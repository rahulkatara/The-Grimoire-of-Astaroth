/**********************************
	
	CSN-291 Lab 1 Question 4 : Radix Sort using Counting Sort
	q4.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

/**
	Converts an array of integers into their binary representation as strings

	@param int a[] -> array of integers
	@param string s[] -> array of strings in which we will store the binary representations
	@param int n -> size of array
	@return NULL
*/
void get_binary(int a[], string s[], int n){
	for(int i=0; i<n; i++){
		string s_temp;
		int num = a[i];
		for(int j=0; j<8; j++){
			int mod = num%2;
			num/=2;
			if(mod==0) s_temp = '0' + s_temp;
			else s_temp = '1' + s_temp;
		}
		s[i] = s_temp;
	}
}

/**
	Sorts the array of integers according to the specified bit pair
	
	@param int a[] -> array of integers in which we will store sorted array after each step
	@param string s[] -> array of binary strings which will also store the sorted value after each step
	@param int n -> size of array
	@param int round -> specificies which pair of bits to sort according to. Round 4 sorts according to first two bits and Round 1 sorts according to last two bits.
	@return NULL
*/
void count_sort(int a[], string s[], int n, int round){
	
	//Specify the bits according to which we will sort 
	int x = 8 - 2*round;
	int y = x+1;

	//Initialize count array with zeroes
	int count[4] = {0};

	//Iterate over each string in the array and increase the corresponding index of count by one
	for(int i=0; i<n; i++){
		string str = s[i];
		if(str[x] == '0' && str[y] == '0') // the two bits have value ZERO
		{
			count[0]++;
		} 
		else if(str[x] == '0' && str[y] == '1') // the two bits have value ONE
		{
			count[1]++;
		}
		else if(str[x] == '1' && str[y] == '0') // the two bits have value TWO
		{
			count[2]++;
		} else { // the two bits have value THREE
			count[3]++;
		}
	}
	
	//Calculate prefix sum of count array, as we do in count sort
	for(int i=1; i<4; i++){
		count[i] += count[i-1];
	}
	
	//Initialize temporary string and integer arrays to store the sorted values for this round
	string temp_string[n];
	int temp_int[n];

	// Build the output character array 
	for(int i=n-1; i>=0; i--){
		string str = s[i];
		if(str[x] == '0' && str[y] == '0'){	
			temp_string[--count[0]] = s[i]; 
			temp_int[count[0]] = a[i];
		} else if(str[x] == '0' && str[y] == '1'){
			temp_string[--count[1]] = s[i];
			temp_int[count[1]] = a[i];
		} else if(str[x] == '1' && str[y] == '0'){
			temp_string[--count[2]] = s[i];
			temp_int[count[2]] = a[i];
		} else {	
			temp_string[--count[3]] = s[i];
			temp_int[count[3]] = a[i];
		}
	}

	//Copy the values of temporary arrays into the arrays where we store the sorted values
	for(int i=0; i<n; i++){
		s[i] = temp_string[i];
		a[i] = temp_int[i];
	}
}



/**
	Sorts the array according to last two bits, then second-last pair of two bits, 
	then second pair of bits and finally most significant pair of bits to get the
	completely sorted array

	@param int a[]    -> array of integers
	@param string s[] -> array of binary representations of integers as strings
	@param int n      -> size of array
	@return NULL
*/
void radix_sort(int a[], string s[], int n){
	//Sorting the array four times, because there will be four groups when we pair two bits at a time.
	for(int i=1; i<=4; i++){
		count_sort(a, s, n, i);
	}

}

int main() 
{
	//Take input
	//cout<<"Enter number of elements in array: ";
	int n; 
	cin>>n;
	
	//cout<<"Enter space separated integers of the array between 0 and 255:\n";
	int a[n];
	for(int i=0; i<n; i++){
		cin>>a[i];
		
		//Number validation
		if(a[i]<0 && a[i]>255){ cout<<"Numbers must be between 0 and 255 inclusive"; return 0; }
	}

	string s[n]; //String array to store binary values as strings
	
	//Convert int to binary string
	get_binary(a, s, n);
	
	//Call radix sort function, which will itself call the count sort functions
	radix_sort(a, s, n);
	
	//Output sorted array
	for(int i=0; i<n; i++){
		cout<<a[i]<<" ";
	}

	return 0;
}
