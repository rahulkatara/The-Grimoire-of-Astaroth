/**********************************

	CSN-261 Lab 1 Question 1: Quick Sort
	q1.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

/**
  Takes the first element of the subarray as pivot, and corectly places it in its sorted position
  @param int l   -> lower index of subarray to be partitioned
  @param int h   -> upper index of subarray to be partitioned
  @param int a[] -> array to be sorted
  @param int n   -> size of array
  @return int j  -> final position of pivot element, which acts as the separation for the next partition
*/
int partition(int l, int h, int a[], int n){
	int pivot = a[l]; //Initialize the first element as pivot element.
	int i=l; int j=h;
	while(i<j){
		do{
			i++;
		} while(a[i]<=pivot);

		do{
			j--;
		} while(a[j]>pivot);

		if(i<j){
			// SWAP a[i] and a[j];
			int t = a[i];
			a[i] = a[j];
			a[j] = t;
		}
	}
	//SWAP a[j] and a[l];
	int tt = a[j];
	a[j] = a[l];
	a[l] = tt;
	return j;
}


/**
  Partitions the array into two parts and recursively calls itself to sort the smaller chunks
  @param int l   -> lower index of subarray to be sorted 
  @param int h   -> upper index of subarray to be sorted
  @param int a[] -> array to be sorted
  @param int n   -> size of array
  @return null
*/
void quicksort(int l, int h, int a[], int n){
	if(l<h) //Ensure that there are at least two elements by checking if l<h
	{
		
		//Find the index of pivot element after is kept in correct position
		int j = partition(l, h, a, n);
		
		//Apply quicksort on the two smaller partitions
		quicksort(l, j, a, n); 
		quicksort(j+1, h, a, n);
	}

}


//Controls operation of the program
int main() 
{

	//cout << "Enter number integers in the array: ";

	//Input size of array
        int n; 
	cin >> n;

	//Declare array of size N
	int a[n+1];

	//cout << "Enter the " << n << " space separated integers:\n";
	
	//Input elements of array
	for(int i=0; i<n; i++){
		cin>>a[i];
	}

	//Initialize last element with largest possible value (to act as infinity)
	a[n] = INT_MAX;
	
	//Sort the array
	quicksort(0, n, a, n);

	//Ouput the sorted array
	cout << "The quickly sorted array:\n";
	for(int i=0; i<n; i++){
		cout<<a[i]<<" ";
	}

	return 0;
}
