#include<iostream>
using namespace std;

int RandomIndex(int l,int r){
    int ind;
    ind = l+(rand()%(r-l+1));   //random number in range [l,r]
    return ind;
}

void Swap(int &a,int &b){
    int temp = a;
    a = b;
    b = temp; 
}

int Partition(int a[],int l, int r){
    
    int ind=RandomIndex(l,r);   //this step is done to ensure randomness in the array to avoid the worst comlexity cases

    Swap(a[r],a[ind]);  //Swap the pivot value with the value at randomly generated index

    int k=a[r]; //number to be put in it's correct place in the current call of function ie.the pivot

    int i=l,j=r;
    while(1){

        while(j>l && a[j]>=k) 
            --j;
        
        while(i<(r-1) && a[i]<=k) 
            ++i;  //r-1 here as we want the max value of i to be r-1

        if(i<j) 
            Swap(a[i],a[j]);
        else {
            if(a[j]>k)
                Swap(a[j],a[r]);
            else 
                Swap(a[j+1],a[r]);
            
            return j;
        }
    }
    
}

void QuickSort(int a[],int l ,int r){
    if(l<r){
        int m = Partition(a,l,r);   // This puts element at index m in the correct position as in the sorted array
        QuickSort(a,l,m);
        QuickSort(a,m+1,r);
    }
}

int main(){
    int n;
    cin>>n;

    int a[n];
    for(int i=0;i<n;++i){
        cin>>a[i];
    }

    QuickSort(a,0,n-1);
    
    for(int i=0;i<n;++i){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    


    return 0;
}
