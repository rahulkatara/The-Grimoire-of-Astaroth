#include<iostream>
using namespace std;

int BinarySearch(int a[],int x,int l,int r){  //this will return the greatest index at which elemnt value is <= our search query
    while(l<r){
        if(r-l+1<=2){
            if(a[r]<=x)
                return r;   //this ensures greatest index is being returned in case of [x,x] as greater index is checked first
            else 
                return l;
        }

        int m=(l+r)/2;
        
        if(a[m] <= x){
            l=m;
        }
        else{
            r=m-1;
        }   
    }
    return l;

}

void InsertionSort(int a[],int n){
    for(int i=1;i<n;++i){
        
        int val=a[i];

        if(a[i]<=a[0]){
            for(int j=i;j>0;--j){
                a[j]=a[j-1];
            }
            a[0]=val;
        }
        else if(a[i]>=a[i-1]){
            continue;
        }
        else{
            int ind = BinarySearch(a,val,0,i-1);    //as by now array till index i-1 would be sorted, BinarySearch can be applied
            
            //now we have ensured that a[0]  < val < a[i-1], thus BinarySearch would return the index of element less than or equal to val and it would exist for sure

            for(int j=i;j>(ind+1);--j){
                a[j]=a[j-1];
            }
            a[ind+1]=val;
        }
     
    }

}

int main(){

    int n;
    cin>>n;

    int a[n];
    for(int i=0;i<n;++i){
        cin>>a[i];
    }

    InsertionSort(a,n);

    for(int i=0;i<n;++i){
        cout<<a[i]<<" ";
    }
    cout<<endl;

    return 0;
}