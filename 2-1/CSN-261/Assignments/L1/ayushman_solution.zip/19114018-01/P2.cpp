#include<iostream>
using namespace std;

int BinarySearch(int a[],int x,int l,int r){
    if(l<=r){
        int m = l + (r-l)/2;

        if(a[m]==x){
            if(m!=0 && a[m-1]==x) //This is to ensure that the smallest index of that value is obtained, if multiple occurences are there
                return BinarySearch(a,x,l,m-1);
            else
                return m;
        }
        else if(a[m]>x)
            return BinarySearch(a,x,l,m-1);
        
        else
            return BinarySearch(a,x,m+1,r);
    }

    return -1;
}

int main(){

    int n;
    cin>>n;

    int a[n];
    for(int i=0;i<n;++i){
        cin>>a[i];
    }
    
    int x;//Key to be searched for
    cin>>x;

    if(BinarySearch(a,x,0,n-1)==-1){
        cout<<"No Such Key Found"<<endl;
    }
    else{
        cout<<BinarySearch(a,x,0,n-1)<<endl;    //Present Complexity:-> O(log n)

        // If it is asked print all indices that match we will just have a while loop untill the element at index value doesn't equal key Complexity :-> O(log n + number of occurences)
    }

    return 0;
}