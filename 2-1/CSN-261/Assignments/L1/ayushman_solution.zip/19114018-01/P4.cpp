#include<iostream>
using namespace std;

int b[256][8]={0};//stores 8-bit binary representation 

void InitialiseBinary(){//This process would take constant time .And as all numbers are in range [0,255] this would be very efficient for this problem and counting the decimal for 2 bits can be done directly
    for(int i=0;i<256;++i){
        int x=i,j=0;
        while(x>0){
            b[i][j]=x%2;
            x/=2;
            j++;
        }
    }
}
//ALITER--> to not using this if range of numbers is very large would be real time dividing and taking remainder 
//Eg. like here we would divide by 4^i and take remainder with 4,in the ith pass through count sort 
//But in question it has been asked to convert to binary representation and then sort, also this would be quite efficient in worst case complexity data

void CountSort(int a[],int val[],int n){
    
    int cnt[4]={0};//max possible value of a radix would be 4 possible values->binary{00,01,10,11}
    for(int i=0;i<n;++i){
        cnt[val[i]]++;
    }
    
    --cnt[0];//so that the indices start from 0 while calculating sorted portion
    for(int i=1;i<4;++i){
        cnt[i] += cnt[i-1];
    }

    int ind;
    int temp[n];//this would be the sorted array for the given radix

    for(int i=n-1;i>=0;--i){
        ind = cnt[val[i]];//index of a[i] in the sorted array according to that radix
        temp[ind] = a[i];
        --cnt[val[i]];
    }
    
    for(int i=0;i<n;++i){
        a[i] = temp[i];
    }       
}

void RadixSort(int a[],int n){
    
    //As all the numbers are of 8 bits hence all will have 4 places to sort by starting from right, thus we have to repeat the process only 4 times

    
    int val[n]={0};//it would contain the decimal value of 2 bits taken together in each iteration 

    for(int i=0;i<4;++i){
        
        for(int j=0;j<n;++j){
            val[j] = b[a[j]][2*i] * 1 + b[a[j]][2*i+1] * 2;  // 2*0 and 2*0+1 = indices 0 and 1 ...then  2 and 3 and so on till 6 and 7 // b[a[j]] has binary representation of a[j]

            // This is how I take decimal value of two bits at a time eg. 00 01 11 10 be number first 2 bits give 0 * 1 + 1 * 2 = 2; next two bits give 1 * 1 + 1 * 2 = 3 and so on
        }

        CountSort(a,val,n);
    }
    

}


int main(){
    
    int n;
    cin>>n;

    int a[n];
    for(int i=0;i<n;++i){
        cin>>a[i];
    }

    InitialiseBinary();
    RadixSort(a,n);

    for(int i=0;i<n;++i){
        cout<<a[i]<<" ";
    }
    cout<<endl;

    return 0;
}