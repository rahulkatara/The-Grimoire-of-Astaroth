// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

#include <iostream>
using namespace std;

// Node which is used in all the data structures
struct Soldier{
    int id;
    Soldier *next;
};

// A utility stack class to replicate the "lift"
class Lift{

    public:
    Soldier *head;
    Lift(){
        head = NULL;
    }

    void push(Soldier *x){
        x->next = head;
        head = x;
    }

    Soldier *pop(){

        if(head == NULL){
            return NULL;
        }

        Soldier *x = head;
        head = head->next;
        return x;
    }

    string print(){

        string s;
        Soldier *itr = head;
        while(itr!=NULL){
            s = s + "S" + to_string(itr->id) + ", ";
            itr = itr->next;
        }
        return s;

    }

};

// A utility linked list to replicate the soldiers standing in a line
class List_Soldiers{

    public:
    Soldier *head;

    List_Soldiers(){
        head = NULL;
    }

    void push(Soldier *x){

        if(head == NULL){
            x->next = NULL;
            head = x; 
        }else{
            Soldier *itr = head;
            Soldier *change = head;

            while(itr!=NULL && itr->id<x->id){
                change = itr;
                itr = itr->next;
            }

            if(itr == head){
                x->next = head;
                head = x;
            }else{
                x->next = change->next;
                change->next = x;
            }
        }

    }

    Soldier *pop(){

        if(head!=NULL){
            Soldier *x = head;
            head = head->next;
            return x;
        }else{
            return NULL;
        }

    }

    string print(){

        string s;
        Soldier *itr = head;
        while(itr!=NULL){
            s = s + "S" + to_string(itr->id) + " ";
            itr = itr->next;
        }
        return s;

    }

};

// Driver Function
int main(){

    // Take inputs n, m, c
    // The input c is redundant as c = n / m
    int n, m, c;
    cin>>n>>m>>c;

    if(n%m){
        cout<<"Invalid Input! n is not divisible by m"<<endl;
        return 0;
    }

    c = n/m;

    // Make the queue of soldiers on the ground
    List_Soldiers *ground_floor_line = new List_Soldiers();

    for(int i = 0; i < n; i++){
        Soldier *x = new Soldier();
        x->id = i+1;
        ground_floor_line->push(x);
    }
    
    // Initialize the Lifts
    Lift *Lifts = new Lift[c];

    // Pop the soldiers from line to lifts
    for(int i = 0; i < m; i++){
        Lifts[i] = Lift();
        for(int j = 0; j < c; j++){
            Lifts[i].push(ground_floor_line->pop());
        }
    }

    // Print the configuration of lifts
    cout<<"Soldiers in the respective Lifts at the Ground Floor are as:"<<endl;
    for(int i = 0; i < m; i++){
        cout<<"Soldiers in Lift "<<(i+1)<<": "<<Lifts[i].print()<<endl;
    }

    // Initialize the answer linked list
    List_Soldiers *ans = new List_Soldiers();

    // Keep track of number of soldiers popped because rand() function can cause some empty lifts to pop too
    int number_of_soldiers_popped = 0;

    // While there are soldiers in the lift, randomly pop soldiers from the lifts and push them into line
    while(number_of_soldiers_popped < n){

        // Select a random lift
        int l = rand()%m;

        // Pop the soldier
        Soldier *x = Lifts[l].pop();

        // If the lift is not empty, push the soldier into the line
        if(x!=NULL){
            cout<<"RANDOM SOLDIER ID S"<<x->id<<" popped from the respective Lift (Lift "<<(l+1)<<")"<<endl;
            ans->push(x);
            cout<<"Final SORTED LIST is: "<<ans->print()<<endl;
            number_of_soldiers_popped++;
        }

    }

    return 0;
}