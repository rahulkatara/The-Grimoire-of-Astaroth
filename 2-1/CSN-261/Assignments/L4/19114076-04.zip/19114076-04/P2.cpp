// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

#include <iostream>
using namespace std;

// Node for all data structures used
struct Node{

    int coefficient;
    int power;
    Node *next;

};

// A linked list representation of a polynomial
class Polynomial{

    public:
    Node *head;

    Polynomial(){
        head = NULL;
    }

    // Push the nodes in the decreasing order of their powers
    Node *push(int coefficient, int power){
        Node *x = new Node();
        x->coefficient = coefficient;
        x->power = power;
        
        // Arrange the linked list in descending order
        if(head == NULL){
            head = x;
            x->next = NULL;
        }else if(head->next == NULL){
            if(head->power > power){
                x->next = NULL;
                head->next = x;
            }else{
                x->next = head;
                head = x;
            }
        }else{
            Node *itr = head;
            Node *change = head;
            while(itr!=NULL && itr->power>power){
                change = itr;
                itr = itr->next;
            }
            if(itr == head){
                x->next = head;
                head = x;
            }else{
                x->next = change->next;
                change->next = x;
            }
        }

        return x;
    }

};

// Driver Function
int main(){

    // Initialize three polynomials
    Polynomial *polynomials = new Polynomial[3];

    // input
    for(int i = 0; i < 3; i++){
        int n, c, p;
        cin>>n; // The number of terms
        
        for(int j = 0; j < n; j++){
            // Input the coefficients and powers of each of the terms
            cin>>c>>p;
            polynomials[i].push(c, p);
        }
    }

    // Initialize the pointers for traversal
    Node *itr1 = polynomials[0].head, *itr2 = polynomials[1].head, *itr3 = polynomials[2].head;

    // Find the term with maximum power
    int temp = (itr1->power > itr2->power) ? itr1->power : itr2->power;
    int itr_power = (itr3->power > temp) ? itr3->power : temp;

    // Loop through all the powers and add their coefficients
    // Store the answer in the third polynomial
    while(itr_power>=0){
        temp = 0;
        if(itr1!=NULL && itr1->power == itr_power){
            temp+=itr1->coefficient;
            itr1 = itr1->next;
        }
        if(itr2!=NULL && itr2->power == itr_power){
            temp+=itr2->coefficient;
            itr2 = itr2->next;
        }
        if(itr3!=NULL && itr3->power == itr_power){
            temp+=itr3->coefficient;
        }

        if(temp){
            if(itr3!=NULL && itr3->power == itr_power){
                itr3->coefficient = temp;
                itr3 = itr3->next;
            }else{
                Node *x = polynomials[2].push(temp, itr_power);
                itr3 = x->next;
            }
        }

        itr_power--;
    }

    // Output the answer
    Node *itr_ans = polynomials[2].head;
    while(itr_ans->next!=NULL){
        cout<<itr_ans->coefficient<<"x^"<<itr_ans->power<<" + ";
        itr_ans = itr_ans->next;
    }
    cout<<itr_ans->coefficient<<"x^"<<itr_ans->power<<endl;

    return 0;
    
}