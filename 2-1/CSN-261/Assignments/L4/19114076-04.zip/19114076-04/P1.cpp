// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

#include <iostream>
using namespace std;

// Node for all the data structures used
struct Node{
    char bracket;
    Node *next;
};

// Utility Stack Class
class Stack{

    public:
    Node *head;
    Stack(){
        head = NULL;
    }

    void push(char a){
        Node *x = new Node();
        x->bracket = a;
        x->next = head;
        head = x;
    }

    char pop(){
        Node *x = head;
        head = head->next;
        char a = x->bracket;
        delete(x);
        return a;
    }

};

// A function to check the priority of two brackets
bool is_correct(char bracket_1, char bracket_2){

    if(bracket_1 == '['){
        return true;
    }else if(bracket_1 == '{' && bracket_2 != '['){
        return true;
    }else if(bracket_1 == '(' && bracket_2 == '('){
        return true;
    }else return false;

}

// A function to find the complement bracket of a given bracket
char find_complement(char bracket){

    switch(bracket){
        case '[': return ']';
        case '{': return '}';
        case '(': return ')';
        case ')': return '(';
        case '}': return '{';
        case ']': return '[';
        default: return 'x';
    }
    return 'x';

}

// Driver Function
int main(){

    // Input the string ( One string at a time )
    string s;
    cin>>s;

    Stack *my_stack = new Stack();

    for(int i = 0; i < s.length(); i++){

        // Check if the bracket is left or right
        if((s[i] == '[') || (s[i] == '{') || (s[i] == '(')){

            // If the bracket has correct priority push the bracket into the stack, else, print a Missing Priority Error
            if(my_stack->head == NULL ||  is_correct(my_stack->head->bracket, s[i])){
                my_stack->push(s[i]);
            }else{
                cout<<"Error: Missing Priority of "<<my_stack->head->bracket<<find_complement(my_stack->head->bracket)<<" and "<<s[i]<<find_complement(s[i])<<endl;
                return 0;
            }

        }else if(s[i] == ']' || s[i] == '}' || s[i] == ')'){

            // Check if the stack head has the correct complement of the current bracket
            // If yes, pop the bracket from the stack, else, throw an unbalanced error
            if(find_complement(s[i]) == my_stack->head->bracket){
                my_stack->pop();
            }else{
                cout<<"Error: Unbalanced "<<my_stack->head->bracket<<" and "<<s[i]<<endl;
                return 0;
            }

        }else{

            cout<<"Invalid input"<<endl;
            return 0;

        }

    }

    // Check if the stack is empty
    // If no, print an unbalanced error
    if(my_stack->head != NULL){

        cout<<"Error: Unbalanced "<<find_complement(my_stack->head->bracket)<<endl;

    }else{

        cout<<"Correct"<<endl;

    }

    return 0;
}