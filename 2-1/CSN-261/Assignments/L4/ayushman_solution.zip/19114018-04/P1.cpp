#include<iostream>
using namespace std;

struct node{
    char bracket;
    node* next;
};

class Stack{
    private:
        int size = 0;
    
    public:
        node* Top = NULL;

        void Push(node* x){

            if(size == 0){
                x->next = NULL;
                Top = x;
            }
            else{
                x->next = Top;
                Top = x;
            }

            size++;
        }

        void Pop(){

            node* temp = Top;

            Top = Top->next;    

            size--;
            delete temp;
        }

        bool Empty(){
            if(size == 0)
                return true;
            else 
                return false;
        }
};

int main(){

    int n;
    cin>>n;
    
    Stack st;

    for(int i = 0; i < n; ++i){
        
        string s;
        cin>>s;

        /*
            First I am checking if there are any unbalanced bracket errors
            Here I am neglecting any errors in priority
            After this check, I will check for missing priority errors
        */
        bool flag = 0;

        for(int i = 0; i < s.length(); i++){

            struct node* x = new node{};
            x->bracket = s[i];

            if(s[i] == '('){
                st.Push(x);
            }
            else if(s[i] == '{'){
                st.Push(x);
            }
            else if(s[i] == '['){
                st.Push(x);
            }
            else if(s[i] == ')'){
                flag = 1;

                if(st.Empty()){
                    cout<<"Error : Unbalanced ("<<endl;
                }
                else if(st.Top->bracket == '{'){
                    cout<<"Error : Unbalanced { and )"<<endl;
                }
                else if(st.Top->bracket == '['){
                    cout<<"Error : Unbalanced [ and )"<<endl;
                }
                else{
                    flag  = 0;
                    st.Pop();
                }
            }
            else if(s[i] == '}'){
                flag = 1;

                if(st.Empty()){
                    cout<<"Error : Unbalanced {"<<endl;
                }
                else if(st.Top->bracket == '('){
                    cout<<"Error : Unbalanced ( and }"<<endl;
                }
                else if(st.Top->bracket == '['){
                    cout<<"Error : Unbalanced [ and }"<<endl;
                }
                else{
                    flag  = 0;
                    st.Pop();
                }
            }
            else if(s[i] == ']'){
                flag = 1;

                if(st.Empty()){
                    cout<<"Error : Unbalanced ["<<endl;
                }
                else if(st.Top->bracket == '('){
                    cout<<"Error : Unbalanced ( and }"<<endl;
                }
                else if(st.Top->bracket == '{'){
                    cout<<"Error : Unbalanced [ and }"<<endl;
                }
                else{
                    flag  = 0;
                    st.Pop();
                }            
            }

            if(flag){
                break;
            }
                
        }            

        if(flag == 0){
            /*
                If the stack isn't empty, then there's an unbalance of the brackets that are already present
                As, in this case, the number of opening and closing brackets are not same. 
            */
            if(!st.Empty()){
                flag = 1;

                if(st.Top->bracket == '(')
                    cout<<"Error : Unbalanced )"<<endl;
                else if(st.Top->bracket == '{')
                    cout<<"Error : Unbalanced }"<<endl;
                else if(st.Top->bracket == '[')
                    cout<<"Error : Unbalanced ]"<<endl; 
                                      
            }
        }

        while(!st.Empty()){
            st.Pop();
        }
        //Here stack needs to be emptied to check for Missing Priority
        /*
            Algorithim to check for Priority:
            To the stack I only push the opening bracket. 
            If a lower priority bracket is present at the stack top and we are pushing one with higher priority,
            then there's a missing priority error.
            If any closing bracket is encountered I Pop the stack top as, no error would be enocuntered as I have already checked for bracket balance.
        */

        if(flag == 0){
            for(int i = 0; i < s.length(); i++){

                struct node* x = new node{};
                x->bracket = s[i];

                if(s[i] == '('){
                    st.Push(x);
                }
                else if(s[i] == '{'){
                    if(st.Empty()){
                        st.Push(x);
                    }
                    else if(st.Top->bracket == '('){
                        cout<<"Error : Missing Priority of () and {}"<<endl;
                        flag = 1;
                    }
                    else{
                        st.Push(x);
                    }
                }
                else if(s[i] == '['){
                    if(st.Empty()){
                        st.Push(x);
                    }
                    else if(st.Top->bracket == '('){
                        cout<<"Error : Missing Priority of () and []"<<endl;
                        flag = 1;
                    }
                    else if(st.Top->bracket == '{'){
                        cout<<"Error : Missing Priority of {} and []"<<endl;
                        flag = 1;
                    }
                    else{
                        st.Push(x);
                    }
                }
                else if(s[i] == ')'){
                    st.Pop();
                }
                else if(s[i] == '}'){
                    st.Pop();
                }
                else if(s[i] == ']'){
                    st.Pop();
                }

                if(flag){
                    break;
                }
                    
            }            
        }
        if(flag == 0){
            cout<<"Balanced Bracket Sequence : No Error"<<endl;
        }

        while(!st.Empty()){
            st.Pop();
        }
        // Lastly I empty the stack to reuse the same for the next test case
    }


    return 0;
}
/*
    I have added some extra testcases to show the exact checking of priority and unbalanced brackets.
*/