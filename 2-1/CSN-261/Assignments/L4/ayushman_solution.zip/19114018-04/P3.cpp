#include<iostream>
using namespace std;

struct soldier{
    int ID;
    soldier* next;
};
/*  Here class lift is of the type stack. 
    Just a modified version of the same, having same functionalities.
*/
class Lift{
    public:
        soldier* top= NULL;

        void Push(soldier* x){
            if(top == NULL){
                top = x;
            }
            else{
                x->next = top;
                top = x;
            }
        }

        soldier* Pop(){

            soldier* TEMP = top;
            top = top->next;

            return TEMP;
        }

};

/*
    The class Sorted_List  is also a type of stack 
    I am going to use this at last to do real-time insertion sort when soldiers are popped from the lifts
*/
class Sorted_List{

    public:
        soldier* top = NULL;

        
        void Insert(soldier* x){
  
            if(top == NULL){
                top = x;
                x->next = NULL;
            }
            else if(top->ID > x->ID){
                x->next = top;
                top = x;
            }
            else{
                soldier* temp = top;

                bool flag = 0;
                /*
                This is to check whether insertion was done in the middle or not
                If no insertion was done in the middle then we insert at end of list ie. when the current ID is the greatest
                */

                while(temp->next != NULL){
                    if(temp->next->ID > x->ID){
                        x->next = temp->next;
                        temp->next = x;
                        flag = 1;
                        break;
                    }
                    else{
                        temp = temp->next;
                    }
                }

                if(flag == 0){
                    x->next = NULL;
                    temp->next = x;
                }
            }   
        }

        void Print(){
            soldier* temp = top;

            cout<<"Final SORTED LIST is : ";
            while(temp != NULL){
                cout<<"S"<<temp->ID<<" ";
                temp = temp->next;
            }
            cout<<endl;
        }
};
int main(){
    int n,m,c;
    //cout<<"Enter the values of n, m, c : ";
    cin>>n>>m>>c;

    Lift lift[m+1];

    //Initialising all lifts
    for(int i = 1; i <= m ; ++i){
        cout<<"Soldiers in Lift "<<i<<" : ";
        for(int j = 1 ; j <= c; ++j){
            struct soldier* x = new soldier{};
            x->ID = (i-1) * c + j;

            if(j != c)
                cout<<"S"<<x->ID<<", ";
            else 
                cout<<"S"<<x->ID<<endl;
            
            lift[i].Push(x);
        }
    }
    int count = n;//Represents the total number of soldiers remaining in lifts and not popped yet

    int random_lift = 0;//The random lift choosen


    Sorted_List SL;


    while(count){
        random_lift = 1 + (rand() % m) ;//generates random lift in range [1,m]

        if(lift[random_lift].top != NULL){  
            soldier* x = lift[random_lift].Pop();
            cout<<"S"<<x->ID<<" popped from Lift "<<random_lift<<endl;

            SL.Insert(x);
            count--;

            SL.Print();
        }
    }
    //The above loop terminates when all soldiers have been popped and no soldier remains in any lift

    return 0;
}

/*
    In this whole program only the space for storing soldiers has been assigned once while making the lifts 
    I have made the final sorted list using the same space by reassigning the pointers as and when required
    Thus, a memory efficient implementation using stacks.
*/