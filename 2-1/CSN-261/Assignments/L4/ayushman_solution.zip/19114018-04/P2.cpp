#include<iostream>
using namespace std;

struct term{

    int coeff;
    int power;
    
    term* next;
}; 

class Polynomial{

    public:

        term* top = NULL;

        void Push(term* x){
            if(top == NULL){
                top = x;
            }
            else{
                x->next = top;
                top = x;
            }
        }

        void Pop(){
            term* TEMP = top;

            top = top->next;

            delete TEMP;
        }
        
};

int main(){

    Polynomial p1;

    //cout<<"Enter number of terms in the first polynomial: ";
    int n1;
    cin>>n1;

    for(int i=0;i<n1;++i){
        struct term* x = new term{};

        //cout<<"Enter coeffecient of term: ";
        cin>>x->coeff;

        //cout<<"Enter power of the term : ";
        cin>>x->power;

        p1.Push(x);
    }

    Polynomial p2;

    //cout<<"Enter number of terms in the second polynomial: ";
    int n2; 
    cin>>n2;

    for(int i=0;i<n2;++i){
        struct term* x = new term{};

        //cout<<"Enter coeffecient of term: ";
        cin>>x->coeff;

        //cout<<"Enter power of the term : ";
        cin>>x->power;

        p2.Push(x);
    }

    Polynomial p3;

    //cout<<"Enter number of terms in the third polynomial: ";
    int n3; 
    cin>>n3;

    for(int i=0;i<n3;++i){
        struct term* x = new term{};

        //cout<<"Enter coeffecient of term: ";
        cin>>x->coeff;

        //cout<<"Enter power of the term : ";
        cin>>x->power;

        p3.Push(x);
    }

    Polynomial result;//the polynomial that stores the result

    int expo = 0;
    int coefficient = 0;
    //Expo would represent the current term of the result
    
    int high = 1000000000;
    //Setting a high value to expo at start of each iteration would ensure that nothing is unnecessarily skipped

    while(p1.top != NULL || p2.top != NULL || p3.top !=NULL){
        expo = high;
        coefficient = 0;

        if(p1.top != NULL)
            expo = p1.top->power;

        if(p2.top != NULL && p2.top->power < expo)
            expo = p2.top->power;

        if(p3.top != NULL && p3.top->power < expo)
            expo = p3.top->power;

        /*
        The above three if statements help select the term with the least value of power among all the three polynomials.
        Then we take all the terms from the three polynomials which have thuis value and add them to store in result
        */

        if(p1.top != NULL && p1.top->power == expo){
            coefficient += p1.top->coeff;
            p1.Pop();
        }
        if(p2.top != NULL && p2.top->power == expo){
            coefficient += p2.top->coeff;
            p2.Pop();
        }

        if(p3.top != NULL && p3.top->power == expo){
            coefficient += p3.top->coeff;
            p3.Pop();;
        }

        struct term* x = new term{};

        x->coeff = coefficient;
        x->power = expo;

        result.Push(x);
    
    }

    while(result.top != NULL){
        cout<<result.top->coeff;
        cout<<"x^";
        cout<<result.top->power;

        if(result.top->next != NULL){
            cout<<" + ";
        }

        result.Pop();
    }        
    cout<<endl;

    return 0;
}