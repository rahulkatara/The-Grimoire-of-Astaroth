/******************************************************************

	CSN-261 Lab 4 Question 2 : Polynomial Addition using Linked Lists
	P2.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

******************************************************************/

#include <iostream>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

struct Term {
  int coefficient;
  int exponent;
  struct Term* next;
};

int main() 
{

  struct Term* polynomials[3]; // ARRAY TO STORE ALL THREE POLYNOMIALS
  for (int i=0; i<3; i++) { // INITIALISE ARRAY WITH NULL VALUES
    polynomials[i] = NULL;
  }

  int number_of_elements; // TO KNOW HOW MANY TIMES TO TAKE INPUT FOR ONE POLYNOMIAL
  int coeff; // COEFFICIENT VALUE FOR EACH TERM
  int exp; // EXPONENT OF VARIABLE FOR EACH TERM

  // INPUT POLYNOMIALS;
  for (int i=0; i<3; i++) {
    cin>>number_of_elements; // NUMBER OF ELEMENTS IN POLYNOMIALS
    struct Term *term = new Term(); // CREATE TERM TO INITIALISE AS FIRST VALUE OF POLYNOMIAL
    polynomials[i] = term; // FIRST VALUE OF POLYNOMIAL
    
    for (int j=0; j<number_of_elements; j++) {
      cin>>coeff>>exp; // INPUT VALUES OF TERM AND COEFFICIENT
      
      // POPULATE TERM WITH VALUES OF COEFFICIENT AND EXPONENT
      term->coefficient = coeff;
      term->exponent = exp;

      if (j < number_of_elements-1) { // IF THIS IS NOT THE LAST TERM IN THE POLYNOMIAL THEN WE NEED TO CREATE THE NEXT TERM AND MOVE FORWARD
        term->next = new Term(); // CREATE NEW TERM
        term = term->next; // MOVE FORWARD
      } else {
        term->next = NULL; // SINCE IT IS THE LAST ELEMENT, NEXT VALUE WOULD BE NULL
      }
    }
  }

  // ADD FIRST AND SECOND POLYNOMIALS USING FIRST POLYNOMIAL AS BASE
  for (int run=1;  run<3; run++) {
    struct Term *curr = polynomials[0]; // LEADING POINTER FOR FIRST POLYNOMIAL'S LINKED LIST
    struct Term *temp = polynomials[0]; // TRAILING POINTER FOR FIRST POLYNOMIAL'S LINKED LIST
    struct Term *insert = polynomials[run]; // INTERATING POINTER FOR SECOND AND THIRD POLYNOMIAL LINKED LIST
    while (true) {
      
      if (insert == NULL) { // IF INSERT IS NULL, IT MEANS THAT WE HAVE REACHED THE END OF THE ITERATED LINKED LIST. 
        break;              // HENCE WE HAVE ADDED ALL THE ELEMENTS. IT IS TIME TO BREAK
      }

      if (curr == NULL) { // THIS MEANS WE HAVE REACHED THE END OF THE FIRST LINKED LIST BUT HAVEN'T ADDED ALL ELEMENTS OF THE ITERATED POLYNOMIAL
        // CREATE NEW NODE TO BE INSERTED AT THE END OF THE BASE LINKED LIST
        struct Term *new_term = new Term();
        new_term->exponent = insert->exponent;
        new_term->coefficient = insert->coefficient;
        new_term->next = NULL;

        insert = insert->next; // SINCE THE TERM HAS BEEN INSERTED MOVE THIS FORWARD
        temp->next = new_term; // INSERT NEW TERM AT THE END OF BASE LINKED LIST
        temp = temp->next; // MOVE TRAILING POINTER TO END OF LINKED LIST
        curr = NULL; // SET CURR POINTER TO NULL BECAUSE WE WANT KNOW THIS BLOCK WILL HAVE TO BE RUN AGAIN IF THERE ARE MORE ELEMENTS REMAINING IN THE ITERATED POLYNOMIAL
        continue;
      } else {
        if (curr->exponent == insert->exponent) { // TERM WITH MATCHING COEFFICIENTS FOUND
          curr->coefficient += insert->coefficient; // MAINTAIN SUM OF COEFFICIENTS IN BASE POLYNOMIAL
          insert = insert->next; // INCREMENT ITERATING TERM POINTER
          // INCREMENT LEADING AND TRAILING POINTER IN BASE POLYNOMIAL BY ONE
          temp = curr; 
          curr = curr->next;
        } else if (curr->exponent < insert->exponent) {
          // NO TERM WITH MATCHING EXPONENT, SO CREATE ONE TO INSERT INTO NSE POLYNOMIAL
          struct Term *new_term = new Term();
          new_term->exponent = insert->exponent;
          new_term->coefficient = insert->coefficient;
          new_term->next = curr; // THIS WILL BE INSERTED IN BETWEEN TEMP AND CURR

          if (temp == curr) { // IF WE ARE STILL ON HEAD ELEMENT, THEN NEW TERM WOULD THEN HAVE TO BE MADE HEAD
            polynomials[0] = new_term; // MAKE HEAD
            temp = new_term; // SHIFT TEMP BACKWARDS TO HEAD
          } else { // WE ARE NOT ON HEAD ELEMENT ANYMORE AND TEMP IS TRAILING BEHIND CURR
            temp->next = new_term; // NEW TERM INSERTED BETWEEN TEMP AND CURR
            temp = temp->next; // MOVE TEMP FORWARDS ONE STEP SO IT IS AGAIN TRAILING CURR
          }
          insert = insert->next; // SINCE THE ELEMENT WAS JUST INSERTED, MOVE ONTO NEXT TERM    
        } else {
          // BASE EXPONENT IS STILLL GREATER THAN EXPONENT OF TERM TO BE INSERTED
          // KEEP MOVING FORWARD UNTIL CORRECT SPOT IS FOUND
          temp = curr; 
          curr = curr->next;
        }
      }
    }
  }

  // PRINT THE TERMS OF THE FIRST POLYNOMIAL AS THE SUM OF ALL THREE POLYNOMIALS IS NOW STORED HERE

  struct Term *term = polynomials[0];
  while(term != NULL) {
    cout<<term->coefficient<<"x^"<<term->exponent<< (term->next == NULL ? "\n" : " + ");
    term = term->next;
  }

	return 0;
}
