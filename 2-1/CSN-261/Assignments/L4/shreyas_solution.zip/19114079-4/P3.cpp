/*****************************************

	CSN-261 Lab 1 Question 3 : Army Soldiers
	P3.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

*****************************************/

#include <iostream>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

class Army {
  private:
    struct Soldier {
      int ID;
      struct Soldier* next;
    };
    int n; // TO STORE NUMBER OF SOLDIER
    int m; // TO STORE NUMBER OF LIFTS
    int c; // TO STORE SOLDIERS PER LIFT = n / m
    struct Soldier* ground_head; // TO STORE BASE LINKED LIST
    struct Soldier* output_list; // TO STORE OUTPUT LINKED LIST
    struct Soldier** lift_pointers; // TO STORE LIST OF POINTERS TO POINTERS ON THE BASE LINKED LIST, TO KEEP TRACK OF WHO WILL BE POPPED NEXT FROM A GIVEN LIFT
  public:
    Army (int n, int m, int c) {
      // INITIALISE LIFTS
      this->n = n;
      this->m = m;
      this->c = c;

      // WHILE INITIALISING LIFTS, OUTPUT IS EMPTY
      this->output_list = NULL;

      // INITIALISE HEAD POINTER OF BASE LINKED LIST
      this->ground_head = new Soldier();
      struct Soldier *curr = ground_head;

      // CREATE ARRAY OF POINTERS
      this->lift_pointers = new Soldier*[m];
      
      // POPULAT REST OF BASE LINKED LIST (WHICH IS GOING TO BE SORTED)
      for (int i=0; i<n+1; i++) {
        curr->ID = n-i; // DECREASING ORDER OF VALUES
        if (i != n && i%c == 0) {
          lift_pointers[m-1-i/c] = curr;
        }
        if (i == n) { // INSERTING n+1 NODES FOR CONVENIENCE OF CALCULATION GOING FORWARD, ALTHOUGH ONLY n SOLDIERS ARE BEING CONSIDERED
          curr->next = NULL;
        } else {
          curr->next = new Soldier();
          curr = curr->next;
        }
      }

    }
    void print_soldiers () {
      cout << "Soldiers in the respective lifts at the ground floor are:\n";
      for (int i=0; i<m; i++) {
        cout << "Soldiers in Lift " << (i+1) << ": ";
        int m1 = i*this->c+1;
        int c1 = this->c;
        while (c1--) {
          cout << "S" << m1 <<" ";
          m1++;
        }
        cout << "\n";
      }
    }
    void insert (int ID) {
      struct Soldier *s = new Soldier();
      s->ID = ID;

      if(this->output_list == NULL){// LIST IS EMPTY
        this->output_list = s;
        s->next = NULL;
      } else if(this->output_list->next == NULL){ // ONLY ONE ELEMENT IN LIST
        if(this->output_list->ID < s->ID){ // If head.age is less than age of element to be inserted
          this->output_list->next = s;
          s->next = NULL;
        } else {
          s->next = this->output_list;
          this->output_list = s;
        }
      } else { // MORE THAN ONE ELEMENT IN LIST

        struct Soldier* curr = this->output_list; // CURR POINTER TO TRAVERSE THE LIST AND FIND THE CORRECT POSITION
        struct Soldier* temp = this->output_list; // TEMP POINTER TO TRAIL BEHIND THE CURR POINTER (USED WHILE INSERTING IN BETWEEN THE LIST)

        if(this->output_list->ID > s->ID){ // CHECK IF NEW STUDENT'S AGE IS LESS THAN OR EQUAL TO HEAD'S AGE FIRST
          // INSERT ELEMENT
          s->next = this->output_list;
          this->output_list = s;
          return;
        }

        while (curr->next != NULL) {
          if (curr->ID > s->ID) {
            // INSERT ELEMENT;
            temp->next = s;
            s->next = curr;
            return;
          }
          temp = curr;
          curr = curr->next;
        }

        // LIST TRAVERSED BUT CORRECT POSITION NOT FOUND
        // THEN STUDENT'S AGE MUST BE LARGER THAN ALL AGES IN DATABASE

        //INSERT  ELEMENT
        if(curr->ID < s->ID){
          curr->next = s;
          s->next = NULL;
        } else {
          temp->next = s;
          s->next = curr;
        }
        return;
      }
    }
    void pop_soldiers () {
      int popped_soldiers_count = 0;
      int lift; // DECLARE LIFT VARIABLE TO RANDOMLY SELECT A LIFT VARIABLE
      while (popped_soldiers_count < this->n) { // RUN AS LONG AS ALL SOLDIERS HAVEN'T BEEN POPPED YET
        lift = rand() % (this->m); // LIFT CAN NOW TAKE RANDOM VALUES BETWEEN 0 AND m-1
        
        /**
         * WE ARE MAINTAINING M LIFT HEAD POINTERS ON THE BASE LINKED LIST.
         * 
         * EACH POINTER WILL POINT TO THE ID OF THE NEXT SOLDIER TO BE POPPED FROM ITS SPECIFIC LIFT.
         * 
         * IF ALL THE SOLDIERS HAVE BEEN POPPED FROM A SPECIFIC LIFT, THE POINTER WILL THEN 
         * POINT TO THE SOLDIER WITH THE HIGHEST ID IN THE NEXT LIFT.
         * 
         * THIS WILL CREATE SUCH A SITUATION THAT THE ID WILL BE EQUAL TO c TIMES THE 0-INDEXED ID OF THE CURRENT LIFT
         * WHICH WE CHECK IN THE BEGINNING OF THE WHILE LOOP. 
         * 
         * IF SUCH A CONDITION HOLDS, WE NEED TO GENERATE A NEW RANDOM NUMBER
         * BECAUSE THAT MEANS THE CURRENT LIFT IS EMPTY.
         **/
        while (this->lift_pointers[lift]->ID == (lift)*c) {
          lift = rand() %  (this->m);
        }
        
        // GET THE ID OF THE SOLDIER TO BE POPPED
        int id = this->lift_pointers[lift]->ID;
        // MOVE LIFT POINTER TO NEXT VALUE
        this->lift_pointers[lift] = this->lift_pointers[lift]->next;
        // INSERT ID OF THIS SOLDIER TO THE OUTPUT LIST (INSERTION SORT)
        insert(id);

        popped_soldiers_count++;
        cout << "S" << id; // PRINT SOLDIER ID (LIFT - 1) BECAUSE ARRAY IS ZERO INDEXED
        cout << " is popped from respective (random) Lift "; // PRINT POP MESSAGE
        cout << ++lift << "\n"; // PRINT LIFT NUMBER

        // PRINT THE CURRENT SORTED LIST 
        struct Soldier *curr = this->output_list;
        cout << "Final sorted list is: ";
        while (curr != NULL) {
          cout << "S" << curr->ID << " ";
          curr = curr->next;
        }
        cout << "\n";
      }
    }
};

int main() 
{
  // TAKE INPUT
  int n, m, c;
  cin>>n>>m>>c;

  // INITIALISE LIFTS AND BASE LINKED LIST IN CONSTRUCTOR
  Army army(n, m, c);
  cout << "\n";
  army.print_soldiers();
  cout << "\n";
  // POP BY TAKING RANDOM LIFT NUMBERS (DONE INSIDE METHOD)
  army.pop_soldiers();
  cout<<endl;
	return 0;
}
