/********************************************

	CSN-261 Lab 4 Question 3 : Ordered Brackets
	P1.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

********************************************/

#include <iostream>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

class StackClass {
  private:
    struct MyStack { // ONE NODE OF STACK
      char ch;
      struct MyStack* next;
    };
    struct MyStack* head; // HEAD NODE OF STACK FOR THIS CLASS 

  public:
    StackClass () {
      this->head = NULL; // INITIALISE HEAD TO NULL BECAUSE STACK IS EMPTY ON CREATION OF LIST
    }
    void push (char c) {
      struct MyStack *s = new MyStack(); // CREATE NEW NODE
      s->ch = c; // INITIALISE CHAR OF NEW NODE
      if (this->head == NULL) { // STACK IS EMPTY
        s->next = NULL;
      } else { // STACK IS NOT EMPTY
        s->next = this->head;
      }
      this->head = s; // MOBE HEAD POINTER TO TOP OF STACK
      return;
    } 

    char get_top () { // RETURNS TOP VALUE OF STACK, OR '0' IF STACK IS EMPTY
      return this->head == NULL ? '0' : this->head->ch;
    }

    void pop () { // REMOVE ELEMENT FROM TOP OF STACK (NO NEED TO CHECK IF STACK IS EMPTY, BECAUSE WE ALREADY CHECK USING get_top() BEFORE CALLING THIS)
      struct MyStack *s = this->head;
      this->head = this->head->next;
      delete s; //  MEMORY NO LONGER NEEDED
      return;
    }
};

string priority_error (char x, char y) {
  string s = "Error: Missing priority of ";
  if ((x == '[' && y == '{') || (x == '{' && y == '[')) {
    s += "[] and {}\n";
  } else if ((x == '[' && y == '(') || (y == '(' && x == '[')) {
    s += "[] and ()\n";
  } else {
    s += "() and {}\n";
  }
  return s;
}

string unbalanced_error (char x, char y) {
  string s = "";
  s += "Unbalanced ";
  s += x;
  s += " and "; 
  s += y;
  s += "\n";
  return s;
}

string unbalanced_error (char x) {
  string s = "";
  s += "Unbalanced ";
  s += x;
  s += "\n";
  return s;
}

string not_found_error (char x) {
  char y;
  switch (x) {
    case '(':
      y = ')';
      break;
    case '{':
      y = '}';
      break;
    case '[':
      y = ']';
    case ')':
      y = '(';
      break;
    case '}':
      y = '{';
      break;
    case ']':
      y = '[';
      break;
  }
  string s = "Error: Cannot find ";
  s += y;
  s += " corresponding to "; 
  s += x;
  s += "\n";
  return s;
}

int main() 
{
  string s; cin>>s; // TAKE INPUT
  int n = s.length(); // STORE LENGTH OF INPUT
  

  for (int i=0; i<n; i++) {
    // CHARACTER IS NOT ON OF {}, (), OR []
    if (!(s[i] == '{' || s[i] == '[' || s[i] == '(' || s[i] == '}' || s[i] == ']' || s[i] == ')')) {
      cout << "Invalid string, character " << s[i] << " not recognised!\n";
      return 0;
    } 
  }

  StackClass sc;
  
  bool priority_error_exists = false;
  string priority_error_string = "";
  bool unbalanced_error_exists = false;
  string unbalanced_error_string = "";
  bool not_found_error_exists = false;
  string not_found_error_string = "";

  for (int i=0; i<n; i++) {
    char prev = sc.get_top(); // CHECK PREVIOUS VALUE 
    if (s[i] == '[' || s[i] == '{' || s[i] == '(') { // OPENING BRACKET
      if (prev == '0') { // IF STACK EMPTY PUSH BRACKET TO STACK
        sc.push(s[i]);
      } else {
        switch (s[i]) { // CHECKING FOR PRIORITY ERROR, ELSE, PUSH TO STACK
          case '[': 
            if (prev != '[' && !priority_error_exists) { 
              priority_error_exists = true;
              priority_error_string = priority_error('[', prev);
            }
            break;
          case '{':
            if (prev == '(' && !priority_error_exists) { 
              priority_error_exists = true;
              priority_error_string = priority_error('{', '(');
            }
            break;
          case '(':
            break;
        }
        sc.push(s[i]);
      }
    } else { // CLOSING BRACKET FOUND
      switch (s[i]) { // STACK IS NOT EMPTY, SO THERE MUST HAVE BEEN AN OPENING BRACKET. WE MUST CHECK IF THE BRACKETS MATCH, ELSE, THROW A PRIORITY ERROR
        case ']':
          if (prev != '[') {
            if (prev == '0') { // IF STACK EMPTY, THEN THERE WAS NO OPENING BRACKET BUT THERE IS AN OPENING BRACKET
              if (!not_found_error_exists) {
                not_found_error_exists = true;
                not_found_error_string = not_found_error(s[i]);
              }
            } else { // STACK NOT EMPTY, BUT STILL VALUES DON'T MATCH
              if (!unbalanced_error_exists) {
                unbalanced_error_exists = true;
                unbalanced_error_string = unbalanced_error(prev, s[i]);
              }
              sc.pop();
            }
          } else {
            sc.pop();
          }
          break;
        case '}':
          if (prev != '{' ) {
            if (prev == '0') { // IF STACK EMPTY, THEN THERE WAS NO OPENING BRACKET BUT THERE IS AN OPENING BRACKET
              if (!not_found_error_exists) {
                not_found_error_exists = true;
                not_found_error_string = not_found_error(s[i]);
              }
            } else { // STACK NOT EMPTY, BUT STILL VALUES DON'T MATCH
              if (!unbalanced_error_exists) {
                unbalanced_error_exists = true;
                unbalanced_error_string = unbalanced_error(prev, s[i]);
              }
              sc.pop();
            }
          } else {
            sc.pop();
          }
          break;
        case ')':
          if (prev !='(') {
            if (prev == '0') { // IF STACK EMPTY, THEN THERE WAS NO OPENING BRACKET BUT THERE IS AN OPENING BRACKET
              if (!not_found_error_exists) {
                not_found_error_exists = true;
                not_found_error_string = not_found_error(s[i]);
              }
            } else { // STACK NOT EMPTY, BUT STILL VALUES DON'T MATCH
              if (!unbalanced_error_exists) {
                unbalanced_error_exists = true;
                unbalanced_error_string = unbalanced_error(prev, s[i]);
              }
              sc.pop();
            }
          } else {
            sc.pop();
          }
          break;
      }
    }
  }

  if (sc.get_top() != '0') {
    not_found_error_exists = true;
    not_found_error_string = not_found_error(sc.get_top());
  }

  if (unbalanced_error_exists) {
    cout << unbalanced_error_string;
  }
  if (priority_error_exists) {
    cout << priority_error_string;
  }
  if (!unbalanced_error_exists && not_found_error_exists) {
    cout << not_found_error_string;
  }
  if ( !(not_found_error_exists || unbalanced_error_exists || priority_error_exists) ) {
    cout << "Valid String!\n";
  }
	return 0;
}
