This code was successfully tested on Codechef IDE on C++ 17
Please refer to the sample input file to see input format 
(It is the same as that given in the lab assignment sample, except the number of rows in the plane needs to be provided)
