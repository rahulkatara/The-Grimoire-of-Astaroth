/**********************************************

	CSN-261 Lab 3 Question 1 : Passenger Airplane
	P1.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************************/

#include <iostream>
using namespace std;

// AIRPLANE CLASS
class Airplane {
private:
	struct Passenger {
		string id;
		struct Passenger* next;
	};
	struct Seat {
		string passenger_id;
		char seat;
		bool is_occupied;
		struct Seat* next;
	};
	int number_of_rows;
	int passenger_count;
	struct Passenger* head; // HEAD OF PASSENGER LINKED LIST 
	struct Seat* seat_map[10][2]; // SEAT MAP
public:
	Airplane (int n) {
		// INITIALISE PASSENGER LIST HEAD 
		head = NULL;
		number_of_rows = n;
		passenger_count = 0;

		// INITIALISE SEAT MAP WITH INITIAL VALUES
		for (int i=0; i<n; i++) {
			this->seat_map[i][0] = new Seat();
			this->seat_map[i][0]->passenger_id = "0"; // RANDOM STRING ASSIGNED BECAUSE IF I KEEP IT EMPTY IT GIVES A SEGMENTATION ERROR
			this->seat_map[i][0]->is_occupied = false; // INITIALLY SEAT IS EMPTY
			this->seat_map[i][0]->seat = 'C'; // AISLE SEAT C ON LEFT SIDE

			this->seat_map[i][0]->next = new Seat();
			this->seat_map[i][0]->next->passenger_id = "0";
			this->seat_map[i][0]->next->is_occupied = false;
			this->seat_map[i][0]->next->seat = 'B'; // MIDDLE SEAT B ON LEFT SIDE

			this->seat_map[i][0]->next->next = new Seat();
			this->seat_map[i][0]->next->next->passenger_id = "0";
			this->seat_map[i][0]->next->next->is_occupied = false;
			this->seat_map[i][0]->next->next->seat = 'A'; // WINDOW SEAT A ON LEFT SIDE
			this->seat_map[i][0]->next->next->next = NULL; //NOTHING COMES AFTER THE WINDOW SEAT
      

			this->seat_map[i][1] = new Seat();
			this->seat_map[i][1]->passenger_id = "0";
			this->seat_map[i][1]->is_occupied = false;
			this->seat_map[i][1]->seat = 'F'; // AISLE SEAT F ON RIGHT SIDE

			this->seat_map[i][1]->next = new Seat();
			this->seat_map[i][1]->next->passenger_id = "0";
			this->seat_map[i][1]->next->is_occupied = false;
			this->seat_map[i][1]->next->seat = 'E'; // MIDDLE SEAT E ON RIGHT SIDE

			this->seat_map[i][1]->next->next = new Seat();
			this->seat_map[i][1]->next->next->passenger_id = "0";
			this->seat_map[i][1]->next->next->is_occupied = false;
			this->seat_map[i][1]->next->next->seat = 'D'; // WINDOW SEAT D ON RIGHT SIDE
      this->seat_map[i][1]->next->next->next = NULL; //NOTHING COMES AFTER THE WINDOW SEAT
		}
	}

	bool isFull () {
		return this->passenger_count == this->number_of_rows * 6;
	}

	bool isEmpty () {
		return this->passenger_count == 0;
	}

  /**
   * NO OTHER PASSENGER ON THE PLANE MUST HAVE THE SAME ID  
   * ITERATE THROUGH THE PASSENGERS LINKED LIST TO FIND MATCHING ID  
   * IF NO MATCH FOUND, THEN VALID ID
   **/
	bool validateID (string id) {
		if (this->head == NULL) return true;
		struct Passenger *curr = this->head;
		do {
			if (curr->id == id) return false;
			curr = curr->next;
		} while (curr != NULL);
		return true;
	}

  /**
   * Checks whether seat number is valid or not
   * Returns true if it's a character between 'A' and 'F' inclusive, else false
   **/
	bool validateSeatNumber (string seat) {
		if (seat.length() != 1) return false;
		if (seat[0]<'A' || seat[0]>'F') return false;
		return true;
	}

  // ROW NUMBER MUST BE BETWEEN 1 AND N
	bool validateRowNumber (int row) {
		return ((row <= this->number_of_rows) && (row > 0));
	}

  // TRAVERSES LINKED LIST OF PASSENGERS TILL THE LAST NODE AND INSERTS NEW PASSENGER AT THE END
	void add_passenger_to_list (string id) {
		struct Passenger *p = new Passenger(); // CREATE NEW PASSENGER
		p->next = NULL; // SINCE IT WILL BE THE LAST NODE, NEXT NODE WOULD BE NULL
		p->id = id; // POPULATE ID OF PASSENGER
		if (this->head == NULL) { // PLANE CURRENTLY EMPTY
			this->head = p;
		} else { // PEOPLE ARE ALREADY PRESENT ON THE PLANE
			struct Passenger *curr = this->head;
			while (curr->next != NULL) {
				curr = curr->next;
			}
			curr->next = p;
		}
    return;
	}

  /**
   * Finds the node with the matching passenger ID and removes them from the list
   * We know for sure that the passenger exists in the link, because this function is only called
   * when the passenger id that the user inputs in E2 is the same as that of the person sitting on the seat.
   **/ 
  void remove_passenger_from_list (string id) {
    // EXITING PASSENGER IS THE HEAD NODE
    if (this->head->id == id) { 
      struct Passenger *t = this->head->next;
      delete this->head;
      this->head = t;
      return;
    }

    //EXITING PASSENGER IS NOT THE HEAD NODE
    struct Passenger *p = this->head;
    struct Passenger *t = this->head;

    do {
      if (p->id == id) {
        t->next = p->next;
        delete p;
        break;
      }
      t = p;
      p = p->next;
    } while (p != NULL);
	}

	/**
	 * First verifies if passenger is has valid id, row and seat number, 
	 * and then checks if seat is available, and finally inserts passenger.
	 *
	 * Returns:
	 *	 1 if passenger successfully inserted
	 *	-1 if row number invalid
	 *	-2 if seat number​ invalid
	 *	-3 if id invalid
	 *	-4 if seat is already taken by another passenger
	 **/
	int passenger_entry (string id, int row, string seat_string) {

		// CHECK IF ROW NUMBER IS VALID
		if (!(this->validateRowNumber(row))) {
			// RETURN -1 BECAUSE ROW NUMBER IS INVALID
			return -1;
		}

		// CHECK IF SEAT NUMBER IS VALID
		if (!(this->validateSeatNumber(seat_string))) {
			// RETURN -2 BECAUSE DEAT NUMBER IS INVALID
			return -2;
		}

		// CHECK IF PASSENGER EXISTS ON PLANE OR NOT
		if (!(this->validateID(id))) {
			// RETURN -3 BECAUSE PASSENGER WITH THIS ID ALREADY EXISTS
			return -3;
		}

		row--; // DECREMENT ROW BY ONE BECAUSE ARRAY IS ZERO-INDEXED
		char seat = seat_string[0]; // CONVERT SEAT ID FROM STRING TO CHAR

		// GET CORRECT SIDE OF AISLE : 0 FOR LEFT, 1 FOR RIGHT
		int side = (seat <= 'C') ? 0 : 1;

		// row->head is the pointer to the AISLE SEAT on the given side of the given row (top of stack)
		struct Seat *row_head = this->seat_map[row][side];
		
		// cout << row_head->passenger_id << " " << row_head->seat << " " << row_head->is_occupied ;
		int seat_number;

		if (seat <= 'C') {
			seat_number = 'C' - seat;
		} else {
			seat_number = 'F' - seat;
		}

		/**
		 * For EACH SIDE in EACH ROW:
		 * row->head             is the pointer to the AISLE SEAT
		 * row->head->next       is the pointer to the MIDDLE SEAT
		 * row->head->next->next is the pointer to the WINDOW SEAT
		 * 
		 * For switch (seat_number):
		 * case 0 : Passenger needs to be seated on the AISLE SEAT
		 * case 1 : Passenger needs to be seated on the MIDDLE SEAT
		 * case 2 : Passenger needs to be seated on the WINDOW SEAT
		 **/
		string output = "";
		
		switch (seat_number) {
			case 0:
				// IF AISLE SEAT (DESIRED SEAT) IS NOT EMPTY, WE CANNOT ASSIGN THAT SPOT TO THE CURRENT PASSENGER
				if (row_head->is_occupied) return -4; 

				// SINCE AISLE SEAT IS EMPTY, ASSIGN THAT SEAT TO THE CURRENT PASSENGER
				row_head->passenger_id = id;
				row_head->is_occupied = true;
				cout << "\n" << "Push " << id << "\n";
					
				// ADD PASSENGER TO LIST SO I KNOW WHO ARE ON BOARD
				this->add_passenger_to_list(id);

				// INCREMENT PASSENGER COUNT
				this->passenger_count++;
				break;
			case 1:
				// IF MIDDLE SEAT (DESIRED SEAT) IS NOT EMPTY, WE CANNOT ASSIGN THAT SPOT TO THE CURRENT PASSENGER
				if (row_head->next->is_occupied) return -4;

				// IF AISLE SEAT IS NOT EMPTY POP THAT PASSENGER
				if (row_head->is_occupied) output += "Pop " + row_head->passenger_id + "\n";

				// SINCE MIDDLE SEAT IS EMPTY, ASSIGN THAT SEAT TO THE CURRENT PASSENGER
				row_head->next->passenger_id = id;
				row_head->next->is_occupied = true;
				output += "Push " + row_head->next->passenger_id + "\n";

				// ADD PASSENGER TO LIST SO I KNOW WHO ARE ON BOARD
				this->add_passenger_to_list(id);

				// INCREMENT PASSENGER COUNT 
				this->passenger_count++;

				// IF WE HAD POPPED THE PASSENGER ON THE AISLE SEAT, PUSH THEM BACK IN
				if (row_head->is_occupied) output += "Push " + row_head->passenger_id + "\n";

				// PRINT OUT THE FINAL OUTPUT MESSAGE
				cout << output;
				break;
			case 2:
				// IF WINDOW SEAT (DESIRED SEAT) IS NOT EMPTY, WE CANNOT ASSIGN THAT SPOT TO THE CURRENT PASSENGER
				if (row_head->next->next->is_occupied) return -4;

				// IF AISLE SEAT IS NOT EMPTY POP THAT PASSENGER
				if (row_head->is_occupied) output += "Pop " + row_head->passenger_id + "\n";
				// IF MIDDLE SEAT IS NOT EMPTY, POP THAT PASSENGER
				if (row_head->next->is_occupied) output += "Pop " + row_head->next->passenger_id + "\n";

				// SINCE WINDOW SEAT IS EMPTY, ASSIGN THAT SEAT TO THE CURRENT PASSENGER
				row_head->next->next->passenger_id  = id;
				row_head->next->next->is_occupied = true;

				// ADD PASSENGER TO LIST SO I KNOW WHO ARE ON BOARD
				this->add_passenger_to_list(id);		
				
        output += "Push " + id + "\n";
				
				// INCREMENT PASSENGER COUNT
				this->passenger_count++;
				// IF WE HAD POPPED THE PASSENGER ON THE MIDDLE SEAT, PUSH THEM BACK IN
				if (row_head->next->is_occupied) output += "Push " + row_head->next->passenger_id + "\n";
				// IF WE HAD POPPED THE PASSENGER ON THE AISLE SEAT, PUSH THEM BACK IN
				if (row_head->is_occupied) output += "Push " + row_head->passenger_id + "\n";

				// PRINT OUT THE FINAL OUTPUT MESSAGE
				cout << output << "\n";
				break;
		}	
		return 1;
	}


	/**
	 * First verifies if seat number and row number are valid 
	 * If the called passenger is sitting at the seat, then it pops it, 
	 * otherwise returns an error value
	 * 
	 * Returns:
	 * 	 1 if passenger successfully popped
	 * 	-1 if row number invalid
	 * 	-2 if seat number​ invalid
	 * 	-3 if the passenger with the given is not sitting on the given seat
	 **/
	int passenger_exit (string id, int row, string seat_string) {
		
		// CHECK IF ROW NUMBER IS VALID
		if (!this->validateRowNumber(row)) {
			// RETURN -1 BECAUSE ID IS INVALID
			return -1;
		}

		// CHECK IF SEAT NUMBER IS VALID
		if (!this->validateSeatNumber(seat_string)) {
			// RETURN -2 BECAUSE ID IS INVALID
			return -2;
		}

		row--; // DECREMENT ROW BY ONE BECAUSE ARRAY IS ZERO-INDEXED
		char seat = seat_string[0]; // CONVERT SEAT ID FROM STRING TO CHAR

		// GET CORRECT SIDE OF AISLE : 0 FOR LEFT, 1 FOR RIGHT
		int side = seat <= 'C' ? 0 : 1;

		//row->head is the pointer to the AISLE SEAT on the given side of the given row (top of stack)
		struct Seat* row_head = this->seat_map[row][side];

		int seat_number;

		if (seat <= 'C') {
			seat_number = 'C' - seat;
		} else {
			seat_number = 'F' - seat;
		}

		/**
		 * For EACH SIDE in EACH ROW:
		 * row->head             is the pointer to the AISLE SEAT
		 * row->head->next       is the pointer to the MIDDLE SEAT
		 * row->head->next->next is the pointer to the WINDOW SEAT
		 * 
		 * For switch (seat_number):
		 * case 0 : Passenger needs to be seated on the AISLE SEAT
		 * case 1 : Passenger needs to be seated on the MIDDLE SEAT
		 * case 2 : Passenger needs to be seated on the WINDOW SEAT
		 **/
		string output = "";
		switch (seat_number) {
			case 0:
        // IF AISLE SEAT IS EMPTY OR SOMEONE ELSE IS SITTING HERE, RETURN -3
				if (!row_head->is_occupied) return -3;
        if (row_head->passenger_id != id) return -3;

        // SINCE ABOVE TWO TESTS PASSED, THE CORRECT PERSON MUST BE SITTING IN THE SEAT, AND WE NEED TO POP HIM.
        this->remove_passenger_from_list(id);
        cout << "Pop " << id <<"\n";

        // REPLACE CHARACTERISTIC VALUES OF CURRENT SEAT WITH INITIAL VALUES SO IT WILL BE EMPTY IN THE NEXT ITERATION
        row_head->is_occupied = false;
        row_head->passenger_id = "0";
				break;
			case 1:
				// IF MIDDLE SEAT IS EMPTY OR SOMEONE ELSE IS SITTING HERE, RETURN -3
				if (!row_head->next->is_occupied) return -3;
        if (row_head->next->passenger_id != id) return -3;

        // IF AISLE SEAT IS OCCUPIED, POP THAT PERSON FIRST.
        if (row_head->is_occupied) output += "Pop " + row_head->passenger_id + "\n";

        // SINCE ABOVE TWO TESTS PASSED, THE CORRECT PERSON MUST BE SITTING IN THE SEAT, AND WE NEED TO POP HIM.
        this->remove_passenger_from_list(id);
        output += "Pop " + id + "\n";

        // IF AISLE SEAT WAS POPPED, PUSH THAT PERSON BACK IN.
        if (row_head->is_occupied) output += "Push " + row_head->passenger_id + "\n";

        // REPLACE CHARACTERISTIC VALUES OF CURRENT SEAT WITH INITIAL VALUES SO IT WILL BE EMPTY IN THE NEXT ITERATION
        row_head->next->is_occupied = false;
        row_head->next->passenger_id = "0";

        //PRINT OUT FINAL OUTPUT
        cout << output << "\n";
				break;
			case 2:
				// IF MIDDLE SEAT IS EMPTY OR SOMEONE ELSE IS SITTING HERE, RETURN -3
				if (!row_head->next->next->is_occupied) return -3;
        if (row_head->next->next->passenger_id != id) return -3;

        // IF AISLE SEAT IS OCCUPIED, POP THAT PERSON FIRST.
        if (row_head->is_occupied) output += "Pop " + row_head->passenger_id + "\n";

        // IF MIDDLE SEAT IS OCCUPIED, POP THAT PERSON TOO.
        if (row_head->next->is_occupied) output += "Pop " + row_head->next->passenger_id + "\n";

        // SINCE ABOVE TWO TESTS PASSED, THE CORRECT PERSON MUST BE SITTING IN THE SEAT, AND WE NEED TO POP HIM.
        this->remove_passenger_from_list(id);
        output += "Pop " + id + "\n";

        // IF MIDDLE SEAT WAS POPPED, PUSH THAT PERSON BACK IN.
        if (row_head->next->is_occupied) output += "Push " + row_head->next->passenger_id + "\n";
        // IF AISLE SEAT WAS POPPED, PUSH THAT PERSON BACK IN.
        if (row_head->is_occupied) output += "Push " + row_head->passenger_id + "\n";


        // REPLACE CHARACTERISTIC VALUES OF CURRENT SEAT WITH INITIAL VALUES SO IT WILL BE EMPTY IN THE NEXT ITERATION
        row_head->next->next->is_occupied = false;
        row_head->next->next->passenger_id = "0";

        //PRINT FINAL OUTPUT
        cout << output << "\n";
				break;
		}	
		return 1;
	}

  /**
   * Method to print out the seat name with appropriate number 
   * of spaces to make output of P pleasant to read
   **/
  void print_seat (string seat) {
    cout << seat;
    int spaces = 5 - seat.length();
    while (spaces--) cout << " ";
  }
  
  /**
   * Print 0 in place of seat if it is empty
   * Print passenger id in place of seat if it is occupied
   **/
  void print_plane () {
    struct Seat *seat;
    cout << "\nFlight occupancy status is\n";
    cout << "\n        A    B    C          F    E    D\n";
    for (int row=1; row<=this->number_of_rows; row++) {
      cout << "Row " << row << ":  ";
      
      // GET LEFT SIDE SEAT POINTER FIRST
      seat = this->seat_map[row-1][0]; 
      // WINDOW SEAT ON LEFT SIDE
      if (seat->next->next->is_occupied) this->print_seat(seat->next->next->passenger_id);
      else this->print_seat("0");
      // MIDDLE SEAT ON LEFT SIDE
      if (seat->next->is_occupied) this->print_seat(seat->next->passenger_id);
      else this->print_seat("0");
      // AISLE SEAT ON LEFT SIDE
      if (seat->is_occupied) this->print_seat(seat->passenger_id);
      else this->print_seat("0");

      // AISLE IN BETWEEN
      cout << "||    ";

      // GET RIGHT SIDE SEAT POINTER FIRST
      seat = this->seat_map[row-1][1];
      
      // AISLE SEAT ON RIGHT SIDE
      if (seat->is_occupied) this->print_seat(seat->passenger_id);
      else this->print_seat("0");
      // MIDDLE SEAT ON RIGHT SIDE
      if (seat->next->is_occupied) this->print_seat(seat->next->passenger_id);
      else this->print_seat("0");
      // WINDOW SEAT ON RIGHT SIDE
      if (seat->next->next->is_occupied) this->print_seat(seat->next->next->passenger_id);
      else this->print_seat("0");
      
      //NEXT LINE
      cout << "\n";
    }
    cout << "\n";
  }

  /**
   * Pop out passengers from front row to back row
   * First left side then right side of each row
   **/
  void full_exit () {
    cout << "\nThe LIFO order of passengers is:\n";
    struct Seat *seat;
    for (int i=0; i<this->number_of_rows; i++) {
      seat = this->seat_map[i][0]; // POP OUT LEFT SIDE PEOPLE FIRST
      
      for (int j=0; j<3; j++) { // ITERATE THROUGH LIST TO POP OUT FIRST AISLE, THEN MIDDLE, THEN WINDOW PERSON
        if (seat->is_occupied) {
          cout << "Pop " << seat->passenger_id << "\n";
          this->remove_passenger_from_list(seat->passenger_id);
          
          // SET DEFAULTS TO REGENRATE EMPTY AIRPLANE
          seat->is_occupied = false;
          seat->passenger_id = "0";
        }
        seat = seat->next;
      }

      seat = this->seat_map[i][1]; // POP OUT RIGHT SIDE PEOPLE SECOND
      
      for (int j=0; j<3; j++) { // ITERATE THROUGH LIST TO POP OUT FIRST AISLE, THEN MIDDLE, THEN WINDOW PERSON
        if (seat->is_occupied) {
          cout << "Pop " << seat->passenger_id << "\n";
          this->remove_passenger_from_list(seat->passenger_id);
          
          // SET DEFAULTS TO REGENRATE EMPTY AIRPLANE
          seat->is_occupied = false;
          seat->passenger_id = "0";
        }
        seat = seat->next;
      }
    }
  }
};

int main() 
{

	// ENTER NUMBER OF ROWS IN AIRPLANE
	int n; 
	cin>>n;

	// INITIALIZE AIRPLANE
	Airplane airplane(n);

	while (true) {
		// INITIALISE INPUT VARIABLES
		bool wrong_input = false;
		string input;

		// Take choice input
		string choice;
		do {
			// PRINT ERROR TEXT
			if (wrong_input) cout << "\nPlease enter a valid choice!\n";

			// PRINT INPUT MESSAGE
			// cout << "\nEnter your choice:\n";
			// cout << "\tE1 for Passenger Entry\n";
			// cout << "\tE2 for Passenger Exit\n";
			// cout << "\tE for Program Exit\n";
			// cout << "\tP for Print\n";
			// cout << "\tX for Full Exit: ";

			// TAKE VALUE OF INPUT
			cin >> input;

			// VALIDATE INPUT CHOICE SO CODE DOESN'T BREAK
			if (input != "E1" && input != "E2" && input != "E" && input != "P" && input != "X") {
				wrong_input = true;
			} else {
				wrong_input = false;
				choice = input;
			}
		} while (wrong_input);

		// EXIT PROGRAM
		if (choice == "E") {
      cout << "\nThe program is stopped\n";
			break;
		}

		// PASSENGER ENTRY
		if (choice == "E1") {
			// CHECK IF PLANE IS FULL
			if ( airplane.isFull() ) {
				cout << "The airplane is already full!";
				continue;
			}

			// cout<<("​Enter ​passenger ID, boarding ​row number​ and ​seat number​: ​");

			// INITIALIZE VARIABLES FOR PASSENGER ID, ROW NUMBER AND SEAT NUMBER
			string id, seat;
			int row;
			
			// TAKE INPUT
			cin >> id >> row >> seat;
			int ret = airplane.passenger_entry(id, row, seat);
			switch (ret) {
				case -1:
				 cout << "\nRow number invalid. It must be an integer between 1 and " << to_string(n) << "\n";
					break;
				case -2:
					cout << "\nSeat number invalid. It must be a character between A and F" << "\n";
					break;
				case -3:
					cout << "\nThere is already a passenger on this plane with the same ID" << "\n";
					break;
				case -4:
					cout << "\nThe seat is currently taken by someone else" << "\n";
					break;
				default:
					cout << "\n";
					break;
			}
		}
		if (choice == "E2") {
			// CHECK IF PLANE IS EMPTY
			if ( airplane.isEmpty() ) {
				cout << "\nThe airplane is already empty!\n";
				continue;
			}

			// cout << "\n​Enter ​passenger ID, boarding ​row number​ and ​seat number​: ​";

			// INITIALIZE VARIABLES FOR PASSENGER ID, ROW NUMBER AND SEAT NUMBER
			string id, seat;
			int row;
			
			// TAKE INPUT
			cin >> id >> row >> seat;
			int ret = airplane.passenger_exit(id, row, seat);
      switch (ret) {
        case -1:
					cout << "\nRow number invalid. It must be an integer between 1 and " << to_string(n) << "\n";
					break;
				case -2:
					cout << "\nSeat number invalid. It must be a character between A and F" << "\n";
					break;
				case -3:
					cout << "\nThe person with id " + id + " is not sitting in the given seat!" << "\n";
					break;
        default:
          cout << "\n";
          break;
      }
		}
    if (choice == "P") {
      airplane.print_plane();
    }
    if (choice == "X") {
      if ( airplane.isEmpty() ) {
				cout << "\nThe airplane is already empty!\n";
				continue;
			}
      airplane.full_exit();
    }
	}
}