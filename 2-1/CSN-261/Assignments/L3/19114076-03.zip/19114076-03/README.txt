This code was tested using Codechef Online IDE - C++17 (Gcc 9.1)

https://www.codechef.com/ide
