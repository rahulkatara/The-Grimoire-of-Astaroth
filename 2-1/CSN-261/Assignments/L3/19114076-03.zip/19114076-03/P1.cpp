// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

/**
 * Structure:
 * - Struct Seat: The base level abstraction that reflects a seat in a plane
 * - Class Row: This class has 2 linked lists of 3 seats each reflecting the left and right aisles of a plane
 * - Class Plane: Has an array of Rows
 * - Class UtilityStack: A temporary storage location for the passengers that are "popped" during the traversal of linked list
 * 
 * Logic:
 * - Whenever a linked list is traversed for insertion / deletion of any element, the preceding elements are pushed into a stack and deleted from the linked list
 * - After the operation is completed, the stack is emptied, popping its elements back to the linked list.
 * 
*/

#include <iostream>
using namespace std;

struct Seat{

    string passenger_id;
    char seat_number;
    Seat *next = NULL;

};

// A utility function to make linked lists from seats dynamically
Seat *make_row(char side){

    Seat *head = NULL;
    for(int i = 0; i < 3; i++){
        Seat *x = new Seat();
        x->seat_number = (side == 'L') ? (char)('A'+i) : (char)('D'+i);
        x->next = head;
        head = x;
    }
    return head;

};

class UtilityStack{

    public:
    Seat *head;
    UtilityStack(){
        head = NULL;
    }

    void push(string passenger_id, char seat_number){

        Seat *x = new Seat();
        x->next = head;
        x->passenger_id = passenger_id;
        x->seat_number = seat_number;
        head = x;

    }

    Seat *pop(){

        Seat *x = head;
        head = head->next;
        return x;

    }

};

class Row{

    Seat *left, *right;
    UtilityStack buffer;

    public:
    Row(){

        left = make_row('L');
        right = make_row('R');

        buffer = *(new UtilityStack);

    }

    // Empty the utility stack and push the elements back into the linked list
    void empty_stack(){

        Seat *x;
        while(buffer.head!=NULL){
            x = buffer.pop();
            Seat *itr = (x->seat_number<='C') ? left : right;
            while(itr->seat_number!=x->seat_number) itr = itr->next;
            itr->passenger_id = x->passenger_id;
            cout<<"Push "<<x->passenger_id<<endl;
            delete(x);
        }

    }

    // Push a passenger into the linked list
    void passenger_entry(string passenger_id, char seat_number){

        Seat *itr;
        buffer.head = NULL;

        if(seat_number=='A' || seat_number=='B' || seat_number=='C'){
            itr = left;
        }else if(seat_number=='D' || seat_number=='E' || seat_number=='F'){
            itr = right;
        }else{
            cout<<"Invalid seat number."<<endl;
            return;
        }

        while(itr!=NULL && itr->seat_number!=seat_number){
            if(itr->passenger_id!=""){
                buffer.push(itr->passenger_id, itr->seat_number);
                cout<<"Pop "<<itr->passenger_id<<endl;
                itr->passenger_id="";
            }
            itr = itr->next;
        }
        
        if(itr->passenger_id!=""){
            cout<<"Error: Seat already occupied."<<endl;
        }else{
            itr->passenger_id=passenger_id;
            cout<<"Push "<<passenger_id<<endl;
        }

        empty_stack();

    }

    // Delete a passenger from the linked list
    void passenger_exit(string passenger_id, char seat_number){

        Seat *itr;
        buffer.head = NULL;

        if(seat_number=='A' || seat_number=='B' || seat_number=='C'){
            itr = left;
        }else if(seat_number=='D' || seat_number=='E' || seat_number=='F'){
            itr = right;
        }else{
            cout<<"Invalid seat number."<<endl;
            return;
        }

        while(itr!=NULL && itr->seat_number!=seat_number){
            if(itr->passenger_id!=""){
                buffer.push(itr->passenger_id, itr->seat_number);
                cout<<"Pop "<<itr->passenger_id<<endl;
                itr->passenger_id="";
            }
            itr = itr->next;
        }

        if(itr->passenger_id!=passenger_id){
            cout<<"The given passenger is not sitting on the given seat."<<endl;
        }else{
            itr->passenger_id="";
            cout<<"Pop "<<passenger_id<<endl;
        }

        empty_stack();

    }

    // Print the contents of both the linked lists
    void print(){

        string s = "";

        Seat *itr = left;
        while(itr!=NULL){
            if(itr->passenger_id.empty()){
                s = "0    " + s;
            }else{
                s = itr->passenger_id + "   " + s;
            }
            itr = itr->next;
        }

        itr = right;
        s = s + "||    ";
        while(itr!=NULL){
            if(itr->passenger_id.empty()){
                s = s + "0    ";
            }else{
                s = s + itr->passenger_id + "   ";
            }
            itr = itr->next;
        }

        cout<<s<<endl;

    }

    // Empty both the linked lists
    void full_exit(){

        Seat *itr = left;
        while(itr!=NULL){
            if(itr->passenger_id!=""){
                cout<<"Pop "<<itr->passenger_id<<endl;
                itr->passenger_id = "";
            }
            itr = itr->next;
        }

        itr = right;
        while(itr!=NULL){
            if(itr->passenger_id!=""){
                cout<<"Pop "<<itr->passenger_id<<endl;
                itr->passenger_id = "";
            }
            itr = itr->next;
        }

    }

};

class Plane{

    int n;
    Row *Rows;

    public:
    Plane(int n){
        this->n = n;
        Rows = new Row[n];
    }

    // Push a passenger into a row
    void passenger_entry(string passenger_id, int row_number, char seat_number){

        if(row_number < 0 || row_number >= n){
            cout<<"Invalid Row"<<endl;
            return;
        }else{
            Rows[row_number].passenger_entry(passenger_id, seat_number);
        }

    }

    // Delete a passenger from a row
    void passenger_exit(string passenger_id, int row_number, char seat_number){

        if(row_number < 0 || row_number >= n){
            cout<<"Invalid Row"<<endl;
            return;
        }else{
            Rows[row_number].passenger_exit(passenger_id, seat_number);
        }

    }

    // Print the contents of all the rows
    void print(){

        cout<<"Flight occupancy status is: "<<endl;
        cout<<"      A    B    C    ||    F    E    D"<<endl;
        for(int i = 0; i < n; i++){
            cout<<"Row"<<(i+1)<<": ";
            Rows[i].print();
        }
        cout<<"---------------------------------------"<<endl;

    }

    // Empty all the rows
    void full_exit(){

        cout<<"The LIFO order of passengers is: "<<endl;
        for(int i = 0; i < n; i++){
            Rows[i].full_exit();
        }

    }

};

int main(){
    
    // Driver Code
    int n; // Number of rows
    // cout<<"Please enter the number of rows: ";
    // Input: n
    cin>>n;

    Plane my_plane = *(new Plane(n));

    // Get input loop
    while(true){

        // cout<<"Enter your choice\n    E1 for Passenger Entry\n    E2 for Passenger Exit\n    E for Program Exit\n    P for Print\n    X for Full Exit: ";
        string choice;
        // Input: choice
        cin>>choice;

        string passenger_id;
        int row_number;
        char seat_number;

        if(choice == "E1"){

            // cout<<"Enter passenger ID, boarding row number and Seat number: ";
            // Input: passenger_id, row_number, seat_number
            cin>>passenger_id>>row_number>>seat_number;
            my_plane.passenger_entry(passenger_id, row_number-1, seat_number);

        }else if(choice == "E2"){

            // cout<<"Enter passenger ID, boarding row number and Seat number: ";
            // Input: passenger_id, row_number, seat_number
            cin>>passenger_id>>row_number>>seat_number;
            my_plane.passenger_exit(passenger_id, row_number-1, seat_number);

        }else if(choice == "E"){

            cout<<"Program is Stopped."<<endl;
            break;

        }else if(choice == "P"){

            my_plane.print();

        }else if(choice == "X"){

            my_plane.full_exit();

        }else{

            cout<<"Invalid Choice."<<endl;
            continue;

        }

    }

    return 0;
}