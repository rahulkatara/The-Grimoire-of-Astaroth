#include <iostream>
using namespace std;

int MAX_CAPACITY = 60;

// Function for the entry of passengers 
void entry(string seats[][6],string idPassenger,int row,char seat,int &numPassengers){
	int x=(int)(seat-'A');
	
	// Check if another passenger already has the seat occupied 
	if(seats[row-1][x]!="0"){
		cout<<"Error! A passenger already exists on the given seat number at the given row.\n";
		return;
	}
    
    // Check if the seat is A/B/C 
	if(x<3){
		for(int i=2;i>x;i--){
			if(seats[row-1][i]!="0"){
				cout<<"Pop "<<seats[row-1][i]<<"\n";
			}
		}
		seats[row-1][x]=idPassenger;
		for(int i=x;i<3;i++){
			if(seats[row-1][i]!="0"){
				cout<<"Push "<<seats[row-1][i]<<"\n";
			}
		}
	}
	// Check if the seat is D/E/F
	else if(x>=3){
		x=8-x;
		for(int i=3;i<x;i++){
			if(seats[row-1][i]!="0"){
				cout<<"Pop "<<seats[row-1][i]<<"\n";
			}
		}
		seats[row-1][x]=idPassenger;
		for(int i=x;i>=3;i--){
			if(seats[row-1][i]!="0"){
				cout<<"Push "<<seats[row-1][i]<<"\n";
			}
		}
	}
	numPassengers++;
}

// Function for exit of a pasenger
void exit(string seats[][6],string idPassenger,int row,char seat,int &numPassengers){
	int x=(int)(seat-'A');
	
	// Check if the specified seat is empty
	if(seats[row-1][x]=="0"){
		cout<<"Error! No passenger exists on the given seat number at the given row.\n";
		return;
	}
	
	// Check if the passengers' ids differ
	if(seats[row-1][x]!=idPassenger){
		cout<<"Error! The passenger ID of the passenger on the given seat number at the given row doesn't match the given passenger ID.\n";
		return;
	}

    // Check if the seat is A/B/C 
	if(x<3){
		for(int i=2;i>=x;i--){
			if(seats[row-1][i]!="0"){
				cout<<"Pop "<<seats[row-1][i]<<"\n";
			}
		}
		seats[row-1][x]="0";
		for(int i=x+1;i<3;i++){
			if(seats[row-1][i]!="0"){
				cout<<"Push "<<seats[row-1][i]<<"\n";
			}
		}
	}	
	// Check if the seat is D/E/F
	else if(x>=3){
		x=8-x;
		for(int i=3;i<=x;i++){
			if(seats[row-1][i]!="0"){
				cout<<"Pop "<<seats[row-1][i]<<"\n";
			}
		}
		seats[row-1][x]="0";
		for(int i=x-1;i>=3;i--){
			if(seats[row-1][i]!="0"){
				cout<<"Push "<<seats[row-1][i]<<"\n";
			}
		}
	}
	numPassengers--;
}

// Function to print the occupancy status of the plane's seats
void display(string seats[][6],int numRows){
    
	cout<<"\tA\tB\tC\t||\tF\tE\tD\n";
	
	for(int i=0;i<numRows;i++){
		cout<<"Row"<<(i+1)<<":  ";
		for(int j=0;j<3;j++){
			cout<<seats[i][j]<<"\t";
		}
		cout<<"||\t";
		for(int j=3;j<6;j++){
			cout<<seats[i][j]<<"\t";
		}
		cout<<"\n";
	}
	cout<<"-----------------------------------------------------------\n";
}


// Function to make all the passengers exit the plane
void completeExit(string seats[][6],int numRows){
	for(int i=0;i<numRows;i++){
		for(int j=2;j>=0;j--){
			if(seats[i][j]!="0"){
				cout<<"Pop "<<seats[i][j]<<"\n";
				seats[i][j]="0";
			}
		}
		for(int j=3;j<=5;j++){
			if(seats[i][j]!="0"){
				cout<<"Pop "<<seats[i][j]<<"\n";
				seats[i][j]="0";
			}
		}
	}
}

int main(){
	int numRows;  
	// cout<<"Enter the number of rows in the flight: ";
	cin>>numRows;
    string seats[numRows][6];	// 2D array to store the seats
    
    for(int i=0;i<numRows;i++)
    	for(int j=0;j<6;j++)
    		seats[i][j] = "0";
    		
	string s;
	int numPassengers=0;  
	
	while(1){
		// cout<<"Enter your choice\nE1 for Passenger Entry\nE2 for Passenger Exit\nE for Program Exit\nP for Print\nX for Full Exit :";
		cin>>s;
		
		if(s=="E1"){
			// cout<<"Enter passenger ID, boarding row number and Seat number: ";
			string idPassenger;
			int row;
			char seat;
			cin>>idPassenger>>row>>seat;
			cout<<"\n";
			if(numPassengers>=MAX_CAPACITY){
			    cout<<"Error! Plane is already full.\n";
			}
			else{
			    entry(seats,idPassenger,row,seat,numPassengers);
			}
			cout<<"\n";
		}
		else if(s=="E2"){
			// cout<<"Enter passenger ID, boarding row number and Seat number: ";
			string idPassenger;
			int row;
			char seat;
			cin>>idPassenger>>row>>seat;
			cout<<"\n";
			if(numPassengers<=0){
			    cout<<"Error! Plane is already empty.\n";
			}
			else{
			    exit(seats,idPassenger,row,seat,numPassengers);
			}
			cout<<"\n";
		}
		else if(s=="E"){
			cout<<"Program is Stopped.\n";
			break;
		}
		else if(s=="P"){
			cout<<"\nFlight occupancy status is:\n";
			display(seats,numRows);
			cout<<"\n";
		}
		else if(s=="X"){
			cout<<"\nThe LIFO order of passengers is:\n";
			completeExit(seats,numRows);
			numRows=0;
			cout<<"\n";
		}
	}
}