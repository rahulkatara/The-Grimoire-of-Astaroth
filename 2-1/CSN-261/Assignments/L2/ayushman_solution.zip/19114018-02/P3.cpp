#include<iostream>
using namespace std;

struct node //Each entry of the Stack would be of this type
{
    char choice;     //Stores which field of union is set. This would be required while acessing the union field

    union{  //This enhances that a momory efficient implementation is done for each node and memory for the max sized element is only allocated rather than the sum of memories of all elements in it
        int in;
        char ch;
        float fl;
    };

    node* next;
    
};

/*I am using a Linked List implementation of Stack with only one pointer to the Top element
This ensures my implementation to be in accordance with the Stack property that only the Top element is accessible
Using an array of pointers would have violated this property of Stack*/

class Stack{
    private: //Making these variables private ensures that direct access to Stack Elements is prevented. Only access would be through the Functions of the Stack

        int MAX_SIZE = 100;
        node* TOP ;
        int size = 0; 

    public:
        
        bool Empty(){   //To check whether stack is Empty or not
            if(size == 0)
                return true;
            else
                return false;
        }

        bool Full(){    //To check whether stack is Full or not
            if(size == MAX_SIZE)
                return true;
            else
                return false;
        }

        void Push(node* x){

            //We have already checked that Stack is not full by the Full() Function called in main()

            if(size == 0){  //This case has to be dealt specially as the other pointer has to remain NULL here.
                TOP = x;
            }
            else{
                x->next = TOP;
                TOP = x;              
            }

            size++;

            if(size==MAX_SIZE)
                cout<<"Stack Full!!"<<endl;

        }
        void Pop(){

            //We have already checked that Stack is not empty by the Empty() Function called in main()

            node* TEMP = TOP;   //I have temporarily stored this location as I would be freeing it after element in it is Popped.
            cout<<"The Popped Element is : ";

            if(TOP->choice == 'I')
                cout<<TOP->in<<endl;
            else if(TOP->choice == 'F')
                cout<<TOP->fl<<endl;
            else if(TOP->choice == 'C')
                cout<<TOP->ch<<endl;

            size--;
            
            TOP = TOP->next;

            free(TEMP);    //This helps us free the memory as after pop, the old top location becomes unaccessible. So this allows to prevent unnecessary space wastage.

        }
        void PRINT(){
            
            cout<<endl<<"The Current Status of Stack is : "<<endl;
            
            node* curr = TOP;
            
            while(curr != NULL){

                if(curr->choice=='I')
                    cout<<"\t\t\t\t  "<<curr->in;
                else if(curr->choice=='C')
                    cout<<"\t\t\t\t  "<<curr->ch;
                else if(curr->choice=='F')
                    cout<<"\t\t\t\t  "<<curr->fl;

                cout<<endl;

                curr = curr->next;
            }
        }
};  

int main(){

    

    Stack st;

    while(1){

        char choice;
        // Enter your choice of Operation : I for Insert, D for Delete, E for Exit, P for Print 
        cin>>choice;
        
        char insert_choice;
        int I;
        char C;
        float F;

        if(choice == 'I'){
            if(st.Full()){  //Whether the Stack is full or not is first checked. If full, the Overflow Error is printed.
                cout<<"OVERFLOW ERROR - Stack is Full. "<<endl;
            }
            else{
                struct node* x = (struct node*) malloc(sizeof(struct node));

                //Choice for Insert Type. Enter I for Integer, C for Character, F for Float 
                cin>>insert_choice;
                x->choice = insert_choice;

                if(x->choice == 'I'){
                    cin>>I;
                    x->in = I;
                }
                else if(x->choice == 'C'){
                    cin>>C;
                    x->ch = C;
                }
                else if(x->choice == 'F'){
                    cin>>F;
                    x->fl = F;
                }

                st.Push(x);                
            }

        }
        else if(choice == 'D'){ //Delete Operation
            
            if(st.Empty()){  //Whether stack is empty or not is checked
                cout<<"UNDERFLOW ERROR - Stack is already Empty. "<<endl;
            }
            else{
                st.Pop();
            }

        }   
        else if(choice == 'E'){ //Exiting the Program
            
            cout<<"Program is Stopped."<<endl;
            break;
        
        }
        else if(choice =='P'){  //Printing the current status of Stack;
            st.PRINT();
        }

    }

    
    return 0;
}