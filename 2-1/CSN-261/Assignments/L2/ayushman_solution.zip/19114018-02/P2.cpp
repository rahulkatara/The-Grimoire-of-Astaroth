#include<iostream>
using namespace std;


struct student
{
    char choice;    //Stores which field of union is set. This would be required while acessing the union field
    
    union   //Using an unnamed union let's me access the fields of union as the fields of struct student directly. Allocating only the max memory size at the same time.
    {
        string Roll_Number;
        long long Mobile_Number; //As mobile number is of 10 digits, it exceeds range of integer. Thus we have to use long long
        string UID;
    
    };
   
    
    string Full_Name;
    string Course_Code;
    int age;
    string Branch;
    student* next;
    
};

class Database
{
    private:
        student* HEAD = NULL;
        student* node = NULL;
    
    public:
        void create_entry(student* s){
            
            if(HEAD == NULL){
                HEAD = s;
                s->next = NULL;
            }
            else if(HEAD->age >= s->age){
                s->next = HEAD;
                HEAD = s;
            }//The above two represented Insertion at HEAD
            else{
                node = HEAD;
                bool flag=0;       

                while(node->next != NULL){  //I have implemented the Insert function in such a way that sorting can be done in Real Time, by Inserting the new entry in the Linked List as per it's age

                    if(node->next->age >= s->age){
                        s->next = node->next;
                        node->next = s;
                        flag=1;
                        break;
                    }
                    else{
                        node = node->next;
                    }

                }

                if(!flag){
                    node->next = s;
                    s->next=NULL;
                }
            }

        }

        void print_database(){  //Utility Funtion to print the current state of Database
            cout<<"The sorted list of students is : "<<endl;
            
            node = HEAD;
            int i=1;
            while(node != NULL){
                cout<<i<<". ";
                
                if(node->choice=='M')
                    cout<<node->Mobile_Number<<", ";
                else if(node->choice=='R')
                    cout<<node->Roll_Number<<", ";
                else 
                    cout<<node->UID<<", ";
                
                cout<<node->Full_Name<<", "<<node->Course_Code<<", "<<node->age<<", "<<node->Branch<<endl;

                node=node->next;

                ++i;
            }
        }


};

int main(){

    int n;

    //Enter the number of students : 
    cin>>n;

    Database db;

    char choice;
    string Roll_Number, UID;
    long long Mobile_Number;
    string Full_Name, Course_Code, Branch;
    int age; 

    for(int i=1;i<=n;++i){

        //student *s = new student{};
        struct student* s = (struct student*) malloc(sizeof(struct student));


        //Enter the choice for student i : R for Roll number, M for Mobile number, O for unique ID.

        cin>>choice;
        s->choice=choice;

        if(s->choice == 'R'){   //Roll Number
            cin>>Roll_Number;
            s->Roll_Number = Roll_Number;
        }
        else if(s->choice == 'M'){  //Mobile Number
            cin>>Mobile_Number;
            s->Mobile_Number = Mobile_Number;
        }
        else{   //Unique ID
            cin>>UID;
            s->UID = UID;
        }
        
        cin.ignore();   //to not let the getline take the '\n'  
        getline(cin,Full_Name);  

        s->Full_Name = Full_Name;
        /*Full Name of the student . 
        Here I have used getline function as cin would have only taken one single word 
        Even if name contained more than one word */

        cin>>Course_Code;
        s->Course_Code=Course_Code;    //Course Code
        
        cin>>age;
        s->age = age;    //Age

        cin>>Branch;
        s->Branch = Branch; //Branch

        db.create_entry(s); //This function passes the pointer to the new memory allocated for student i to create a new entry for the student
        
    }

    db.print_database();

    return 0;
}