#include<iostream>
using namespace std;

int main(){

    int n;

    //Enter the size of Array 
    cin>>n;
    
    int a[n];

    //Enter the elements : 
    for(int i=0;i<n;++i){
        cin>>a[i];
    }

    int k;
    //Enter the kth smallest element you want to find (Enter k)
    cin>>k;


    for(int i=0;i<k;++i){   //in ith each iteration the value of a[i-1] would be fixed , a[i-1] is the i th smallest element {i starts from 0}
        for(int j=n-1;j>i;--j){
            if(a[j]<a[j-1]){
                a[j] = a[j]+a[j-1];
                a[j-1] = a[j]-a[j-1];
                a[j] = a[j]-a[j-1];
            }
        }
    }

    cout<<"kth smallest element : "<<a[k-1]<<endl; 

    return 0;
}

// I have used the bubble sort and iterated k times,ith  iteration would fix the ith smallest number and we don't need to sort further.
// Using any other sorting algorithm like Merge Sort or Heap Sort or Randomised Quick Sort would have reduced the worst case time complexity,
// But it would have had no change on the average case/best case complexity. Here the best case complexity is O(n) and makes the complexity dependent on k. (Complexity = O(n*k))