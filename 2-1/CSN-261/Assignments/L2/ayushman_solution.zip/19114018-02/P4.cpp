#include<iostream>
using namespace std;

struct node
{
    char choice;     //Stores which field of union is set. This would be required while acessing the union field

    union{
        int I;
        char C;
        float F;
    };

    node* next;
};

class CircularQueue{   
    private:    //Making these variables private ensures that direct access to Queue Elements is prevented. Only access would be through the Functions of the Circular Queue
        
        int MAX_SIZE = 100;
        node* front = NULL; //Points to  the first inserted node. Deletion occurs from the front of the queue.
        node* back = NULL;  //Points to the last inserted node. Insertion occurs at back of the queue
        int size=0;


        //The defining property of a Circular Queue is that back->next would always be equal to the front.

    public:
        bool Underflow(){   //Checks for Underflow in the Circular Queue
            if(size == 0)
                return true;
            else
                return false;
        }

        bool Overflow(){    //Checks for Overflow in the Circular Queue
            if(size == MAX_SIZE)
                return true;
            else
                return false;
        }
            
        void Insert(node* s){

            if(front == NULL){  //This case has to be dealt specially as both front and back pointers are uninitialized. Otherwise only back had to be updated in other cases
                s->next = s;
                front = s;
                back = s;
            }
            else{
                back->next = s;
                s->next = front;
                back = s;            
            }

            size++;
        }

        void Delete(){
            
            node* TEMP = front; //I have temporarily stored this location as I would be freeing it after element in it is Deleted.

            cout<<"The Deleted Element is : ";
            if(front->choice=='I')cout<<front->I<<endl;
            else if(front->choice=='C')cout<<front->C<<endl;
            else cout<<front->F<<endl;

            front = front->next;
            back->next = front;
            
            size--;

            free(TEMP); //This helps us free the memory as after Delete(), the old front location becomes unaccessible. So this allows to prevent unnecessary space wastage.
            

        }

        void PRINT(){
            node* curr = front;
            cout<<"The Current Status of the Queue is : "<<endl;
            while(1){

                if(curr->choice == 'I')
                    cout<<"\t\t\t\t  "<<curr->I<<endl;
                else if(curr->choice == 'C')
                    cout<<"\t\t\t\t  "<<curr->C<<endl;
                else if(curr->choice == 'F')
                    cout<<"\t\t\t\t  "<<curr->F<<endl;

                curr = curr->next;

                if(curr == front)   //Execution of Print Statement is Stopped when the first node is pointed to again
                    break;
            }
        }

};

int main(){

    CircularQueue CQ;
        
        char c; //Type of operation

        char insert_choice;
        int I;
        char C;
        float F;

    while(1){
        struct node* s = (struct node*) malloc(sizeof(struct node));
        
        //Enter Operation to be Performed: I for Insert, D for Delete, E for Exit, P for Print
        cin>>c;

        if(c == 'I'){     //Insert Operation

            if(CQ.Overflow()){  //Check for Overflow. If Circular Queue is already at Max Capacity, then prints Error Message

                cout<<"OVERFLOW ERROR - Maximum Size of Circular Queue already Reached."<<endl;
            
            }
            else{
                cin>>insert_choice; //Choice for Insert Type
                s->choice = insert_choice;

                if(s->choice == 'I'){
                    cin>>I;
                    s->I = I;
                }
                else if(s->choice == 'C'){
                    cin>>C;
                    s->C = C;
                }
                else if(s->choice == 'F'){
                    cin>>F;
                    s->F = F;
                }
                CQ.Insert(s);                
            }

        }
        else if(c == 'D'){  //Delete Operation
            CQ.Delete();
        }
        else if(c == 'P'){  //Print Operation   
            CQ.PRINT();
        }
        else if(c == 'E'){  //Exit Operation

            cout<<"Program is Stopped."<<endl;
            break;
        }

    }
    return 0;
}