/**********************************

	CSN 261 Lab 2 Question 1 : Circular Queue Implementation Using Linked Lists
	P4.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

struct Element{
	public: 
	union {
		int i;
		char c;
		float f;
	} data;
	char choice;
	struct Element* next;
};

class MyQ{
private: //Keeping data (queue) private

	int size;
	struct Element* front;
	struct Element* rear;

public: //Providing functions for user to manipulate queue

	MyQ(){
		front=NULL;
		rear=NULL;
		size=0;
	}

	bool checkOverflow(){
		return this->size == 10; //MAX SIZE OF QUEUE IS 10
	}
	bool checkUnderflow(){
		return this->size == 0; //MIN SIZE 0
	}

	//PUSH FUNCTIONS
	void enqueue(struct Element* e){		
		if(this->rear == NULL){ //INSERT ELEMENT WHEN QUEUE IS EMPTY
			this->front = e;
			this->rear = e;
			this->rear->next = this->front;
		} else { // INSERT ELEMENT WHEN QUEUE IS NOT EMPTY
			e->next = this->front;
			this->rear->next = e;
			this->rear = e;
		}
		this->size++;
	}

	//POP FUNCTION
	struct Element* dequeue(){ 
		struct Element* e = this->front; // STORE ELEMENT TO BE POPPED IN ONE VARIABLE
		if(this->front == this->rear){ // REMOVE ELEMENT WHEN ONLY ONE ITEM IN QUEUE
			//SET BOTH POINTERS TO NULL
			this->front = NULL;
			this->rear = NULL;
		} else { //REMOVE ELEMENT WHEN MORE THAN ONE ELEMENT PRESENT IN QUEUE
			this->front = this->front->next;
			this->rear->next = this->front;
		}
		this->size--;
		return e; //RETURN POPPED ELEMENT
	}

	void show_queue(){
		cout<<"\nPrinting elements in FIFO order:\n";
		struct Element* curr = this->front; // START FROM FRONT OF QUEUE
		int n = this->size-1;
		cout<<"\nStarting from the front of the queue:\n\n";
		do { //ITERATE TILL BACK OF QUEUE
			cout<<"\t";
			cout<<(this->size-n)<<". Type: "<<curr->choice<<", Value: ";
			switch(curr->choice){
				case 'I':
					cout<<curr->data.i<<"\n";
					break;
				case 'F':
					cout<<curr->data.f<<"\n";
					break;
				case 'C':
					cout<<curr->data.c<<"\n";
					break;
			}
			curr = curr->next;
			n--;
		} while(curr != this->front); //STOP WHEN WE REACH THE FRONT AGAIN
		cout<<"Ending with the rear of the queue\n\n";
	}
};

int main() 
{
	MyQ myQ;
	while(true){
		//Get input
		
		bool input_invalid = false;
		string choice_input;
		char choice;
		do{
			if(input_invalid) cout<<"\nPlease enter a valid choice!\n";
			
			// cout<<"\nEnter your choice:\n";
			// cout<<"I for Insert\n";
			// cout<<"D for Delete\n";
			// cout<<"E for Exit\n";
			// cout<<"P for Print: ";
			cin>>choice_input;

			//VALIDATE INPUT TO MAKE SURE MY PRORGAM DOESN'T BREAK EASILY 
			if( choice_input.length() != 1 || !(choice_input[0] == 'I' || choice_input[0] == 'D' || choice_input[0] == 'E' || choice_input[0] == 'P')){
				input_invalid = true;
			} else {
				choice = choice_input[0];
				input_invalid = false;
			}
		} while(input_invalid);


		if(choice=='E'){ // EXIT PROGRAM
			cout<<"\nProgram is stopped\n";
			break;
		}
		
		if(choice=='I'){ //INSERT
			if(myQ.checkOverflow()){ //CHECK SIZE OF QUEUE TO PREVENT OVERFLOW
				cout<<"\nThe circular queue is full (It already has 10 elements)! No more elements can be added, otherwise it will overflow :)\n";
				continue;
			}
			input_invalid = false;
			string data_type_input;
			char data_type;
			do{
				if(input_invalid) cout<<"\nPlease enter a valid choice!\n";
				
				//cout<<"​\nEnter ​I ​for integer,​ C​ for char and ​F​ for float:​ ";
				cin>>data_type_input;
				if( data_type_input.length() != 1 || !(data_type_input[0] == 'I' || data_type_input[0] == 'F' || data_type_input[0] == 'C')){
					input_invalid = true;
				} else {
					data_type = data_type_input[0];
					input_invalid = false;
				}

			} while(input_invalid);

			cout<<"\n";
			
			struct Element *e = (struct Element*) malloc(sizeof(struct Element));
			e->choice=data_type;

			switch(data_type){
				case 'I':
					int int_input;
					//cout<<"Enter an integer value: ";
					cin>>int_input;
					e->data.i = int_input;
					break;
				case 'F':
					float float_input;
					//cout<<"Enter a float value: ";
					cin>>float_input;
					e->data.f = float_input;
					break;
				case 'C':
					char char_input;
					//cout<<"Enter a char value: ";
					cin>>char_input;
					e->data.c = char_input;
					break;
			}

			myQ.enqueue(e);
			cout<<"\nInserted\n";
		}

		if(choice=='D'){//DELETE
			if(myQ.checkUnderflow()){ //CHECK SIZE OF QUEUE TO PREVENT UNDERFLOW
				cout<<"\nThe circular queue is empty! No more elements can be removed, otherwise it will underflow :)\n";
				continue;
			}

			struct Element *e = (struct Element*) malloc(sizeof(struct Element));
			e = myQ.dequeue();
			
			switch(e->choice){
				case 'I':
					cout<<"\nDequeued element is "<<e->data.i<<"\n";
					break;
				case 'F':
					cout<<"\nDequeued element is "<<e->data.f<<"\n";
					break;
				case 'C':
					cout<<"\nDequeued element is "<<e->data.c<<"\n";
					break;
			}
			
			free(e); // FREE THE DATA FROM THE MEMORY LOCATION BECAUSE IT IS NO LONGER NEEDED
		}

		if(choice=='P'){
			if(myQ.checkUnderflow()){ //IF QUEUE IS EMPTY WE WILL HAVE NOTHING TO PRINT
				cout<<"\nThe circular queue is currently empty. Insert elements using choice I :)\n";
			} else {				
				myQ.show_queue();
			}
		}
		
	}
	return 0;
}
