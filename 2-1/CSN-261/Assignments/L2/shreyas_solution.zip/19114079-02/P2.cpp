/**********************************

	CSN 261 Lab 2 Question 2 : Student Database Using Linked List
	P2.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;


class Database {
private: //This is where the data goes	
	struct Student { 
		union {
			string roll_number;
			string mobile_number;
			string unique_id;
		} data;
		char id_choice;
		string full_name;
		string course_code;
		string branch;
		int age;
		struct Student* next;
	};

	struct Student* head;

public: //This is where the functions go
	//Constructor
	Database(){
		head = NULL;
	}

	void insert_student(
		char id_choice, 
		string id_value, 
		string full_name, 
		string course_code, 
		string branch, 
		int age)
	{
		struct Student *s = (struct Student*) malloc(sizeof(struct Student)); // Creates data space for student
		
		// Set value of id type and id value
		s->id_choice = id_choice;
		switch(id_choice){
			case 'R':
				s->data.roll_number = id_value;
				break;
			case 'M':
				s->data.mobile_number = id_value;
				break;
			default:
				s->data.unique_id = id_value;
		}
		// Set remaining values
		s->full_name = full_name;
		s->course_code = course_code;
		s->branch = branch;
		s->age = age;

		if(this->head == NULL){// LIST IS EMPTY
			this->head = s;
			s->next = NULL;
		} else if(this->head->next == NULL){ // ONLY ONE ELEMENT IN LIST
			if(this->head->age < s->age){ // If head.age is less than age of element to be inserted
				this->head->next = s;
				s->next = NULL;
			} else {
				s->next = this->head;
				this->head = s;
			}
		} else { // MORE THAN ONE ELEMENT IN LIST

			struct Student* curr = this->head; // CURR POINTER TO TRAVERSE THE LIST AND FIND THE CORRECT POSITION
			struct Student* temp = this->head; // TEMP POINTER TO TRAIL BEHIND THE CURR POINTER (USED WHILE INSERTING IN BETWEEN THE LIST)

			if(this->head->age >= s->age){ // CHECK IF NEW STUDENT'S AGE IS LESS THAN OR EQUAL TO HEAD'S AGE FIRST
				// INSERT ELEMENT
				s->next = this->head;
				this->head = s;
				return;
			}

			while(curr->next != NULL){ // ITERATE THROUGH LIST
				if(curr->age >= s->age){ // CORRECT POSITION FOUND
					// INSERT ELEMENT
					temp->next = s;
					s->next = curr;
					return;
				}
				temp = curr; //TRAILS BEHIND
				curr = curr->next; //MOVES FORWARD
			}

			// LIST TRAVERSED BUT CORRECT POSITION NOT FOUND
			// THEN STUDENT'S AGE MUST BE LARGER THAN ALL AGES IN DATABASE

			//INSERT  ELEMENT
			if(curr->age < s->age){
				curr->next = s;
				s->next = NULL;
			} else {
				temp->next = s;
				s->next = curr;
			}
			return;
		}
	}

	int show_database(){
		struct Student *curr = this->head; // CURR POINTER TO TRAVERSE THE LIST AND FIND THE CORRECT POSITION
		
		if(curr == NULL) return 0; // LIST EMPTY
		cout<<"\n";	
		int counter = 1; // ITERATOR TO BE USED WHILE PRINTING ELEMENTS FOR USER TO KEEP TRACK WITH EASE
		while(curr != NULL){ // ITERATE THROUGH LIST
			// PRINT USER INFORMATION
			cout<<counter<<". ";
			switch(curr->id_choice){
				case 'R':
					cout<<curr->data.roll_number;
					break;
				case 'M':
					cout<<curr->data.mobile_number;
					break;
				default:
					cout<<curr->data.unique_id;
					break;
			}
			cout<<", ";

			cout<<curr->full_name<<", ";
			cout<<curr->course_code<<", ";
			cout<<curr->age<<", ";
			cout<<curr->branch<<", ";
			cout<<"\n";
			
			curr = curr->next; //MOVES FORWARD
			counter++; // INCREMENT COUNTER
		}
		return 1; //LIST NOT EMPTY
	}
}; 

int main() 
{
	//INITIALIZE FIRST STUDENT WITH AGE ZERO AS HEAD OF LINKED LIST
	//INPUT NUMBER OF STUDENTS
	// cout<<"\nEnter the number of students: ";
	int num_students; cin>>num_students;
		
	if(num_students==0){
		cout<<"No students entered in database\n";
		return 0;
	}

	Database db;

	//INITIALIZING QUESTIONS AND ERRORS ARRAY TO AVOID CODE REPETITION
	string id_question[3];
	id_question[0] = "Enter 10-digits mobile number of student ";
	id_question[1] = "Enter roll number of student ";
	id_question[2] = "Enter unique id of student ";

	string id_error[3];
	id_error[0] = "Mobile number is not valid!\n";
	id_error[1] = "Roll number is not valid!\n";
	id_error[2] = "Unique ID is not valid!\n";
		

	for(int stdnt=1; stdnt<=num_students; stdnt++){
		bool wrong_input = false;

		//TAKING CHOICE INPUT
		string choice_input;
		char choice;
		do {
			//PRINT ERROR STATEMENT IN CASE USER ENTERED INVALID VALUES
			if(wrong_input) cout<<"\nPlease enter a valid choice!\n";
			
			//ASK QUESTION
			// cout<<"\nEnter the choice for student "<<stdnt<<"\n";
			// cout<<"R for Roll number \nM for mobile number \nO for other Unique ID: ";
			cin>>choice_input;

			//VALIDATE INPUT TO MAKE SURE MY PRORGAM DOESN'T BREAK EASILY 
			if( choice_input.length() != 1 || !(choice_input[0] == 'R' || choice_input[0] == 'M' || choice_input[0] == 'O')){
				wrong_input = true;
			} else {
				choice = choice_input[0];
				wrong_input = false;
			}
		} while(wrong_input);


		
		//TAKING ID INPUT
		wrong_input = false;
		string id_value;
		do{
			//PRINT ERROR STATEMENT IN CASE USER ENTERED INVALID VALUES
			if(wrong_input){
				cout<<"\n";
				if(choice=='M')cout<<id_error[0];
				else if(choice=='R')cout<<id_error[1];
				else cout<<id_error[2];
			}

			//ASK QUESTION
			// if(choice=='M')cout<<id_question[0]<<stdnt<<": ";
			// else if(choice=='R')cout<<id_question[1]<<stdnt<<": ";
			// else cout<<id_question[2]<<stdnt<<": ";
			cin>>id_value;

			//VALIDATE INPUT TO MAKE SURE MY PRORGAM DOESN'T BREAK EASILY 
			if(choice == 'M'){
				if(id_value.length() != 10){
					wrong_input = true;
				} else {
					wrong_input = false;
					for(int i=0; i<10; i++){
						if(id_value[i] >= '0' && id_value[i] <= '9'){
							continue;
						} else {
							wrong_input = true;
							break;
						}
					}
				}
			}

		} while(wrong_input);


		//TAKING REST OF THE INPUT
		string name;
		// cout<<"\nEnter the full name of student "<<stdnt<<": ";
		cin.ignore();
		getline(cin, name);

		string course;
		// cout<<"\nEnter the course code of student "<<stdnt<<": ";
		cin>>course;

		int age;
		wrong_input = false;
		do{
			if(wrong_input) cout<<"\nAge must be a postive integer, please try again!\n";

			// cout<<"\nEnter the age of student "<<stdnt<<": ";
			cin>>age;

			if(age<1){
				wrong_input = true;
			} else {
				if(age>=40) cout<<"\nThe student's age is suspiciously large, but I'll allow it. You're never to old to learn :P\n";
				wrong_input = false;
			}	
		} while(wrong_input);

		string branch;
		// cout<<"\nEnter the branch for student "<<stdnt<<": ";
		cin>>branch;

		//INSERT INTO DATABASE
		//cout<<"\nTime to enter these into the database!\n";
		db.insert_student(choice, id_value, name, course, branch, age);
	}
	
	//FINAL OUTPUT
	db.show_database();
	return 0;
}
