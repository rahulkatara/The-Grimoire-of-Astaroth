Please use codechef IDE to test this code

