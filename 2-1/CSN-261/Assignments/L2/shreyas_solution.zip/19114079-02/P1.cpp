/**********************************
	
	CSN 261 Lab 2 Question 1 : K-th Smallest Element
	P1.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

int main() 
{
	//Input size of array
    int n;
	// cout<<"Enter the size of the array: ";
	cin>>n;

	//Input elements of array
	int a[n];
	// cout<<"Enter the elements: ";
	for(int i=0; i<n; i++) cin>>a[i];

	//Input value of k
	int k;
	// cout<<"Enter the Kth smallest you want to find: ";
	cin>>k;

	if(k>n || k<1){ //Validating value of K, otherwise search cannot be performed
		cout<<"\nThe value of k must be between 1 and "<<n<<" inculsive."; 
		return 0;
	}
	int ksmallest;
	for(int turn=0; turn<k; turn++){
		int mn = INT_MAX; //Setting minimum value (mn) to maximum possible value of int, so that we can compare it to the values of the arrays and take minimum of the two
		int mn_ind = -1; //Variable to store index of minimum for this round
		for(int i=0; i<n; i++){
			if(a[i] < mn){ 
				mn = a[i]; //Assign mn to array element if it is less than mn, so that by going through the entire array, we will find the minimum value present
				mn_ind = i; //Store index of smallest element
			}
		}
		a[mn_ind] = INT_MAX; //Assign maximum value of int in place of minimum value so we don't count it in the next iteration
		ksmallest = mn; //Assign value of mn in each step to global min so after the k-th iteration we'll get the k-th smallest value
	}

	cout<<"\nThe kth smallest element is: "<<ksmallest<<"\n"; //Output 
	return 0;
}
