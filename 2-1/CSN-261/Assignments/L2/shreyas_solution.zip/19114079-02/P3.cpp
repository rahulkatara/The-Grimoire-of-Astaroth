/**********************************

	CSN 261 Lab 2 Question 3 : Stack Implementation Using Linked Lists
	P3.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

**********************************/

#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;

struct Element{
	public: 
	union {
		int i;
		char c;
		float f;
	} data;
	char choice;
	struct Element* next;
};

class MyStack{
private: //Keeping data (stack) private

	int size;
	struct Element* top;

public: //Providing functions for user to manipulate stack

	MyStack(){
		top=NULL;
		size=0;
	}

	bool isFull(){
		return this->size == 10; //MAXIMUM STACK SIZE 10
	}
	bool isEmpty(){
		return this->size == 0;
	}

	//PUSH FUNCTIONS
	void push(struct Element* e){ // INSERT ELEMENT ON TOP OF STACK
		e->next= this->top;
		this->top = e;
		this->size++;
	}

	//POP FUNCTION
	struct Element* pop(){
		struct Element* e = this->top;
		this->top = this->top->next; //MOVE HEAD TO NEXT 
		this->size--;
		return e;
	}

	void show_stack(){
		cout<<"\nPrinting elements in LIFO order:\n";
		struct Element* curr = this->top;
		int n = this->size;
		cout<<"\nStarting with the top of the stack\n\n";
		while(curr != NULL){
			cout<<"\t";
			cout<<n<<". Type: "<<curr->choice<<", Value: ";
			switch(curr->choice){
				case 'I':
					cout<<curr->data.i<<"\n";
					break;
				case 'F':
					cout<<curr->data.f<<"\n";
					break;
				case 'C':
					cout<<curr->data.c<<"\n";
					break;
			}
			curr = curr->next;
			n--;
		}
		cout<<"\nEnding with the bottom of the stack\n";
	}
};

int main() 
{
	MyStack myStack;
	while(true){
		//Get input
		
		bool input_invalid = false;
		string choice_input;
		char choice;
		do{
			//GET CHOICE INPUT
			if(input_invalid) cout<<"\nPlease enter a valid choice!\n";
			
			// cout<<"\nEnter your choice:\n";
			// cout<<"I for Insert\n";
			// cout<<"D for Delete\n";
			// cout<<"E for Exit\n";
			// cout<<"P for Print: ";
			cin>>choice_input;

			//VALIDATE INPUT TO MAKE SURE MY PRORGAM DOESN'T BREAK EASILY 
			if( choice_input.length() != 1 || !(choice_input[0] == 'I' || choice_input[0] == 'D' || choice_input[0] == 'E' || choice_input[0] == 'P')){
				input_invalid = true;
			} else {
				choice = choice_input[0];
				input_invalid = false;
			}
		} while(input_invalid);


		if(choice=='E'){
			cout<<"\nProgram is stopped\n";
			break;
		}
		
		if(choice=='I'){ //INSERT
			if(myStack.isFull()){ // CHECK SIZE TO PREVENT STACK OVERFLOW
				cout<<"\nThe stack is full (It already has 10 elements)! No more elements can be added :)\n";
				continue;
			}
			input_invalid = false;
			string data_type_input;
			char data_type;
			do{
				if(input_invalid) cout<<"\nPlease enter a valid choice!\n";
				
				//TAKE DATA TYPE INPUT
				// cout<<"​\nEnter ​I ​for integer,​ C​ for char and ​F​ for float:​ ";
				cin>>data_type_input;

				//VALIDATE INPUT TO MAKE SURE MY PRORGAM DOESN'T BREAK EASILY 
				if( data_type_input.length() != 1 || !(data_type_input[0] == 'I' || data_type_input[0] == 'F' || data_type_input[0] == 'C')){
					input_invalid = true;
				} else {
					data_type = data_type_input[0];
					input_invalid = false;
				}

			} while(input_invalid);

			cout<<"\n";
			
			struct Element *e = (struct Element*) malloc(sizeof(struct Element));
			e->choice=data_type;

			// TAKE VALUE OF DATA INPUT
			switch(data_type){
				case 'I':
					int int_input;
					// cout<<"Enter an integer value: ";
					cin>>int_input;
					e->data.i = int_input;
					break;
				case 'F':
					float float_input;
					// cout<<"Enter a float value: ";
					cin>>float_input;
					e->data.f = float_input;
					break;
				case 'C':
					char char_input;
					// cout<<"Enter a char value: ";
					cin>>char_input;
					e->data.c = char_input;
					break;
			}

			// INSERT INTO STACK
			myStack.push(e);
			cout<<"\nInserted\n";
		}

		if(choice=='D'){//DELETE
			if(myStack.isEmpty()){ //CHECK TO PREVENT UNDERFLOW
				cout<<"\nThe stack is empty! No more elements can be removed :)\n";
				continue;
			}

			struct Element *e = (struct Element*) malloc(sizeof(struct Element));
			e = myStack.pop();
			
			switch(e->choice){
				case 'I':
					cout<<"\nPopped element is "<<e->data.i<<"\n";
					break;
				case 'F':
					cout<<"\nPopped element is "<<e->data.f<<"\n";
					break;
				case 'C':
					cout<<"\nPopped element is "<<e->data.c<<"\n";
					break;
			}
			free(e); // FREE THE DATA FROM THE MEMORY LOCATION BECAUSE IT IS NO LONGER NEEDED
		}

		if(choice=='P'){
			if(myStack.isEmpty()){ //IF STACK IS EMPTY WE WILL HAVE NOTHING TO PRINT
				cout<<"\nThe stack is currently empty. Insert elements using choice I :)\n";
			} else {				
				myStack.show_stack(); //SHOW STACK
			}
		}
		
	}
	return 0;
}
