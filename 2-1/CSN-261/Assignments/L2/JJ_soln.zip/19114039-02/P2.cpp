#include <iostream>
using namespace std;

typedef long long ll;

// Use struct to define the structure of a node in the Linked List
struct Node{
    struct Node *next;

    char choice;
    union {
        string roll;
        ll mobile;
        string other;
    } unique_id;

    string name;
    string course_code;
    int age;
    string branch;
};

class StudentDatabase{

    public:

    struct Node *head;

    StudentDatabase(){
        head = NULL;
    }

    void insert(char choice, string roll, ll mobile, string other, string name, string course_code, int age, string branch){

        struct Node *new_node = (struct Node*) malloc(sizeof(struct Node));

        // Conditions for figuring out the choice given by the user

        switch (choice)
        {
        case 'R':
            new_node->unique_id.roll = roll;
            break;
        case 'O':
            new_node->unique_id.other = other;
            break;
        case 'M':
             new_node->unique_id.mobile = mobile;
            break;
        default:
            cout << "This is not a valid choice!\n";
            return;
        }
        new_node->choice = choice;
        new_node->name = name;
        new_node->course_code = course_code;
        new_node->age = age;
        new_node->branch = branch;

        
        if(head==NULL){
            head=new_node;
            return;
        }else if(head->age > age){
            new_node->next = head;
            head = new_node;
            return;
        }
        
        struct Node  *ptr;
        ptr = head;

        while(ptr->next != NULL && ptr->next->age < age) continue;

        // Move through the nodes
        new_node->next = ptr->next;
        ptr->next = new_node;
        head = (head->age < ptr->age) ? head : ptr;

        return;
    }

    // Fuction to display the database entries
    void display(){

        struct Node *ptr = head;

        cout<<"\nThe sorted list of students is :"<<endl;
        int itr=1;

        string unique_id_str;
        ll unique_id_ll;
        while(ptr!=NULL){
            if(ptr->choice == 'M'){
                unique_id_ll = ptr->unique_id.mobile;
            }else if(ptr->choice == 'R'){
                unique_id_str = ptr->unique_id.roll;
            }else{
                unique_id_str = ptr->unique_id.other;
            }

            if(ptr->choice == 'M'){
                cout<<itr<<", "<<unique_id_ll<<", "<<ptr->name<<", "<<ptr->course_code<<", "<<ptr->age<<", "<<ptr->branch<<endl;
            }else{
                cout<<itr<<", "<<unique_id_str<<", "<<ptr->name<<", "<<ptr->course_code<<", "<<ptr->age<<", "<<ptr->branch<<endl;
            }

            ptr = ptr->next;
            itr++;
        }
        return;
    }
};

int main(){
    
    int n;
    // cout<<"Enter the number of students: ";
    cin>>n;

    StudentDatabase mydb;

    for(int i=0; i < n; i++){
        // cout<<"Enter choice for student no. "<<i+1<<":\n R for Roll Number\n M for Mobile Number\n O for other unique id\n Choice: ";
        char choice;
        cin>>choice;

        ll unique_id_ll;
        string unique_id_str;
        string name, course_code, branch;
        int age;

        if(choice == 'R'){
            // cout<<"Enter the Roll Number for student "<<i+1<<": ";
            cin>>unique_id_str;
        }else if(choice == 'M'){
            // cout<<"Enter 10-digits Mobile number for the student "<<i+1<<": ";
            cin>>unique_id_ll;
        }else if(choice == 'O'){
            // cout<<"Enter another unique id for the student "<<i+1<<": ";
            cin>>unique_id_str;
        }else{
            cout<<"Invalid option selected. Please try again."<<endl;
            i--;
            continue;
        }

        // cout<<"Enter the full name for the student "<<i+1<<": ";
        cin.ignore();
        getline(cin, name);

        // cout<<"Enter the course code for the student "<<i+1<<": ";
        cin>>course_code;

        // cout<<"Enter the age for the student "<<i+1<<": ";
        cin>>age;

        // cout<<"Enter the branch name for student "<<i+1<<": ";
        cin>>branch;

        // Add the student to the database
        mydb.insert(choice, unique_id_str, unique_id_ll, unique_id_str, name, course_code, age, branch);
        // cout<<"--------------------------------------\n";        
    }
    cout<<"Waiting for the database entries to be displayed...";

    // Display the contents of database
    mydb.display();
    
    return 0;
}