#include <iostream>
using namespace std;


int main(){
    int n;
    
   // cout<<"Enter the size of the array: ";
    cin>>n;
    int arr[n];

    //cout<<"Enter the elements (in separate lines) and press enter: \n";
    for(int i = 0; i < n; i++) cin>>arr[i];

    int k;
    //cout<<"Enter the Kth smallest you want to find: ";
    cin>>k;

    // Carry out [k] iterations to find the get the kth smallest at the k-1 index 
    for(int i = 0; i < k; i++){
        for(int j=n-1; j>0; j--){
            if(arr[j]<arr[j-1]){
                int temp = arr[j];
                arr[j]=arr[j-1];
                arr[j-1]=temp;
            }
        }
    }

    cout<<"The " << k << "th element is: ";
    cout<<arr[k-1]<<endl;

    return 0;
}