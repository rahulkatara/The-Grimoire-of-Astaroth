#include <iostream>
using namespace std;

#define STACK_SIZE 30
#define ERROR_OUTPUT -1

struct Node{

    char choice;
    union {
        int I;
        char C;
        float F;
    } data;

    struct Node *next;
};

class Stack{

    public:

    struct Node *head;
    int count;

    Stack(){
        head = NULL;
        count=0;
    }

    bool empty(){
        return head==NULL;
    }

    bool full(){
        return count>STACK_SIZE;
    }

    // Push for all 3 datatypes
    int push(int data){
        
        if(full()){
            cout<<"Stack Size of 30 has been reached!\n"<<endl;
            return ERROR_OUTPUT;
        }
        
        struct Node *new_node = (struct Node*) malloc(sizeof(struct Node));
        new_node->choice = 'I';
        new_node->data.I = data;
        new_node->next = head;
        head = new_node;
        count++;

        return data;
    }

    char push(char data){
        
        if(full()){
            cout<<"Stack is full!\n"<<endl;
            return ERROR_OUTPUT;
        }
        
        struct Node *new_node = (struct Node*) malloc(sizeof(struct Node));
        new_node->choice = 'C';
        new_node->data.C = data;
        new_node->next = head;
        head = new_node;
        count++;

        return data;
    }

    float push(float data){
        
        if(full()){
            cout<<"Stack is full!\n"<<endl;
            return ERROR_OUTPUT;
        }
        
        struct Node *new_node = (struct Node*) malloc(sizeof(struct Node));
        new_node->choice = 'F';
        new_node->data.F = data;
        new_node->next = head;
        head = new_node;
        count++;

        return data;
    }

    // Pop from stack
    struct Node *pop(){
        if(empty()){
            cout<<"Nothing to pop. The stack is empty!\n"<<endl;
            return NULL;
        }

        struct Node *last = head;
        head = head->next;
        count--;

        return last;
    }

    void print(){
        struct Node *ptr;
        ptr = head;
        cout<<"The current status of stack is:\n";

        while(ptr!=NULL){
            switch(ptr->choice){
                case 'I': cout<<ptr->data.I<<endl; break;
                case 'C': cout<<ptr->data.C<<endl; break;
                case 'F': cout<<ptr->data.F<<endl; break;
                default: cout<<"An error was encountered!\n"<<endl;
            }
            ptr=ptr->next;
        }
    }

};

int main(){

    Stack stack;
    while(true){

        char mode;
        // cout<<"Enter your choice\n I for Insert\n D for delete\n E for exit\n P for print\n Response: ";
        cin>>mode;

        if(mode=='E'){
            cout<<"Program terminated."<<endl;
            break;
        }else if(mode=='P'){
            stack.print();
        }else if(mode=='I'){
            // cout<<"Enter I for Integer, C for Character and F for Float: ";
            char choice;
            cin>>choice;
            if(choice=='I'){
                int data;

                // cout<<"Enter an integer value: ";
                cin>>data;

                stack.push(data);
            }else if(choice=='C'){
                char data;

                // cout<<"Enter a character value: ";
                cin>>data;

                stack.push(data);
            }else if(choice=='F'){
                float data;

                // cout<<"Enter a float value: ";
                cin>>data;

                stack.push(data);
            }else{
                cout<<"Please enter I, C or F!\n"<<endl;
                continue;
            }

        }else if(mode=='D'){
            struct Node *popped_element = stack.pop();

            if(popped_element == NULL) continue;

            switch(popped_element->choice){
                case 'I': cout<<"The popped element is "<<popped_element->data.I<<endl; break;
                case 'C': cout<<"The popped element is "<<popped_element->data.C<<endl; break;
                case 'F': cout<<"The popped element is "<<popped_element->data.F<<endl; break;
                default: cout<<"Error encountered!"<<endl;
            }
            
        }else{
            cout<<"Please enter I, P, E or D!\n"<<endl;
            continue;
        }
        // cout<<"-------------------\n"<<endl;
    }

    return 0;
}