#include <iostream>
using namespace std;

#define MAX_SIZE 30

struct Node{
    union{
        int i;
        char c;
        float f;
    } key;
    char choice;
    Node *next;
};

class CircularQueue{
    public:
    
    Node *front;
    Node *rear;
    int count; 

    CircularQueue(){
        front=NULL;
        rear=NULL;
        count=0;
    }

    //insert int
    void Insert(int j){
        if(count==MAX_SIZE){
            cout<<"Circular Queue is full!\n";
            return;
        }
        Node *node=(Node*)malloc(sizeof(struct Node));
        node->choice='I';
        node->key.i=j;
        if(front==NULL){
            front=node;
            rear=node;
            node->next=node;
        }
        else{
            rear->next=node;
            node->next=front;
            rear=node;
        }
        
        count++;
    }

    void Insert(char j){
        if(count==MAX_SIZE){
            cout<<"Circular Queue is full!\n";
            return;
        }
        Node *node=(Node*)malloc(sizeof(struct Node));
        node->choice='C';
        node->key.c=j;
        if(front==NULL){
            front=node;
            rear=node;
            node->next=node;
        }
        else{
            rear->next=node;
            node->next=front;
            rear=node;
        }
        
        count++;
    }

    void Insert(float j){
        if(count==MAX_SIZE){
            cout<<"Circular Queue is full!\n";
            return;
        }
        Node *node=(Node*)malloc(sizeof(struct Node));
        node->choice='F';
        node->key.f=j;
        if(front==NULL){
            front=node;
            rear=node;
            node->next=node;
        }
        else{
            rear->next=node;
            node->next=front;
            rear=node;
        }
        
        count++;
    }

    Node* Delete(){
        if(count==0){
            return NULL;
        }
        Node *node=front;
        if(count==1){
            front=NULL;
            rear=NULL;
        }
        else{
            front=front->next;
            rear->next=front;
        }

        count--;
        return node;
    }

    // Queue is full
    bool Overflow(){
        if(count>MAX_SIZE){
            return true;
        }
        return false;
    }

    // Queue is empty
    bool Underflow(){
        if(count<0 || front==NULL){
            return true;
        }
        return false;
    }

    // Queue state
    void print(){
        Node *temp=front;
        if(temp==NULL){
            return;
        }
        if(temp->choice=='I'){
            
            cout<<temp->key.i;
        }
        else if(temp->choice=='C'){
            cout<<temp->key.c;
        }
        else if(temp->choice=='F'){
            cout<<temp->key.f;
        }
        cout<<"\n";
        temp=temp->next;
        while(temp!=front){
            if(temp->choice=='I'){
                cout<<temp->key.i;
            }
            else if(temp->choice=='C'){
                cout<<temp->key.c;
            }
            else if(temp->choice=='F'){
                cout<<temp->key.f;
            }
            cout<<"\n";
            temp=temp->next;
        }
    }
};

int main(){
    CircularQueue queue;

    while(true){
        // cout<<"Enter your choice\n I for Insert\n D for Delete\n E for Exit\n P for Print\n Choice: ";
        char c;
        cin>>c;
        if(c=='D'){
            Node *node=queue.Delete();
            if(node==NULL){
                cout<<"Error! Stack is empty.\n";
            }
            else{
                cout<<"The deleted element is : ";
                if(node->choice=='I'){
                    cout<<node->key.i;
                }
                else if(node->choice=='F'){
                    cout<<node->key.f;
                }
                else if(node->choice=='C'){
                    cout<<node->key.c;
                }
                cout<<"\n";
            }
        }
        else if(c=='E'){
            cout<<"Program is Stopped.\n";
            break;
        }
        else if(c=='I'){
            // cout<<"Enter I for integer, C for char and F for float: ";
            char v;
            cin>>v;
            if(v=='I'){
                // cout<<"Enter an Integer value: ";
                int x;
                cin>>x;
                queue.Insert(x);
            }
            else if(v=='C'){
                // cout<<"Enter a Char value: ";
                char x;
                cin>>x;
                queue.Insert(x);
            }
            else if(v=='F'){
                // cout<<"Enter a Float value: ";
                float x;
                cin>>x;
                queue.Insert(x);
            }
        }
        else if(c=='P'){
            cout<<"The Current status of the Queue is:\n";
            queue.print();
        }
    }
    return 0;
}
