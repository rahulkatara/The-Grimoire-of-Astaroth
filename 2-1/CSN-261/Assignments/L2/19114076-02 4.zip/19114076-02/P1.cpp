// Shashank Aital - 19114076
// Batch O4
// Computer Science And Engineering
// Indian Institute of Technology, Roorkee

// Problem 1

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, k;

    // Input: Size of the array
    cin>>n;
    int a[n];

    // Input: The elements of the array
    for(int i = 0; i < n; i++) cin>>a[i];

    // Input: The value of k
    cin>>k;

    for(int i = 0; i < k; i++){
        for(int j=n-1; j>0; j--){
            if(a[j]<a[j-1]){
                int temp = a[j];
                a[j]=a[j-1];
                a[j-1]=temp;
            }
        }
    }

    cout<<a[k-1]<<endl;

    return 0;
}