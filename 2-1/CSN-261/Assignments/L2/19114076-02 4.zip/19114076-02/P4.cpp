// Shashank Aital - 19114076
// Batch O4
// Computer Science And Engineering
// Indian Institute of Technology, Roorkee

// Problem 4

#include <bits/stdc++.h>
using namespace std;

#define MAX_SIZE 100
#define ERROR_OUTPUT 0

struct Node{
    char choice;
    union{
        int I;
        char C;
        float F;
    } data;

    struct Node *next;
};

class Circular_Queue{

    public:

    struct Node *front;
    int count;

    Circular_Queue(){
        front=NULL;
        count=0;
    }

    bool underflow(){
        return front==NULL;
    }

    bool overflow(){
        return count>MAX_SIZE;
    }

    // Overloaded push functions
    int push(int data){

        if(overflow()){
            cout<<"Queue is full!"<<endl;
            return ERROR_OUTPUT;
        }

        struct Node *ptr = (struct Node*) malloc(sizeof(struct Node));
        ptr->choice='I';
        ptr->data.I=data;

        if(front==NULL){
            front=ptr;
            front->next = front;
            return data;
        }
        
        ptr->next = front->next;
        front->next = ptr;
        front = ptr;
        return data;

    }
    char push(char data){

        if(overflow()){
            cout<<"Queue is full!"<<endl;
            return ERROR_OUTPUT;
        }

        struct Node *ptr = (struct Node*) malloc(sizeof(struct Node));
        ptr->choice='C';
        ptr->data.C=data;

        if(front==NULL){
            front=ptr;
            front->next = front;
            return data;
        }
        
        ptr->next = front->next;
        front->next = ptr;
        front = ptr;
        return data;

    }
    float push(float data){

        if(overflow()){
            cout<<"Queue is full!"<<endl;
            return ERROR_OUTPUT;
        }

        struct Node *ptr = (struct Node*) malloc(sizeof(struct Node));
        ptr->choice='F';
        ptr->data.F=data;

        if(front==NULL){
            front=ptr;
            front->next = front;
            return data;
        }
        
        ptr->next = front->next;
        front->next = ptr;
        front = ptr;
        return data;

    }

    // Delete function
    struct Node *pop(){

        if(underflow()){
            cout<<"Queue is empty."<<endl;
            return NULL;
        }

        if(front==front->next){
            struct Node *ptr = front;
            front=NULL;
            return ptr;
        }

        struct Node *ptr = front->next;
        front->next = front->next->next;
        return ptr;

    }

    void print(){

        cout<<"The current status of queue is:\n";
        struct Node *ptr = front->next;

        while(ptr!=front){
            switch(ptr->choice){
                case 'I': cout<<ptr->data.I<<endl; break;
                case 'C': cout<<ptr->data.C<<endl; break;
                case 'F': cout<<ptr->data.F<<endl; break;
                default: cout<<"An internal error occured."<<endl;
            }
            ptr=ptr->next;
        }

        if(front!=NULL){
            switch(front->choice){
                case 'I': cout<<front->data.I<<endl; break;
                case 'C': cout<<front->data.C<<endl; break;
                case 'F': cout<<front->data.F<<endl; break;
                default: cout<<"An internal error occured."<<endl;
            }
        }
        
        return;

    }

};

int main(){

    Circular_Queue my_queue;

    while(true){

        // cout<<"--------------------------------------------------------"<<endl;

        // cout<<"Enter your choice\n    I for Insert\n    D for Delete\n    E for Exit\n    P for Print\n  Response: ";
        char response;
        // Input: response
        // I for Insert
        // D for Delete
        // E for Exit
        // P for Print

        cin>>response;

        if(response=='E'){
            cout<<"Program is stopped."<<endl;
            break;
        }else if(response=='P'){
            my_queue.print();
        }else if(response=='I'){

            // cout<<"Enter I for integer, C for char and F for float: ";
            char choice;
            // Input: choice
            // I for Integer
            // C for Char
            // F for Float
            cin>>choice;

            if(choice=='I'){

                // cout<<"Enter an Integer value: ";
                int data;
                // Input: Integer data
                cin>>data;
                my_queue.push(data);

            }else if(choice=='C'){

                // cout<<"Enter a Char value: ";
                char data;
                // Input: Char data
                cin>>data;
                my_queue.push(data);

            }else if(choice=='F'){

                // cout<<"Enter a Float value: ";
                float data;
                // Input: Float data
                cin>>data;
                my_queue.push(data);

            }else{

                cout<<"Invalid choice."<<endl;
                continue;

            }

        }else if(response=='D'){

            struct Node *popped_element = my_queue.pop();

            if(popped_element!=NULL){

                switch(popped_element->choice){
                    case 'I': cout<<"The deleted element is: "<<popped_element->data.I<<endl; break;
                    case 'C': cout<<"The deleted element is: "<<popped_element->data.C<<endl; break;
                    case 'F': cout<<"The deleted element is: "<<popped_element->data.F<<endl; break;
                    default: cout<<"An internal error occured."<<endl;
                }

            }

            // Reclaim the space allocated to popped_element
            free(popped_element);

        }else{

            cout<<"Invalid response."<<endl;
            continue;

        }
    }

    return 0;
}