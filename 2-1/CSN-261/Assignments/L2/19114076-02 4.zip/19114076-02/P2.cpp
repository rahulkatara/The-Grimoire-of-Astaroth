// Shashank Aital - 19114076
// Batch O4
// Computer Science And Engineering
// Indian Institute of Technology, Roorkee

// Problem 2
// The problem is implemented using linked list

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

struct Node{
    struct Node *next;

    char choice;
    union {
        string roll_no;
        ll mobile_no;
        string other_info;
    } unique_id;

    string full_name;
    string course_code;
    int age;
    string branch;
};

class Database{

    public:

    struct Node *head;

    Database(){
        head = NULL;
    }

    void insert(char choice, string roll_no, ll mobile_no, string other_info, string full_name, string course_code, int age, string branch){

        struct Node *new_node = (struct Node*) malloc(sizeof(struct Node));

        // choice = 0 => roll Number provided
        // choice = 1 => mobile number provided
        // choice = 2 => Other ID provided

        if(choice == 'R'){
            new_node->unique_id.roll_no = roll_no;
        }else if(choice == 'M'){
            new_node->unique_id.mobile_no = mobile_no;
        }else if(choice == 'O'){
            new_node->unique_id.other_info = other_info;
        }else return;
        new_node->choice = choice;
        new_node->full_name = full_name;
        new_node->course_code = course_code;
        new_node->age = age;
        new_node->branch = branch;

        if(head==NULL){
            head=new_node;
            return;
        }else if(head->age > age){
            new_node->next = head;
            head = new_node;
            return;
        }
        
        struct Node  *ptr;
        ptr = head;

        while(ptr->next != NULL && ptr->next->age < age) continue;

        new_node->next = ptr->next;
        ptr->next = new_node;
        head = (head->age < ptr->age) ? head : ptr;

        return;
    }

    void display(){

        struct Node *ptr = head;

        cout<<"The sorted list of students is :"<<endl;
        int itr=1;

        string unique_id_str;
        ll unique_id_ll;
        while(ptr!=NULL){
            if(ptr->choice == 'M'){
                unique_id_ll = ptr->unique_id.mobile_no;
            }else if(ptr->choice == 'R'){
                unique_id_str = ptr->unique_id.roll_no;
            }else{
                unique_id_str = ptr->unique_id.other_info;
            }

            if(ptr->choice == 'M'){
                cout<<itr<<", "<<unique_id_ll<<", "<<ptr->full_name<<", "<<ptr->course_code<<", "<<ptr->age<<", "<<ptr->branch<<endl;
            }else{
                cout<<itr<<", "<<unique_id_str<<", "<<ptr->full_name<<", "<<ptr->course_code<<", "<<ptr->age<<", "<<ptr->branch<<endl;
            }

            ptr = ptr->next;
            itr++;
        }
        return;
    }
};

int main(){
    
    int n;
    // Input: The number of students:
    cin>>n;

    Database mydb;

    for(int i=0; i < n; i++){
        // cout<<"Enter choice for student "<<i+1<<"\n    R for Roll Number\n    M for Mobile Number\n    O for other unique id\n Response: ";
        // Input: Response
        // R - Roll Number
        // M - Mobile Number
        // O - Other Unique ID

        char response;
        cin>>response;

        ll unique_id_ll;
        string unique_id_str;
        string full_name, course_code, branch;
        int age;

        if(response == 'R'){
            // cout<<"Enter the Roll Number for student "<<i+1<<": ";
            // Input: Roll Number
            cin>>unique_id_str;
        }else if(response == 'M'){
            // cout<<"Enter 10-digits Mobile number for the student "<<i+1<<": ";
            // Input: Mobile Number
            cin>>unique_id_ll;
        }else if(response == 'O'){
            // cout<<"Enter another unique id for the student "<<i+1<<": ";
            // Input: Other ID
            cin>>unique_id_str;
        }else{
            cout<<"Invalid option selected. Please try again."<<endl;
            i--;
            continue;
        }

        // cout<<"Enter the full name for the student "<<i+1<<": ";
        // Input: Full Name
        cin.ignore();
        getline(cin, full_name);

        // cout<<"Enter the course code for the student "<<i+1<<": ";
        // Input: Course Code
        cin>>course_code;

        // cout<<"Enter the age for the student "<<i+1<<": ";
        // Input: Age
        cin>>age;

        // cout<<"Enter the branch name for student "<<i+1<<": ";
        // Input: Branch
        cin>>branch;

        // Insert
        mydb.insert(response, unique_id_str, unique_id_ll, unique_id_str, full_name, course_code, age, branch);        
    }

    // Display the contents of database
    mydb.display();
    
    return 0;
}