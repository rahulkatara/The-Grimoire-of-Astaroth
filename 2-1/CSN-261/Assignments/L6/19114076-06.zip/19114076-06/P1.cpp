// Shashank Aital - 19114076 - Sophomore, B. Tech.
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee.

// Lab Assignment 6

#include <iostream>
using namespace std;

// Node to make the Linked List
struct Node{

    int data;
    Node *next;
    Node *second;

};


class LinkedList{

    public:
    Node *head;
    int n; // Number of Nodes
    int number_of_cycles; // Stores number of cycles after find_cycles() is called
    string cycles; // Stores the cycles after find_cycles() is called

    LinkedList(int n){

        head = NULL;
        this->n = n;
        number_of_cycles = 0;
        cycles = "";

    }

    // Initialize the Linked List
    void initialize(){

        // Make a simple single linked list
        for(int i = n; i >= 1; i--){

            Node *x = new Node();
            x->data = i;
            x->next = head;
            head = x;

        }

        // Take custom input from user for assigning the second pointers
        Node *itr1 = head, *itr2 = head;
        for(int i = 0; i < n; i++){
            itr2 = head;
            int x;
            cin>>x;

            for(int j = 0; j < x-1; j++){
                itr2 = itr2->next;
            }

            itr1->second = itr2;
            itr1 = itr1->next;
        }

    }

    // A utility function to print the status of the Linked List as per the required format
    void print(){

        Node *itr = head;
        cout<<"     Node     Next Pointer    Second Pointer"<<endl;
        cout<<"--------------------------------------------"<<endl;
        while(itr->next!=NULL){
            cout<<"       "<<itr->data<<"            "<<itr->next->data<<"               "<<itr->second->data<<endl;
            itr = itr->next;
        }
        cout<<"       "<<itr->data<<"          "<<"NULL"<<"              "<<itr->second->data<<endl;

    }

    // Function to clone the linked list in O(n) time complexity
    LinkedList *clone(){

        Node *itr = head;

        // Duplicate the nodes so that the linked list becomes 1 -> 1 -> 2 -> 2 -> ...
        while(itr!=NULL){

            Node *x = new Node();
            x->data = itr->data;
            x->next = itr->next;
            itr->next = x;
            itr = itr->next->next;

        }

        itr = head;

        // Go through the old nodes of the linked list and assign the second pointers of the new nodes as per the old nodes' second pointers
        while(itr!=NULL){

            itr->next->second = itr->second->next;
            itr = itr->next->next;

        }

        itr = head;

        // Separate the old nodes from the new nodes
        // Make a linked list out of the new nodes
        // The new linked list is the exact copy of the old linked list
        LinkedList *copy = new LinkedList(n);
        copy->head = head->next;
        Node *x = itr;

        while(itr->next!=NULL){

            itr = itr->next;
            x->next = x->next->next;
            x = itr;

        }

        // Return the new Linked List
        return(copy);

    }

    // A function to remove a node from the linked list and restructure the linked list accordingly
    void remove(int x){

        Node *itr = head;

        // Restructure the 'second' pointers of all the nodes pointing to the node that is supposed to be deleted
        while(itr!=NULL){
            if(itr->second->data == x){
                itr->second = itr->second->second;
            }

            itr = itr->next;
        }

        // Delete the node (Similar to deleting a node in a Singly Linked List)
        Node *y;
        if(head->data == x){
            y = head;
            head = head->next;
            free(y);
        }else{

            itr = head;
            while(itr->next!=NULL){

                if(itr->next->data == x){
                    y = itr->next;
                    itr->next = itr->next->next;
                    free(y);
                    break;
                }else{
                    itr = itr->next;
                }

            }

        }

    }

    // A function to find the highest referenced node in the Linked List
    void highest_referenced(){

        int ref[n] = {0};

        // Update number of references due to the 'next' pointers
        for(int i = 1; i < n; i++){
            ref[i]++;
        }

        // Update the number of references due to the 'second' pointers
        Node *itr = head;
        while(itr!=NULL){
            ref[itr->second->data-1]++;
            itr = itr->next;
        }

        // Find the maximum number of references
        int ans = ref[0];
        for(int i = 1; i < n; i++){
            ans = (ans > ref[i]) ? ans : ref[i];
        }

        // Find the nodes having the highest number of references
        cout<<"List of highest referenced nodes: ";
        for(int i = 0; i < n; i++){
            if(ref[i]==ans) cout<<(i+1)<<" ";
        }
        cout<<"\nNumber of times they were referenced: "<<ans<<endl;

    }

    // Custom DFS in order to find cycles
    void dfs(LinkedList *g, Node *n, Node *root , bool *vis, LinkedList *stack){

        if(vis[n->data-1]){

            // If the node is visited, check if the node is the same as the root node
            if(n == root){
                
                // Cycle Detected
                // Increase the number of cycles and append this cycle to string cycles
                number_of_cycles++;
                string h = to_string(n->data) + "\n";
                Node *itr = stack->head;

                while(itr!=NULL){
                    h = to_string(itr->data) + " " + h;
                    itr = itr->next;
                }

                h = "Cycle " + to_string(number_of_cycles) + ": " + h;
                cycles = cycles + h;

                return;

            }else{
                // Redundant cycle
                // Will be covered in future iterations. => Skip now
                return;
            }

        }else{

            // Univisited Node
            vis[n->data-1] = true;

            // Append the new node to the stack (We maintain stack for keeping track of the path)
            Node *f = new Node();
            f->data = n->data;
            f->next = stack->head;
            stack->head = f;

            // If the 'next' node is not null, recursively call dfs for that node
            if(n->next!=NULL) dfs(g, n->next, root, vis, stack);
            // If the 'second' node is not null and is not same as the first node, recursively call dfs on that node
            if(n->second!=NULL && (n->next == NULL || n->second->data!=n->next->data)) dfs(g, n->second, root, vis, stack);

            // Undo the operations for backtracking
            vis[n->data-1] = false;
            f = stack->head;
            stack->head = stack->head->next;
            delete(f);

        }

    }

    // A function that finds all the unique cycles in the Linked List
    void find_cycles(){

        // Clone the linked list and initialize the stack
        LinkedList *c = this->clone();
        LinkedList *stack = new LinkedList(0);

        // Initialize the boolean 'vis' array to keep track of the nodes that are visited
        bool vis[n] = {0};

        // Apply dfs on the linked list and delete the node which is considered as root to avoid duplicates
        // Loop till the cloned linked list is empty
        while(c->head!=NULL){

            // Call dfs
            dfs(c, c->head, c->head, vis, stack);

            // Delete the root
            Node *itr = c->head;
            while(itr!=NULL){
                if(itr->second == c->head){
                    itr->second = NULL;
                }
                itr = itr->next;
            }
            itr = c->head;
            c->head = c->head->next;
            delete(itr);

        }

    }

};

int main(){
    
    int n; // The number of nodes in the Linked List
    // Input: n
    cin>>n;

    // Make a new Linked List
    LinkedList *l = new LinkedList(n);

    // Initialize the Linked List
    l->initialize();

    // Print the Linked List
    cout<<"The original Linked List: "<<endl;
    l->print();

    // Clone the Linked List
    LinkedList *copy = l->clone();

    // Print the cloned Linked List
    cout<<"The cloned Linked List: "<<endl;
    copy->print();

    int r; // Element to be deleted from the cloned Linked List
    // Input: r
    cin>>r;

    // Remove the element from the cloned Linked List
    copy->remove(r);

    // Print the clone after element removal
    cout<<"The cloned Linked List after element removal: "<<endl;
    copy->print();
    
    // Print the highest referenced node in the original Linked List
    l->highest_referenced();

    // Find the unique cycles in the original Linked List
    l->find_cycles();

    // Print the unique cycles in the Linked List
    cout<<"Total number of unique cycle are: "<<l->number_of_cycles<<endl;
    cout<<l->cycles<<endl;

    return 0;

}
