// Shashank Aital - 19114076 - Sophomore, B. Tech.,
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee

import java.util.Scanner;

class P3 {

    // Static state variables to store the inorder traversal and a global iterator (To keep track of indices inside a recursive function)
    static int in_order[];
    static int itr;

    // Utility: Quicksort: Partition function
    // Considers the last element as pivot
    // variable i keeps track of the index of elements that are strictly less than the pivot
    static int partition(int a[], int left, int right){

        int p = a[right];
        int i = left - 1;

        for(int j = left; j < right; j++){
            if(a[j] < p){
                i++;
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }

        int temp = a[i+1];
        a[i+1] = a[right];
        a[right] = temp;

        return i+1;

    }

    // Utility: Quicksort: Driver code
    static void quicksort(int a[], int left, int right){

        if(left < right){
            int p = partition(a, left, right);

            quicksort(a, left, p-1);
            quicksort(a, p+1, right);
        }

    }

    // Utility: Find an element 'x' in an array 'a'
    static int find_element(int a[], int n, int x){

        for(int i = 0; i < n; i++){
            if(a[i] == x) return i;
        }
        return -1;

    }
    
    // Function to find the in order traversal of the given binary tree
    static void find_inorder(int a[], int root, int n){

        // If there is a left child, find the inorder traversal of the subtree with the left child as root
        if(2*root+1 < n){
            find_inorder(a, 2*root+1, n);
        }

        // Traverse the root
        in_order[itr++] = a[root];

        // If there is a right child, find the inorder traversal of the subtree with the right child as root
        if(2*root+2 < n){
            find_inorder(a, 2*root+2, n);
        }

    }

    // Function to find the minimum number of swaps required to convert a binary tree into a binary search tree
    static int min_swaps(int n){

        // The inorder traversal of a binary search tree is in ascending order
        // We need to find the number of swaps required to sort the inorder traversal of our tree in ascending order
        int swaps = 0;
        
        // We make 2 arrays identical to the array containing the inorder traversal
        int t[] = in_order.clone();
        int s[] = in_order.clone();

        // Sort one of the arrays
        quicksort(t, 0, n-1);

        // Loop through the unsorted array and find which elements are not placed correcly
        // If they are not placed correctly, swap them with the element that belongs to that position
        // To find the element to be swapped, we use the sorted array
        for(int i = 0; i < n; i++){
            if(t[i] != s[i]){
                
                int pos = find_element(s, n, t[i]);

                int temp = s[i];
                s[i] = s[pos];
                s[pos] = temp;
                swaps++;
            }
        }

        return swaps;

    }

    public static void main(String args[]){

        // Define scanner
        Scanner sc = new Scanner(System.in);

        // Input: n: Number of nodes
        int n = sc.nextInt();
        // a: Binary Tree in given format
        int a[] = new int[n];
        in_order = new int[n];

        for(int i = 0; i < n; i++){
            a[i] = sc.nextInt();
        }
        sc.close();

        // Find the inorder traversal of the given binary tree
        find_inorder(a, 0, n);

        // Find the minimum number of swaps
        int ms = min_swaps(n);

        System.out.println(ms);
        
    }

}
