// Shashank Aital - 19114076 - Sophomore, B. Tech.,
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee

import java.util.Scanner;

class P2 {

    // Search for an element in the array 'in' between the indices 'left_in' and 'right_in'
    static int search(int in[], int x, int n, int left_in, int right_in){

        for(int i = left_in; i <= right_in; i++){
            if(in[i] == x){
                return i;
            }
        }
        return -1;

    }
    
    // Function to find the post order traversal from the preorder traversal 'pre' and inorder traversal 'in'
    static void post_order(int pre[], int in[], int left_in, int right_in, int left_pre, int n){

        // The leftmost element in the preorder traversal is the root of the (sub)tree that we are looking at
        // Search the position of that root in the inorder traversal to find the left subtree and the right subtree
        int root = search(in, pre[left_pre], n, left_in, right_in);

        // If root does not exist, throw an error
        if(root == -1){
            System.out.println("Invalid input");
            return;
        }

        // If there is a left subtree, run this function on the left subtree
        if(root!=left_in){
            post_order(pre, in, left_in, root-1, left_pre+1, n);
        }

        // If there is a right subtree, run this function on the right subtree
        if(root!=right_in){
            post_order(pre, in, root+1, right_in, left_pre+root-left_in+1, n);
        }

        // Traverse (in this case, print) the root
        System.out.print((pre[left_pre]+1) + " ");

    }

    public static void main(String args[]){
        
        // Define a scanner to take inputs
        Scanner sc = new Scanner(System.in);
        // Input n: number of nodes
        int n = sc.nextInt();
        // pre[]: The preorder traversal of the tree
        int pre[] = new int[n];
        // in[]: The inorder traversal of the tree
        int in[] = new int[n];

        // Take inputs
        for(int i = 0; i < n; i++){
            in[i] = sc.nextInt()-1;
        }
        for(int i = 0; i < n; i++){
            pre[i] = sc.nextInt()-1;
        }
        sc.close();

        post_order(pre, in, 0, n-1, 0, n);

    }

}
