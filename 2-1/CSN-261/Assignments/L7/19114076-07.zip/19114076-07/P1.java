// Shashank Aital - 19114076 - Sophomore, B. Tech.,
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee

import java.util.Scanner;

class P1{
    
    // Function to find the minimum number of nodes in an AVL tree having height 'h'
    static int avl_min_nodes(int h){

        // Base cases
        if(h==0){
            return 1;
        }else if(h==1){
            return 2;
        }

        // nodes[h] = nodes[h-1] + nodes[h-2] + root
        return (avl_min_nodes(h-1) + avl_min_nodes(h-2) + 1);
    }

    public static void main(String args[]){
        
        // Define a scanner
        Scanner sc = new Scanner(System.in);
        // Input
        int h = sc.nextInt();
        sc.close();
        // Print the answer
        System.out.println("Minimum Number of Nodes in AVL Tree of height " + h + " is " + avl_min_nodes(h));

    }

}
