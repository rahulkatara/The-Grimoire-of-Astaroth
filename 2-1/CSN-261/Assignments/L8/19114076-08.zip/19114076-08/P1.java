// Shashank Aital - 19114076 - Sophomore, B. Tech.,
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee

import java.util.Scanner;

class P1{

    // Utility function to implement "Partition" Operation in Quicksort
    static int partition(int a[], int left, int right){

        int p = a[right];
        int i = left - 1;

        for(int j = left; j < right; j++){
            if(a[j] < p){
                i++;
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }

        int temp = a[i+1];
        a[i+1] = a[right];
        a[right] = temp;

        return i+1;

    }

    // A function to sort an array using Quicksort algorithm
    static void quicksort(int a[], int left, int right){

        if(left < right){
            int p = partition(a, left, right);

            quicksort(a, left, p-1);
            quicksort(a, p+1, right);
        }

    }

    // Here are a couple of utility functions to rearrange elements of an array by sorting another array
    // We are basically simulating a hashmap using 2 arrays and sorting this hashmap using Quicksort algorithm to sort this Hashmap according to its keys

    // A utility function to implement "Partition" Operation of the custom Quicksort
    static int partition_sync(int a[], int depths[], int left, int right){

        int p = depths[right];
        int i = left - 1;

        for(int j = left; j < right; j++){
            if(depths[j] <= p){
                i++;

                int temp = depths[i];
                depths[i] = depths[j];
                depths[j] = temp;

                temp = a[i];
                a[i] = a[j];
                a[j] = temp;

            }
        }

        int temp = depths[i+1];
        depths[i+1] = depths[right];
        depths[right] = temp;

        temp = a[i+1];
        a[i+1] = a[right];
        a[right] = temp;

        return i+1;

    }

    // Driver function for custom Quicksort
    // Sorts a according to the corresponding entries in the 'depths' array
    static void quicksort_sync(int a[], int depths[], int left, int right){

        if(left < right){
            int p = partition_sync(a, depths, left, right);

            quicksort_sync(a, depths, left, p-1);
            quicksort_sync(a, depths, p+1, right);
        }

    }

    // A function to calculate depth of various vertices once inserted in the AVL Tree
    static void depth_calculator(int a[], int depths[], int left, int right, int depth){

        // Find the element in the middle (or near middle in case of even elements)
        int r = (left + right) / 2;

        if(left>right){
            return;
        }else if(left == right){
            // Only one element left (leaf node) => return
            depths[r] = depth;
            return;
        }else{
            // Assign depth of the middle element and call this function recursively for the left and right halves

            depths[r] = depth;

            depth_calculator(a, depths, left, r-1, depth+1);
            depth_calculator(a, depths, r+1, right, depth+1);

            return;
        }

    }

    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);

        // Input: n: Number of nodes
        int n = sc.nextInt();

        int a[] = new int[n];
        // Input: a: The given array of numbers
        for(int i = 0; i < n; i++){
            a[i] = sc.nextInt();
        }
        sc.close();

        // Sort the given array
        quicksort(a, 0, n-1);

        // Calculate the depths of the given elements when inserted in an AVL tree
        int depths[] = new int[n];
        depth_calculator(a, depths, 0, n-1, 0);

        // Sort the nodes according to their depth
        // Logic: As long as we insert nodes layer by layer (as obtained from the AVL tree) in a simple Binary Search Tree,
        //        the Binary Search Tree remains an AVL Tree. Hence, we get the desired insertion order after sorting the nodes as per their depths
        quicksort_sync(a, depths, 0, n-1);

        // Print all the elements
        for(int i = 0; i < n; i++){
            System.out.print(a[i] + " ");
        }
        System.out.println();

        /**
         * NOTE:
         * 
         * The output that the code gives is:  4 1 7 0 5 2 8 3 6 9
         * The given output in the problem is: 4 1 7 0 2 5 8 3 6 9
         * 
         * Both of these sequences, when inserted into a binary tree give the same AVL Tree. Hence, both are correct.
         * 
         * I have used Quicksort in order to achieve O(n*log(n)) time complexity, which is not stable. Hence my answer differs from the problem statement.
         * We could achieve the same answer as the problem statement by employing a stable sorting algorithm.
         */

    }
}