// Shashank Aital - 19114076 - Sophomore, B. Tech.,
// The Department of Computer Science and Engineering,
// Indian Institute of Technology, Roorkee

import java.util.Scanner;

// A utility class to implement Stack
class Stack{
    private int max_length;
    private int[] stack_array;
    private int top;

    // Initialize with maximum length of stack
    public Stack(int max_length){

        this.max_length = max_length;
        this.stack_array = new int[max_length];
        this.top = -1;

    }

    // Utility functions to implement stack functionalitites
    public void push(int x){
        stack_array[++top] = x;
    }

    public int pop(){
        return stack_array[top--];
    }

    public boolean is_empty(){
        return top == -1;
    }

    public boolean is_full(){
        return top == max_length - 1;
    }

}

class P2{

    // State variables:
    // n: number of nodes in the graph
    // g: Adjacency matrix representing the graph
    static int n;
    static int g[][];

    // A function to implement DFS and finally push the node inside a stack
    static void topological_sort(int vertex, Stack r, boolean visited[]){

        visited[vertex] = true;

        for(int i = 0; i < n; i++){
            if(g[vertex][i] == 1){
                if(!visited[i]){
                    topological_sort(i, r, visited);
                }
            }
        }

        // Since we are inserting the element after we have traversed its children recursively, this element will be on the top of all the children in the stack
        // This means that all of its children will be on the right when we empty the stack (Topological Sort)
        r.push(vertex);

    }

    // Driver code to perform topological sorting of the graph's vertices
    static void topological_sort_driver(){

        // Initialize the stack in which we will be pushing the vertices once the DFS of that vertex is complete
        Stack r = new Stack(n);

        // An array to determine if a vertex is visited
        boolean visited[] = new boolean[n];
        for(int i = 0; i < n; i++){
            visited[i] = false;
        }

        // Loop through the nodes. If the node is not visited, implement DFS
        for(int i = 0; i < n; i++){
            if(!visited[i]){
                topological_sort(i, r, visited);
            }
        }

        // Empty the stack and print the topologically sorted order of the nodes
        while(!r.is_empty()){
            System.out.print(r.pop() + " ");
        }
        System.out.println();

    }

    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);
        // Input: n: Number of nodes in the graph
        n = sc.nextInt();

        g = new int[n][n];
        
        // Input: g: Adjacency matrix for the Directed Graph
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                g[i][j] = sc.nextInt();
            }
        }
        sc.close();

        // Print the Topologically Sorted Order of nodes
        topological_sort_driver();

    }
}
