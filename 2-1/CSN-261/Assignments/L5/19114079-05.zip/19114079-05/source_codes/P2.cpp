/*****************************************************************

	CSN-261 Lab 5 Question 2 : Krushkal's Algorithm Using Union Find
	P2.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

/****************************************************************/

#include <iostream>
using namespace std;

class UnionFind {
  private:
    int numberOfNodes; // Number of nodes in graph
    int numberOfComponents; // Number of componenets in the graph
    int* size; // Size of the component whose value of index will represent the root node
    int* id; // Stores parent node of each node
  public:
    UnionFind (int n) {
      numberOfComponents = n;
      numberOfNodes = n;

      id = new int[n+1]; // n+1 for 1-indexed array
      size = new int[n+1]; // n+1 for 1-indexed array

      for (int i=0; i<n+1; i++) {
        id[i] = i; // each element is initially its own root
        size[i] = 1; // size of each component is initially 1
      }
    }
    /**
     * Takes value of node p and returns its root node while
     * simultaneously performing path compression
     **/
    int find (int p) {
      int root = p;
      while (root != id[root]) { // Root node has id[i] = i.
        root = id[root]; // Traverse the component until root node is found.
      }

      while (p != root) { // Path compression
        int next = id[p];
        id[p] = root; // Set ID of every node in that path to root node.
        p = next;
      }

      return root;
    }

    // Two nodes are connected (in the same component) if their roots are the same
    bool connected (int p, int q) {
      return find(p) == find(q);
    }

    // Merge two components together
    void unify (int p, int q) {
      int root1 = find(p);
      int root2 = find(q);

      if (root1 == root2) return; // Already in the same component.

      if (size[root1] > size[root2]) { // Merge the smaller component into the larger component
        size[root1] += size[root2];
        id[root2] = root1;
      } else {
        size[root2] += size[root1];
        id[root1] = root2;
      }
      return;
    }
};

struct Edge {
  int a; // first node
  int b; // second node
  int w; // weight
  struct Edge* next;
};

class EdgeList {
  public:
    struct Edge* front;
    int length;
  public:
    EdgeList () {
      front = NULL;
      length = 0;
    }
    int get_length() {
      return length;
    }
    /**
     * Push edges onto list using insertion sort
     * When we pop edges, we get them in increasing
     * order of weights
     **/
    void push (int a, int b, int w) {
      struct Edge *e = new Edge();
      e->a = a;
      e->b = b;
      e->w = w;
      length++;
      if (front == NULL) { // LIST INITIALLY EMPTY
        front = e;
        e->next = NULL;
      } else if (front->next == NULL) { //ONLY ONE ELEMENT IN LIST
        if (front->w > w) {
          e->next = front;
          front = e;
        } else {
          front->next = e;
          e->next = NULL;
        }
      } else { // More elements in the list
        if(front->w > w){
          e->next = front;
          front = e;
          return;
        }

        struct Edge *curr = front;
        struct Edge *temp = front;
        while (curr->next != NULL) {
          if (curr->w > e->w) {
            temp->next = e;
            e->next = curr;
            return;
          }
          temp = curr;
          curr = curr->next;
        }

        // All elements travsersed, so node must belong at the end
        if(curr->w < e->w){ 
          curr->next = e;
          e->next = NULL;
        } else {
          temp->next = e;
          e->next = curr;
        }
        return;
      }
    }
    struct Edge* pop () {
      if (front == NULL) { // List empty
        return NULL;
      }

      struct Edge *e = new Edge();
      e->a = front->a;
      e->b = front->b;
      e->w = front->w;
      front = front->next;
      length--;
      return e;
    }
};

void print_node (string s) {
  cout << s;
  int spaces = 6 - s.length();
  while (spaces--) cout << " ";
}

void generate_mst (EdgeList el, UnionFind uf) {
  EdgeList mst;
  struct Edge *e;
  int edge_count = el.get_length();
  int a, b, w;

  for (int i=0; i<edge_count; i++) {
    // EDGELIST STORES THEM IN INCREASING ORDER OF SIZE
    // SO WE GET SMALLEST EDGES FIRST
    e = el.pop();
    a = e->a;
    b = e->b;
    w = e->w;

    if (uf.connected(a, b)) continue; // IF THE NODES ALREADY BELONG TO THE SAME COMPONENT, CONTINUE
    
    uf.unify(a, b); // NODES ARE NOT ALREADY IN THE SAME COMPONENT, SO UNIFY THEM
    mst.push(a, b, w); // PUSH EDGE INTO OUR MST
  }

  // ALL OUTPUT NOW
  cout << "\nNodes in MST followed by dot code:\n";
  cout << "Node1 Node2 Weight\n";
  int total_weight=0;
  int mst_length = mst.get_length();
  string dot_code = "";
  dot_code += "graph mst {\n";
  dot_code += "\toverlap=\"scale\";\n";
  
  for (int i=0; i<mst_length; i++) {
    e = mst.pop();
    a = e->a;
    b = e->b;
    w = e->w;
    total_weight += w;

    dot_code += "\t" + to_string(a) + " -- " + to_string(b) + " [label=\"  " + to_string(w) + "  \"];\n";
    print_node(to_string(a));
    print_node(to_string(b));
    cout << w;
    cout << "\n";
    
  }
  dot_code += "}";
  cout<<"Total edge weight of the MST: "<<total_weight<<"\n";
  cout << "\nDot code to be copy-pasted:\n" << dot_code << "\n";
}

int main() 
{ 
  int a, b, w;
  EdgeList el;
  int max_node;
  while (cin>>a>>b>>w) {
    el.push(a, b, w);
    if (max_node < a) max_node = a;
  }
  
  UnionFind uf(max_node);

  generate_mst(el, uf);

	return 0;
}
