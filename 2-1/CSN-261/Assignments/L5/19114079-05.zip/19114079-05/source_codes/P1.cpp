/******************************************************

	CSN-261 Lab 5 Question 1 : Graph Traversal Algorithms
	P1.cpp
	Shreyas Dodamani
	19114079
	shreyas_d@cs.iitr.ac.in 

/*****************************************************/

#include <iostream>
using namespace std;

class Queue {
  private:
    struct Element {
      int id;
      struct Element* next;
    };
    struct Element* front;
    struct Element* rear;
  public:
    Queue () {
      front = NULL;
      rear = NULL;
    }

    bool empty () {
      return this->front == NULL;
    }

    void enqueue(int id){
      struct Element* e = new Element();
      e->id = id;
      e->next = NULL;
      if(this->front == NULL){ //INSERT ELEMENT WHEN QUEUE IS EMPTY
        this->front = e;
        this->rear = e;
      } else { // INSERT ELEMENT WHEN QUEUE IS NOT EMPTY
        this->rear->next = e;
        this->rear = e;
      }
      return;
    }
    
    int dequeue(){ 
      int id = this->front->id;
      if(this->front == this->rear){ // REMOVE ELEMENT WHEN ONLY ONE ITEM IN QUEUE
        //SET BOTH POINTERS TO NULL
        this->front = NULL;
        this->rear = NULL;
      } else { //REMOVE ELEMENT WHEN MORE THAN ONE ELEMENT PRESENT IN QUEUE
        this->front = this->front->next;
      }
      return id; //RETURN POPPED ELEMENT ID
    }
};

class Graph {
  private:
    struct Node {
      int id;
      struct Node* next;
    };
    struct Node** list;
    int n; // number of nodes
    bool* dfs_vis;
  public:
    Graph (int edge_count) {
      // Because total number of nodes can be e+1 when it's a tree  
      // but I want my array to be 1-indexed so I created a an array of e+2 size
      this->n = edge_count+2;
      this->dfs_vis = new bool[n];
      list = new Node*[n];

      for (int i=0; i<n; i++) {
        list[i] = NULL;
        dfs_vis[i] = false;
      }
    }

    void create_edge (int a, int b) {
      if (list[a] == NULL) {
        list[a] = new Node();
        list[a]->next = NULL;
        list[a]->id = a;
      }
      if (list[b] == NULL) {
        list[b] = new Node();
        list[b]->next = NULL;
        list[b]->id = b;
      }
      struct Node *new_node = new Node();
      new_node->id = b;
      new_node->next = list[a]->next;
      list[a]->next = new_node;

      new_node = new Node();
      new_node->id = a;
      new_node->next = list[b]->next;
      list[b]->next = new_node;
    }

    void show_graph () {
      cout << "Size " << this->n << "\n";
      for (int i=0; i<this->n; i++) {
        cout << i <<"... ";
        if (list[i] == NULL) {
          cout << "\n";
          continue;
        } 
        struct Node *node = list[i]->next;
        while (node != NULL) {
          cout << node->id << " ";
          node = node->next;
        }
        cout << "\n";
      }
      return;
    }

    void bfs (int s) {
      bool vis[this->n] = {false};
      Queue q;
      q.enqueue(s);
      vis[s] = true;  
      cout << s << " ";
      int v;
      while (!q.empty()) {
        v = q.dequeue();
        struct Node *node = this->list[v]->next;
        while (node != NULL) {
          int t = node->id;
          node = node->next;
          if (vis[t]) continue;
          vis[t] = true;
          q.enqueue(t);
          cout << t << " ";          
        }
      }
      return;
    }

    void dfs (int s) {
      if (this->dfs_vis[s]) return;

      cout << s << " ";
      this->dfs_vis[s] = true;
      struct Node *node = this->list[s]->next;
      while (node != NULL) {
        this->dfs(node->id);
        node = node->next;
      }
      return;
    }

    bool cycle_find () {
      bool vis[this->n] = {false};
      int parent[this->n] = {0};

      Queue q;
      q.enqueue(1);
      vis[1] = true;  
      parent[1] = -1;
      
      int v;
      while (!q.empty()) {
        v = q.dequeue();
        struct Node *node = this->list[v]->next;
        while (node != NULL) {
          int t = node->id;
          node = node->next;
          
          if (vis[t]) {
            if (t == parent[v]) {
              continue;
            } else {
              return true;
            }
          }
          parent[t] = v;
          vis[t] = true;
          q.enqueue(t);
        }
      }
      return false;
    }

    void pds (int s, int i) {
      if (s == n-1) cout << i << "\n";
      return;
    }

    int max_depth (int s) {
      int depth[this->n] = {0};
      bool vis[this->n] = {false};

      Queue q;
      q.enqueue(s);
      vis[s] = true;  

      int v;
      while (!q.empty()) {
        v = q.dequeue();
        int d = depth[v] + 1;
        if (this->list[v] == NULL) continue;
        struct Node *node = this->list[v]->next;
        while (node != NULL) {
          int t = node->id;
          node = node->next;
          if (vis[t]) continue;
          vis[t] = true;
          depth[t] = d;
          q.enqueue(t);          
        }
      }
      int max_depth_value = 0;
      for (int i=1; i<n; i++) {
        if (depth[i] > max_depth_value) {
          max_depth_value = depth[i];
        }
      }
      return max_depth_value;
    }

    int get_diameter () {
      int current_max_depth = -1, diameter = -1;
      for (int i=1; i<this->n; i++) {
        current_max_depth = this->max_depth(i);
        if ( diameter < current_max_depth) diameter = current_max_depth;
      }
      return diameter;
    }
};

int main() 
{
  int total_edges;
  cin>>total_edges;

  // Initialise graph
  Graph g(total_edges);

  int a, b;
  int total_nodes=0;
  while (total_edges--) {
    cin>>a>>b;
    g.create_edge(a, b);
  }

  // //SHOW GRAPH
  // cout << "\nGraph structure:\n";
  // g.show_graph();

  // BFS
  cout << "1. BFS: ";
  g.bfs(1);

  // DFS
  cout << "\n2. DFS: ";
  g.dfs(1);

  // CYCLE FIND
  cout << "\n3. Cycle found: ";
  cout << ( g.cycle_find() ? "Yes" : "No" );

  // DIAMETER
  cout << "\n4. Diameter: " << g.get_diameter();

  cout<<"\n";
	return 0;
}
