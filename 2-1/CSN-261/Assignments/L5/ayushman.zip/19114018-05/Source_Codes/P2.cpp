#include<iostream>
using namespace std;

/*
    To implement using Kruskal's algorithm we would need the edge with minimum weight at every iteration of edge addition.
    For this we would need a Priority Queue.
    Here I have implemented the same using linked-lists to reduce the code-complexity
    The best time-efficient implementation would be by using Minimum-Heaps, that can do an insertion and deletion in complexity log(n)
    Also, another method would have been to insert all edges and then sort them using Quick Sort or similar algorith which does the work in O(n log n)
    My implementation would achieve insertion in O(n) and deletion in O(1) complexity.
*/


struct edge{
    int x,y;
    int weight;
    edge* next;
};

class Prioity_Queue{
    private:
        edge* top;  //  Would always point to the smallest edge in the list
        
    public:
        bool isEmpty(){
            if(top == NULL)    
                return 1;
            else 
                return 0;
        }
        void Push(int a , int b, int w){
            struct edge* node = new edge{};
            node->x = a;
            node->y = b;
            node->weight = w;

            if(isEmpty()){
                top = node;
            }
            else if(top->weight >= node->weight){
                node->next = top;
                top = node;
            }
            else{
                edge* temp = top;
                while(temp->next != NULL){
                    if(temp->next->weight >= node->weight){
                        
                        node->next = temp->next;
                        temp->next = node;
                        
                        return;
                    }
                    else{
                        temp = temp->next;
                    }
                }
                
                temp->next = node;                           
            }
            
        }

        //  Always returns the vertex with minimum weight
        edge* Pop(){
            edge* temp = top;
            top = top->next;

            return temp;
        }
};

class Kruskal{
    private:
        int n; 

        int* parent;
        int* size;
        
        Prioity_Queue* PQ;

        int MST_Weight = 0;
        edge** MST_Edges;

    public:
        Kruskal(int n, Prioity_Queue* edge_list){
            this->n = n;
            PQ = edge_list;

            parent = new int[n+1];
            size = new int[n+1];
            MST_Edges = new edge*[n-1];

            for(int i = 1; i <= n; ++i ){
                parent[i] = i;
                size[i] = 1;
            }
            
        }

        int Find_Root(int v){
            while(parent[v] != v){
                parent[v] = parent[parent[v]];
                v = parent[v];
            }
            return v;
            /*
                This is an advanced form of root finding called path compression where we assign the parent of vertex as the grand parent.
                This in turn reduces the complexity of the algoritm to log*(n) or iterative log(n).
                Thus a very efficient root finding method
            */
        }

        void Union_Sets(int a, int b){
            int root_a = Find_Root(a);
            int root_b = Find_Root(b);

            //  Swapping, to ensure that always smaller set is merged into larger set, we make a as the larger set by default and merge b into a
            if(size[root_a] < size[root_b]){
                root_a = root_a + root_b;
                root_b = root_a - root_b;
                root_a = root_a - root_b;
            }   
            
            parent[root_b] = parent[root_a];
            size[root_a] += size[root_b];
        }

        void find_MST(){
            struct edge* node = new edge{}; 
            for(int i = 0 ; i < n-1 ; ++i){
                //  Each iteration would add one edge to our MST, thus n-1 iterations for complete MST
                node = PQ->Pop();

                while(Find_Root(node->x) == Find_Root(node->y)){
                    node = PQ->Pop();
                }
                //  If roots are different then they belong to different sets.
                //  This is how cycle formation is prevented.
                
                MST_Edges[i] = node;
                MST_Weight += node->weight;
                Union_Sets(node->x, node->y);
            }

        }

        void Total_Output(){

            cout<<"Edges in MST: "<<endl<<endl;

            cout<<"Node1"<<" "<<"Node2"<<" "<<"Weight"<<endl;

            for(int i = 0; i < n-1; ++i){
                cout<<"  "<<MST_Edges[i]->x<<"     "<<MST_Edges[i]->y<<"      "<<MST_Edges[i]->weight<<endl;
            }

            cout<<endl<<"Total edge weight of the MST is : "<<MST_Weight<<endl<<endl;
            cout<<"DOT FILE CODE: "<<endl<<endl;
            cout<<"graph MST_Kruskal{ "<<endl<<endl;
            cout<<"\toverlap = \"scale\""<<endl;
            cout<<"\tsize = \"1,1\";"<<endl<<endl;
            for(int i =0 ; i < n - 1 ; ++i){
                cout<<"\t"<<MST_Edges[i]->x<<" -- "<<MST_Edges[i]->y<<" [label = \""<<MST_Edges[i]->weight<<"\"]"<<endl;
            }
            cout<<endl<<"}"<<endl;
        }
};
int main(){

    #ifndef ONLINE_JUDGE
        freopen("P2_Input.txt","r",stdin);
    #endif 

    Prioity_Queue* edge_list = new Prioity_Queue();

    int a,b,w;
    int n = 0;

    while( cin >> a >> b >> w){
        edge_list->Push(a,b,w);
        if(a > n)
            n = a;
        if(b > n)
            n = b;
    }

    Kruskal MST(n,edge_list);
    
    
    MST.find_MST();

    MST.Total_Output();

    return 0;
}