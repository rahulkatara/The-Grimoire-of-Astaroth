#include<iostream>
using namespace std;

struct node{
    int key;
    node* next;
};
//  Node here represents a node/vertex of the graph


//  This Queue is a utility queue, that I would be using for my BFS traversal.

class Queue{
    public:
        node* front;
        node* back;

        int size = 0;
    
        bool Empty(){
            if(size)
                return 0;
            else 
                return 1;
        }

        void Push(int id){
            struct node* x = new node{};
            x->key = id;

            if(Empty()){
                front = x;
                back = x; 
            }
            else{
                back->next = x;
                back = x;
            }
            size++;
        }

        void Pop(){
            node* temp = front;
            front = front->next;
            
            size--;
            delete temp;
        }

};
class Graph{
    private:
        node** adj; //pointer to the array of pointers, which in turn points to adjacency list for the respective node
        int n;

        int* visited;
        int* level;

    
    public:

        Graph(int n){
            this->n = n;    
           
            adj = new node*[n+1];

            visited = new int[n+1];
            level = new int[n+1];

        }
        void Initialize(){
            for(int i = 1; i <= n; ++i){
                visited[i] = 0;
                level[i] = 0;
            }
        }
        void Add_Edge(int x,int y){
                
            struct node* a = new node{};
            a->key = x;
            
            struct node* b = new node{};
            b->key = y;

            if(adj[x] == NULL){
                adj[x] = b;
            }
            else{
                b->next= adj[x];
                adj[x] = b; 
            }

            if(adj[y] == NULL){
                adj[y] = a;
            }
            else{
                a->next= adj[y];
                adj[y] = a; 
            }

        }
        void BFS(int source, bool print){
            Queue q;

            struct node* temp = new node{};
            temp->key = source;
            
            q.Push(temp->key);
            visited[temp->key] = 1;
            level[temp->key] = 0;

            int vertex;
            while(!q.Empty()){
                vertex = q.front->key;
                if(print)
                    cout<<vertex<<" ";

                temp = adj[vertex];
                while(temp != NULL){
                    if(!visited[temp->key]){
                        q.Push(temp->key);
                        visited[temp->key] = 1;
                        level[temp->key] = level[vertex] + 1;
                    }
                    temp = temp->next;
                }
                q.Pop();
            }

        }

        /*
            For DFS traversal no external stack is required here, 
            As the function call stack does the work of an external stack for our algorithm.
        */

        void DFS(int source){
            visited[source] = 1;
            cout<<source<<" ";

            node* temp = adj[source];

            while(temp != NULL){
                if(!visited[temp->key]){
                    DFS(temp->key);
                }
                temp = temp->next;
            }
        }

        bool Has_Cycle(int source,int parent){
            visited[source] = 1;

            node* temp = adj[source];

            while(temp != NULL){
                if(visited[temp->key] == 1){
                    if(temp->key != parent)
                        return 1;
                    // if an already visited vertex was encountered in the traversal, other than the parent vertex, then cycle is found.
                }
                else{
                    if(Has_Cycle(temp->key,source))
                        return 1;
                    // This will check for cycle starting at vertex temp->key and if found terminate the whole function and returns 1, if not found, it will continue normally
                }
                temp = temp->next;
            }

            return 0;
        }
        /*
            For finding Diameter, we run BFS from each vertex and update the max_level each time
            The max level after all BFS traversals is the diameter 
        */
        int Diameter(){
            int max_level = 0;

            for(int i = 1; i <= n ; ++i){
                
                Initialize();
                BFS(i,0);
                for(int j = 0; j <= n; ++j ){
                    if(level[j] > max_level){
                        max_level = level[j];
                    } 
                }

            }
            
            int diameter = max_level;

            return diameter;
        }
        //  In case of a graph having a cycle, diameter is defined as the maximum amongst the shortest distance between vertices.
};

int main(){

    #ifndef ONLINE_JUDGE
        freopen("P1_Input.txt","r",stdin);
    #endif 
    //  This piece of code helped me to directly take input from file to stdin in terminal
    //  This won't affect the IDE input as, the file if not available theere, so the stdin would have the only custom input
    //  So, I have kept this code in P1 too.


    int n = 0;  //  Number of Nodes in Graph
    
    int m = 0;  //  Number of Edges
    cin>>m;

    int a[m],b[m];

    for( int i = 0 ; i < m; ++i ){
        cin>>a[i]>>b[i];
        if(a[i] > n){
            n = a[i];
        }
        if(b[i] > n){
            n = b[i];
        } 
    }

    Graph g(n);

    for(int i = 0 ; i < m ; ++i){
        g.Add_Edge(a[i],b[i]);
    } 

    g.Initialize();
    cout<<"1. ";
    g.BFS(1,1);
    cout<<endl;

    g.Initialize();
    cout<<"2. ";
    g.DFS(1);
    cout<<endl;

    g.Initialize();
    cout<<"3. ";
    if(g.Has_Cycle(1,0))
        cout<<"Yes"<<endl;
    else 
        cout<<"No"<<endl;

    /*
        We don't even need to run the hasCycle() function to check for cyclicity if the graph here.
        As we have a connected graph, with n vertices(calculated) and m edges(given),
        If m > n - 1, then we can simply say that the graph has a cycle, as n - 1 edges would make it a tree and thus just connected 
        And adding one more edge would either induce a self loop(can be considered a cycle of length 2) or a cycle.  
    */

    g.Initialize();
    cout<<"4. ";
    cout<<"Diameter: "<<g.Diameter()<<endl;

    return 0;
}
/*
    I have written all algorithms based on the fact that the graph is connected.
    In case of a disconnected graph, we just would have to iterate through the  vertices to check if they are visited or not.
    If not visited, we call the respective algorithms again.
*/