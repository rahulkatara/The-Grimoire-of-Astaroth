// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

// Lab 5 - Problem 2

#include <iostream>
using namespace std;

// Structure storing the implementation of edge
struct edge{
    int a, b, w;
    edge *next;
};

// Structure storing the implementation of a subset (used in union-find algorithm)
struct subset{
    int parent, rank;
};

// Utility function to hold all the edges in ascending order of their weights
class Edge_List{

    public:
    edge *head;

    Edge_List(){
        head = NULL;
    }

    void insert(int a, int b, int w){

        edge *x = new edge();
        x->a = a;
        x->b = b;
        x->w = w;

        edge *itr = head, *prev = head;

        while(itr!=NULL && itr->w<w){
            prev = itr;
            itr = itr->next;
        }

        if(prev==NULL){

            x->next = NULL;
            head = x;

        }else if(prev==head){

            if(w>prev->w){
                x->next = head->next;
                head->next = x;
            }else{
                x->next = head;
                head = x;
            }

        }else{

            x->next = prev->next;
            prev->next = x;

        }

    }

};

// A class to implement a graph
class Graph{

    public:
    int e, v;

    Edge_List *edges;

    Graph(int e, int v, Edge_List *edges){
        this->e = e;
        this->v = v;

        this->edges = edges;
    }

    // Function to implement the "Find part" in Union-Find Algorithm
    // Note: The Find Function implementation uses Path Compression
    int Find(subset subsets[], int i){

        // Compress the path for all the nodes traversed while finding the root of a given node
        if(subsets[i].parent != i){
            subsets[i].parent = Find(subsets, subsets[i].parent);
        }

        return subsets[i].parent;
    }

    // Function to implement the "Union part" in Union-Find Algorithm
    // Note: The Union Function uses Ranks of subsets to decide the final root
    void Union(subset subsets[], int x, int y){

        int x_root = Find(subsets, x);
        int y_root = Find(subsets, y);

        // The subset root with higher rank becomes the root
        // If the ranks of both the subsets are same, an arbitrary subset's root is chosen and is decided to be root. It's rank is incremented by 1
        if(subsets[x_root].rank > subsets[y_root].rank){
            subsets[y_root].parent = x_root;
        }else if(subsets[x_root].rank < subsets[y_root].rank){
            subsets[x_root].parent = y_root;
        }else{
            subsets[y_root].parent = x_root;
            subsets[x_root].rank++;
        }

    }

    // Function to implement Kruskal's algorithm to find a MST of the graph
    edge *Kruskal(){

        // Array of edges reflecting the final MST
        edge *ans = new edge[v-1];
        // Array of subsets of size equal to the number of vertices
        // subsets[i] depicts the parent and the rank of the ith vertex
        subset *subsets = new subset[v];

        // Set the parent of each subset equal to the vertex in it
        // Initialize the ranks to zero
        for(int i = 0; i < v; i++){
            subsets[i].parent = i;
            subsets[i].rank = 0;
        }

        int inserted_edges = 0;

        edge *itr = edges->head;

        // Insert v-1 edges into the MST
        while(itr!=NULL && inserted_edges<v){

            // Find the roots of the subsets that have the nodes corresponding to our edge
            int a_root = Find(subsets, itr->a);
            int b_root = Find(subsets, itr->b);

            // If the nodes (and hence the roots) belong to different subsets, then insert the edge into the MST by finding the union of the 2 subsets
            if(a_root!=b_root){
                Union(subsets, itr->a, itr->b);
                ans[inserted_edges++] = *itr;
            }

            itr = itr->next;
        }

        return ans;

    }

    // A utility function to output the state of MST and the code that generates the visual graph using the DOT language
    void generate_answer(edge *ans){

        int total = 0;

        cout<<"Node1 Node2 Weight:"<<endl;

        for(int i = 0; i < v-1; i++){
            cout<<(ans[i].a+1)<<" "<<(ans[i].b+1)<<" "<<ans[i].w<<endl;
            total += ans[i].w;
        }

        cout<<endl;
        cout<<"Total edge weight of the MST: "<<total<<endl;

        cout<<endl;
        cout<<"dot code: "<<endl;
        cout<<"graph kruskal_mst{"<<endl;
        cout<<"    overlap=\"scale\";"<<endl;

        for(int i = 0; i < v-1; i++){
            cout<<"    "<<(ans[i].a+1)<<" -- "<<(ans[i].b+1)<<" [label=\" "<<ans[i].w<<" \"];"<<endl;
        }

        cout<<"}"<<endl;

    }

};


int main(){

    int e, v=0;

    int a, b, w;

    Edge_List *edges = new Edge_List();

    // Input the edges
    while(cin>>a>>b>>w){
        e++;
        v = (v>a) ? v : a;
        v = (v>b) ? v : b;
        edges->insert(a-1, b-1, w);
    }

    // Make a graph out of the edges
    Graph *my_graph = new Graph(e, v, edges);
    // Find the MST and parse it into the desirable output format
    my_graph->generate_answer(my_graph->Kruskal());

    return 0;
    
}
