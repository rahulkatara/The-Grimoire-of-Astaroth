// Shashank Aital - 19114076
// Batch O4
// Computer Science and Engineering
// Indian Institute of Technology, Roorkee

// Lab 5 - Problem 1

#include <iostream>
using namespace std;

// Structure storing the implementation of a node
struct vertex{

    int number;
    vertex *next;

};

// Utility Linked List to form the Linked Lists used in Adjacency List
class Linked_List{

    public:
    vertex *head;

    Linked_List(){
        head = NULL;
    }

    void push(int number){

        vertex *x = new vertex();
        x->number = number;
        x->next = head;
        head = x;

    }

};

// Utility Queue class to be used in BFS
class Queue{

    public:
    vertex *front, *rear;

    Queue(){
        front = NULL;
        rear = NULL;
    }

    // Function to push an element into the queue
    void push(int y){

        vertex *x = new vertex();
        x->number = y;
        x->next = NULL;
        if(rear == NULL){
            front = x;
            rear = x;
        }else{
            rear->next = x;
            rear = x;
        }

    }

    // Function to pop an element from the queue
    int pop(){

        vertex *x = front;
        front = front->next;
        if(front == NULL){
            rear = NULL;
        }
        int y = x->number;
        delete(x);
        return y;

    }

    // A utility function to check if the queue is empty
    bool isEmpty(){
        if(front==NULL && rear == NULL){
            return true;
        }
        return false;
    }

};

// A class to implement a Graph
class Graph{

    public:
    Linked_List *graph; // Adjacency List
    bool *visited; // Boolean Array to check if a node is visited
    int vertices; // Number of nodes/vertices in a graph

    // Initialize all the global variables
    Graph(int vertices){
        graph = new Linked_List[vertices];
        visited = new bool[vertices];
        this->vertices = vertices;
    }

    // A utility function to insert an edge into the adjacency list
    void insert(int vertex1, int vertex2){
        graph[vertex1].push(vertex2);
        graph[vertex2].push(vertex1);
    }

    // A utility function to reset the elements of the boolean array "visited" to false
    void reset(){
        for(int i = 0; i < vertices; i++){
            visited[i] = 0;
        }
    }

    // A function to implement BFS
    void bfs(int root){

        reset(); // Reset the visited status of all the elements

        cout<<"BFS: ";
        // Initialize the queue
        Queue *q = new Queue();
        
        // Push the source node
        q->push(root);
        // Mark the source node as visited
        visited[root] = 1;
        cout<<root+1<<" ";

        // Loop till the queue is empty
        while(!q->isEmpty()){

            // Pop an element from the queue
            int x = q->pop();
            vertex *itr = graph[x].head;

            // Look up all of it's adjacent nodes
            while(itr!=NULL){

                // If one of the nodes is not visited, push that element into the queue and mark it visited
                if(!visited[itr->number]){

                    q->push(itr->number);
                    visited[itr->number] = 1;
                    cout<<itr->number+1<<" ";

                }
                itr = itr->next;

            }

        }
        cout<<endl;

    }

    // The driver code for DFS
    // We do not need to implement a separate utility "Stack" class because the execution of a program is done using a system stack
    // So, a simple recursive call would give the same effect as implementing a stack
    void dfs_driver(int root){

        // Mark the node that is provided in input as visited
        visited[root] = 1;
        cout<<root+1<<" ";

        vertex *itr = graph[root].head;

        // Look up the adjacent nodes to the given node
        while(itr!=NULL){

            // If a node is not visited, recursively call DFS for that node
            if(!visited[itr->number]){
                dfs_driver(itr->number);
            }
            itr = itr->next;

        }

    }

    // The call function for DFS driver
    void dfs(int root){

        reset(); // Reset the visited status of all the nodes to false
        cout<<"DFS: ";
        dfs_driver(root); // Call the driver
        cout<<endl;

    }

    // A function to determine if the graph has cycles
    bool has_cycle(){
        
        // Implement BFS
        // Not using the above function because it is made specifically to print the bfs traversal

        // NOTE:
        // We dont need to use any algorithm in finding the cycle since the given graph is connected
        // Hence, it will have cycles iff the number of edges >= number of vertices
        // Hence, cycle finding here can be O(1)

        // Here is an algorithm to finding cycles in any graph

        // Algorithm:
        /**
         * Check if any of the adjacent nodes to a node are visited
         * If any of the node is visited, check if it is that node's parent node
         * If it is not the parent node, then, the graph has a cycle
        */

        reset(); // Reset the visited status of all the nodes to false

        // Following the same algorithm used in BFS as implemented above
        Queue *q = new Queue();
        // Boolean denoting if the graph has a cycle in it
        bool ans = false;

        int parent[vertices]; // An array to keep track of the parents of a node
        // Initializing the array so that the parents of all the nodes are not defined (in the current context of the graph)
        for(int i = 0; i < vertices; i++){
            parent[i] = -1;
        }

        int root = graph[0].head->number;
        q->push(root);
        visited[root] = 1;

        // Loop iff ans is false i.e. a cycle has not been found yet
        while(!q->isEmpty() && !ans){

            int x = q->pop();
            vertex *itr = graph[x].head;

            while(itr!=NULL){

                if(!visited[itr->number]){

                    // Assign the value of parent
                    parent[itr->number] = x;
                    q->push(itr->number);
                    visited[itr->number] = 1;

                }else{

                    // Check if the node that is already visited is the parent
                    if(itr->number != parent[x]){
                        // If it is not, our graph has a cycle
                        ans = true;
                        break;
                    }

                }
                itr = itr->next;

            }

        }

        return ans;

    }

    // A function to find the diameter of our graph
    int diameter(){

        // If our graph was a tree we could've found the diameter in O(N) by applying BFS twice
        // Since our graph isn't a tree, we apply BFS from each and every vertex and find the depths of different vertices from that vertex
        // The maximum depth is our diameter

        int ans = -1;

        // Loop over all the vertices
        for(int i = 0; i < vertices; i++){

            reset();
            // An array to store the depth
            int depth[vertices] = {0};

            Queue *q = new Queue();

            // Set the current vertex as root
            int root = graph[i].head->number;
            q->push(root);
            visited[root] = 1;
            depth[root] = 0;

            while(!q->isEmpty()){
                int x = q->pop();
                vertex *itr = graph[x].head;

                while(itr!=NULL){
                    if(!visited[itr->number]){
                        q->push(itr->number);
                        visited[itr->number] = 1;
                        // Depth of child = Depth of Parent +1
                        depth[itr->number] = depth[x] + 1;
                    }
                    itr = itr->next;
                }
            }

            // Find maximum depth
            for(int j = 0; j < vertices; j++){
                ans = (ans > depth[j]) ? ans : depth[j];
            }

        }

        return ans;

    }

};


int main(){

    int nodes=-1, edges;
    // Input: The number of edges in our graph
    cin>>edges;

    // Utility 2-D array to store the inputs (In order to find the number of vertices)
    int vertices[edges][2];
    for(int i = 0; i < edges; i++){
        // Input: Edges
        cin>>vertices[i][0]>>vertices[i][1];
        // Set the number of nodes to the maximum input node_id
        nodes = (nodes > vertices[i][0]) ? nodes : vertices[i][0];
        nodes = (nodes > vertices[i][1]) ? nodes : vertices[i][1];
    }

    // Initialize the graph with the number of nodes
    Graph *g = new Graph(nodes);

    // Push edges into the graph
    for(int i = 0; i < edges; i++){
        g->insert(vertices[i][0]-1, vertices[i][1]-1);
    }

    // Perform BFS
    g->bfs(0);
    // Perform DFS
    g->dfs(0);
    
    // Check if the given graph has a cycle
    if(g->has_cycle()) cout<<"Cycle Found: YES"<<endl;
    else cout<<"Cycle Found: NO"<<endl;

    // Output the diameter of the graph
    cout<<"Diameter: "<<g->diameter()<<endl;

    return 0;

}
